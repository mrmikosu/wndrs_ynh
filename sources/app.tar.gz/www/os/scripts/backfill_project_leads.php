<?php
declare(strict_types=1);

/**
 * CLI: Project-Lead-Backfill für Altbestand ohne project_memberships.
 *
 * Idempotent — mehrfach ausführbar. Legt für jedes Projekt ohne Membership
 * einen lead an (Quelle: projects.lead_id, sonst erster Admin/Superadmin).
 *
 * Nutzung (lokal, aus dem Repo-Root oder site/):
 *   php site/scripts/backfill_project_leads.php
 *
 * Kein Deploy, keine Live-DB-Änderung durch dieses Skript selbst — nur wenn
 * du es bewusst gegen eine lokale/Staging-Datenbank startest.
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    echo "Nur als CLI ausführbar.\n";
    exit(1);
}

require_once dirname(__DIR__) . '/app/bootstrap.php';

$stats = BackfillProjectLeads::run(Db::pdo());

echo "Backfill project_memberships (lead)\n";
echo "  Projekte gescannt:  {$stats['scanned']}\n";
echo "  Leads angelegt:     {$stats['created']}\n";
echo "  Übersprungen:       {$stats['skipped']}\n";
echo "  Warnungen:          " . count($stats['warnings']) . "\n";

foreach ($stats['warnings'] as $warning) {
    fwrite(STDERR, "WARN {$warning}\n");
}

exit(0);
