<?php
declare(strict_types=1);

final class Automations
{
    public static function fire(string $trigger, array $payload = []): void
    {
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM automation_rules WHERE enabled = 1 AND trigger = ?');
        $stmt->execute([$trigger]);
        foreach ($stmt->fetchAll() as $rule) {
            $message = '';
            $status = 'ok';
            try {
                if ($rule['action'] === 'create_project_from_event') {
                    $title = $payload['title'] ?? 'Event-Projekt';
                    $eventId = $payload['event_id'] ?? null;
                    $pid = uuid();
                    $ins = $db->prepare('INSERT INTO projects (id, title, description, status, event_id) VALUES (?,?,?,?,?)');
                    $ins->execute([$pid, 'Projekt: ' . $title, 'Auto aus Event', 'planned', $eventId]);
                    $t = $db->prepare('INSERT INTO tasks (id, project_id, title, status, sort_order) VALUES (?,?,?,?,?)');
                    $t->execute([uuid(), $pid, 'Kickoff / Crew', 'todo', 0]);
                    $t->execute([uuid(), $pid, 'Technik / Rider', 'todo', 1]);
                    $t->execute([uuid(), $pid, 'Nachbereitung', 'todo', 2]);
                    $message = 'Project ' . $pid . ' created';
                } else {
                    $status = 'skip';
                    $message = 'Unknown action';
                }
            } catch (Throwable $e) {
                $status = 'error';
                $message = $e->getMessage();
            }
            $run = $db->prepare('INSERT INTO automation_runs (id, rule_id, payload, status, message) VALUES (?,?,?,?,?)');
            $run->execute([uuid(), $rule['id'], json_encode_db($payload), $status, $message]);
        }
    }
}
