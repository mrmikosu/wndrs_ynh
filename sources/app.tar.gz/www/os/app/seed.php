<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$db = Db::pdo();
Db::migrate();

$cfg = Config::load();
$adminEmail = strtolower($cfg['seed_admin_email'] ?? 'dev@wndrs.de');
$memberEmail = strtolower($cfg['seed_member_email'] ?? 'member@wndrs.local');
$adminPass = $cfg['seed_admin_password'] ?? 'change-me-admin';
$memberPass = $cfg['seed_member_password'] ?? 'change-me-member';

function ensure_user(PDO $db, string $email, string $name, string $password, array $roles, string $membership, bool $publicProfile = false): string
{
    $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $id = $stmt->fetchColumn();
    if (!$id) {
        $id = uuid();
        $db->prepare('INSERT INTO users (id, email, display_name, password_hash) VALUES (?,?,?,?)')
            ->execute([$id, $email, $name, password_hash($password, PASSWORD_DEFAULT)]);
        $db->prepare('INSERT INTO memberships (id, user_id, status, joined_at) VALUES (?,?,?,datetime("now"))')
            ->execute([uuid(), $id, $membership]);
        $db->prepare('INSERT INTO profiles (id, user_id, artist_name, bio, public_visible, visibility) VALUES (?,?,?,?,?,?)')
            ->execute([uuid(), $id, $name, 'Seed-Profil', $publicProfile ? 1 : 0, 'public']);
    } else {
        $db->prepare('UPDATE users SET password_hash = ?, display_name = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $name, $id]);
    }
    $db->prepare('DELETE FROM role_assignments WHERE user_id = ?')->execute([$id]);
    foreach ($roles as $role) {
        $db->prepare('INSERT INTO role_assignments (id, user_id, role) VALUES (?,?,?)')
            ->execute([uuid(), $id, $role]);
    }
    return (string) $id;
}

$adminId = ensure_user($db, $adminEmail, 'WNDRS Admin', $adminPass, ['superadmin', 'admin', 'finance', 'team'], 'active', true);
$memberId = ensure_user($db, $memberEmail, 'Demo Member', $memberPass, ['member'], 'active');
$teamEmail = strtolower($cfg['seed_team_email'] ?? 'team@wndrs.local');
$teamPass = $cfg['seed_team_password'] ?? 'change-me-team';
$teamId = ensure_user($db, $teamEmail, 'Demo Team', $teamPass, ['member', 'team'], 'active');
unset($teamId); // used for seed side-effects only

// Home page
$home = $db->query("SELECT id FROM pages WHERE slug = 'home'")->fetchColumn();
$blocks = [
    ['type' => 'hero', 'eyebrow' => 'WNDRS KLLKTV BERLIN', 'headline' => '… woanders wenn nicht hier.'],
    ['type' => 'richtext', 'body' => 'Freiräume für Kunst, Events und kollektives Arbeiten. Mitglieder organisieren sich im OS — öffentlich bleibt die Haltung sichtbar.'],
    ['type' => 'cta', 'label' => 'Mitmachen', 'href' => '/apply'],
];
if (!$home) {
    $db->prepare('INSERT INTO pages (id, slug, title, status, blocks, version) VALUES (?,?,?,?,?,1)')
        ->execute([uuid(), 'home', 'Home', 'published', json_encode_db($blocks)]);
} else {
    $db->prepare('UPDATE pages SET status = ?, blocks = ?, title = ? WHERE slug = ?')
        ->execute(['published', json_encode_db($blocks), 'Home', 'home']);
}

// Channel
$ch = $db->query("SELECT id FROM channels WHERE slug = 'general'")->fetchColumn();
if (!$ch) {
    $ch = uuid();
    $db->prepare('INSERT INTO channels (id, slug, name, kind) VALUES (?,?,?,?)')
        ->execute([$ch, 'general', 'General', 'topic']);
    $db->prepare('INSERT INTO messages (id, channel_id, author_id, body) VALUES (?,?,?,?)')
        ->execute([uuid(), $ch, $adminId, 'Willkommen im Kollektiv OS.']);
}

// Project + tasks
$proj = $db->query("SELECT id FROM projects LIMIT 1")->fetchColumn();
if (!$proj) {
    $proj = uuid();
    $db->prepare('INSERT INTO projects (id, title, description, status, lead_id) VALUES (?,?,?,?,?)')
        ->execute([$proj, 'Kollektiv Launch', 'Same-day PHP launch', 'active', $adminId]);
    foreach ([['Setup Hosting', 'todo'], ['Seed & Smoke', 'doing'], ['Go Live', 'todo']] as $i => [$title, $st]) {
        $db->prepare('INSERT INTO tasks (id, project_id, title, status, sort_order) VALUES (?,?,?,?,?)')
            ->execute([uuid(), $proj, $title, $st, $i]);
    }
}

// Event
$ev = $db->query("SELECT id FROM events LIMIT 1")->fetchColumn();
if (!$ev) {
    $db->prepare('INSERT INTO events (id, title, description, venue, starts_at, status, public) VALUES (?,?,?,?,datetime("now","+14 days"),?,1)')
        ->execute([uuid(), 'Open Studio Night', 'Öffentlicher Abend im Kollektiv.', 'Berlin', 'published']);
}

// Wiki / board / equipment / poll / automation
if (!$db->query("SELECT id FROM wiki_pages LIMIT 1")->fetchColumn()) {
    $db->prepare('INSERT INTO wiki_pages (id, slug, title, body, updated_by_id) VALUES (?,?,?,?,?)')
        ->execute([uuid(), 'onboarding', 'Onboarding', "1. Profil ausfüllen\n2. General lesen\n3. Regeln bestätigen", $adminId]);
}
if (!$db->query("SELECT id FROM board_posts LIMIT 1")->fetchColumn()) {
    $db->prepare('INSERT INTO board_posts (id, author_id, title, body, category, pinned) VALUES (?,?,?,?,?,1)')
        ->execute([uuid(), $adminId, 'Willkommen am Brett', 'Gesuche, Aufrufe, Kooperationen hier.', 'notice']);
}
if (!$db->query("SELECT id FROM assets LIMIT 1")->fetchColumn()) {
    $db->prepare('INSERT INTO assets (id, name, category, location, status) VALUES (?,?,?,?,?)')
        ->execute([uuid(), 'PA System Klein', 'audio', 'Lager A', 'available']);
}
if (!$db->query("SELECT id FROM polls LIMIT 1")->fetchColumn()) {
    $db->prepare('INSERT INTO polls (id, title, description, kind, options, created_by_id) VALUES (?,?,?,?,?,?)')
        ->execute([uuid(), 'Nächstes Plenum', 'Terminfindung', 'decision', json_encode_db(['Di 19h', 'Do 19h', 'Sa 11h']), $adminId]);
}
if (!$db->query("SELECT id FROM automation_rules LIMIT 1")->fetchColumn()) {
    $db->prepare('INSERT INTO automation_rules (id, name, trigger, action, enabled) VALUES (?,?,?,?,1)')
        ->execute([uuid(), 'Event → Projekt', 'event.created', 'create_project_from_event']);
}
if (!$db->query("SELECT id FROM news_posts WHERE public = 1 LIMIT 1")->fetchColumn()) {
    $db->prepare('INSERT INTO news_posts (id, title, body, status, public) VALUES (?,?,?,?,1)')
        ->execute([uuid(), 'OS online', 'Das Kollektiv-Betriebssystem läuft.', 'published']);
}
if (!$db->query("SELECT id FROM job_posts LIMIT 1")->fetchColumn()) {
    $db->prepare('INSERT INTO job_posts (id, author_id, kind, role, title, body, location, event_date, pay_note, contact, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([uuid(), $adminId, 'gesuch', 'runner', 'Runner für Open Studio', '2 Runner für Auf-/Abbau und Artist-Care.', 'Berlin', date('Y-m-d', strtotime('+14 days')), 'Aufwand / Verpflegung', $adminEmail, 'open']);
    $db->prepare('INSERT INTO job_posts (id, author_id, kind, role, title, body, location, event_date, pay_note, contact, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([uuid(), $memberId, 'angebot', 'fotograf', 'Event-Fotografie', 'Ich fotografiere Kollektiv-Events, Portfolio auf Anfrage.', 'Berlin', null, 'nach Absprache', $memberEmail, 'open']);
    $db->prepare('INSERT INTO job_posts (id, author_id, kind, role, title, body, location, event_date, pay_note, contact, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([uuid(), $adminId, 'gesuch', 'barkeeper', 'Bar-Support Wochenende', 'Erfahrene:r Barkeeper:in für Pop-up Bar.', 'Neukölln', date('Y-m-d', strtotime('+21 days')), 'Abendgage', $adminEmail, 'open']);
}

$upload = Config::get('upload_dir');
if (!is_dir($upload)) {
    mkdir($upload, 0775, true);
}
file_put_contents(rtrim($upload, '/') . '/.htaccess', "Options -Indexes\nphp_flag engine off\n");

echo "Seed OK\n";
echo "Admin:  {$adminEmail} / {$adminPass}\n";
echo "Team:   {$teamEmail} / {$teamPass}\n";
echo "Member: {$memberEmail} / {$memberPass}\n";
