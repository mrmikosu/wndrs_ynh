<?php
declare(strict_types=1);

/**
 * Outbox — einfacher Ausgangskorb für nachgelagerte Effekte.
 * Einträge entstehen in derselben Transaktion wie die Fachänderung;
 * ein Worker kann sie später verarbeiten (status: pending → processed).
 */
final class Outbox
{
    public function __construct(private readonly PDO $db)
    {
    }

    /** @param array<string, mixed> $payload */
    public function append(string $type, array $payload): void
    {
        $this->db->prepare('INSERT INTO outbox (id, type, payload_json, status) VALUES (?,?,?,?)')
            ->execute([uuid(), $type, json_encode_db($payload), 'pending']);
    }
}
