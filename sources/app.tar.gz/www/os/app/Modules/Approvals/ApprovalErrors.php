<?php
declare(strict_types=1);

/**
 * Fehlertypen für Freigabe-Workflows (Phase 2, wiederverwendet in Phase 5).
 * Die Handler bilden sie auf HTTP-Statuscodes ab:
 * ApprovalForbidden → 403, ApprovalNotFound → 404,
 * ApprovalConflict → 409, ApprovalValidation → Formularfehler (Flash).
 */
class ApprovalError extends RuntimeException
{
}

/** Kein Grundrecht, keine Bereichszuständigkeit oder Selbstfreigabe. */
final class ApprovalForbidden extends ApprovalError
{
}

/** Zielobjekt existiert nicht. */
final class ApprovalNotFound extends ApprovalError
{
}

/** Zustand hat sich geändert — Doppelentscheidung oder veralteter Status. */
final class ApprovalConflict extends ApprovalError
{
}

/** Fachlicher Validierungsfehler (z. B. fehlende Ablehnungsbegründung). */
final class ApprovalValidation extends ApprovalError
{
}
