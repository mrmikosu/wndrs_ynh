<?php
declare(strict_types=1);

/**
 * ApprovalInboxQuery — gebündelte Freigabe-Warteschlange für /admin/inbox.
 *
 * Bündelt: Auslagen (status 'submitted', Workflow aus Phase 2),
 * Equipment-Reservierungen (status 'requested'), Bewerbungen (status 'pending').
 *
 * Berechtigungsfilterung passiert HIER (nicht in der View):
 * - Auslagen: 'finance.approve' + Bereichszuständigkeit (ProjectPolicy::canManage
 *   bei Projekt-Auslagen); eigene Einreichungen werden ausgeblendet
 *   (Selbstfreigabe-Verbot aus Phase 2).
 * - Equipment: 'equipment.approve'. Bewerbungen: 'applications.decide'.
 *
 * Zuweisungsbegriff (interpretiert, da es kein Zuweisungsmodell gibt):
 * - 'mine'     → projektverknüpfte Auslage, in deren Projekt der Actor Lead ist
 * - 'project'  → projektverknüpfte Auslage, Zuständigkeit über globale Rechte
 * - 'general'  → allgemeine Queue (kein Projektbezug / Equipment / Bewerbung)
 *
 * Überfällig: älter als OVERDUE_DAYS Tage.
 */
final class ApprovalInboxQuery
{
    public const OVERDUE_DAYS = 7;

    public const TYPE_LABELS = [
        'expense' => 'Auslage',
        'equipment' => 'Equipment',
        'application' => 'Bewerbung',
    ];

    public const STATUS_LABELS = [
        'expense' => 'eingereicht',
        'equipment' => 'angefragt',
        'application' => 'offen',
    ];

    public function __construct(private readonly PDO $db)
    {
    }

    /**
     * @param array{type?: string, scope?: string, overdue?: bool|string, project_id?: string} $filters
     * @return list<array<string, mixed>>
     */
    public function forActor(Actor $actor, array $filters = []): array
    {
        if (!$actor->active) {
            return [];
        }
        $items = [];
        $type = (string) ($filters['type'] ?? '');
        if ($this->wantsType($type, 'expense') && $actor->can('finance.approve')) {
            $items = array_merge($items, $this->expenseItems($actor));
        }
        if ($this->wantsType($type, 'equipment') && $actor->can('equipment.approve')) {
            $items = array_merge($items, $this->equipmentItems());
        }
        if ($this->wantsType($type, 'application') && $actor->can('applications.decide')) {
            $items = array_merge($items, $this->applicationItems());
        }

        $scope = (string) ($filters['scope'] ?? '');
        $projectFilter = (string) ($filters['project_id'] ?? '');
        $onlyOverdue = !empty($filters['overdue']);
        $items = array_values(array_filter($items, static function (array $item) use ($scope, $projectFilter, $onlyOverdue): bool {
            if ($scope === 'mine' && $item['assignment'] !== 'mine') {
                return false;
            }
            if ($scope === 'unassigned' && $item['assignment'] !== 'general') {
                return false;
            }
            if ($projectFilter !== '' && ($item['project_id'] ?? '') !== $projectFilter) {
                return false;
            }
            if ($onlyOverdue && !$item['overdue']) {
                return false;
            }
            return true;
        }));

        // Älteste zuerst — was am längsten wartet, steht oben.
        usort($items, static fn (array $a, array $b): int => strcmp((string) $a['created_at'], (string) $b['created_at']));
        return $items;
    }

    /** @return array<string, int> Anzahl offener Einträge je Typ (berechtigungsgefiltert). */
    public function countsByType(Actor $actor): array
    {
        $counts = ['expense' => 0, 'equipment' => 0, 'application' => 0];
        foreach ($this->forActor($actor) as $item) {
            $counts[$item['type']]++;
        }
        return $counts;
    }

    /** @return list<array<string, mixed>> */
    private function expenseItems(Actor $actor): array
    {
        $rows = $this->db->query(
            "SELECT e.*, u.display_name AS requester_name, p.title AS project_title, p.status AS project_status
             FROM expenses e
             LEFT JOIN users u ON u.id = e.submitter_id
             LEFT JOIN projects p ON p.id = e.project_id
             WHERE e.status = 'submitted'
             ORDER BY e.created_at ASC"
        )->fetchAll();
        $items = [];
        foreach ($rows as $row) {
            // Selbstfreigabe-Verbot: eigene Einreichungen nicht anzeigen.
            if ((string) $row['submitter_id'] === $actor->id) {
                continue;
            }
            $projectId = (string) ($row['project_id'] ?? '');
            $assignment = 'general';
            $responsibility = 'Finanzen (allgemein)';
            if ($projectId !== '') {
                $project = ['id' => $projectId, 'title' => $row['project_title'], 'status' => $row['project_status']];
                // Bereichszuständigkeit: ohne canManage für das Projekt ausblenden.
                if (!ProjectPolicy::canManage($actor, $project, $this->db)) {
                    continue;
                }
                $role = $this->projectRoleOf($actor->id, $projectId);
                $assignment = $role === 'lead' ? 'mine' : 'project';
                $responsibility = 'Finanzen + Projektleitung „' . (string) ($row['project_title'] ?? '–') . '“'
                    . ($assignment === 'mine' ? ' (Du)' : '');
            }
            $items[] = $this->item(
                'expense',
                (string) $row['id'],
                (string) $row['title'] . ' (' . number_format(((int) $row['amount_cents']) / 100, 2, ',', '.') . ' €)',
                (string) ($row['requester_name'] ?? '–'),
                $projectId !== '' ? (string) ($row['project_title'] ?? '–') : '',
                $responsibility,
                $assignment,
                (string) $row['created_at'],
                '/admin/expenses/decide',
                ['approved' => 'Freigeben', 'rejected' => 'Ablehnen'],
                'status',
                $projectId
            );
        }
        return $items;
    }

    /** @return list<array<string, mixed>> */
    private function equipmentItems(): array
    {
        $rows = $this->db->query(
            "SELECT r.*, a.name AS asset_name, u.display_name AS requester_name
             FROM asset_reservations r
             JOIN assets a ON a.id = r.asset_id
             JOIN users u ON u.id = r.requester_id
             WHERE r.status = 'requested'
             ORDER BY r.created_at ASC"
        )->fetchAll();
        $items = [];
        foreach ($rows as $row) {
            $items[] = $this->item(
                'equipment',
                (string) $row['id'],
                (string) $row['asset_name'] . ' (' . (string) $row['starts_at'] . ' – ' . (string) $row['ends_at'] . ')',
                (string) ($row['requester_name'] ?? '–'),
                '',
                'Equipment-Verwaltung',
                'general',
                (string) $row['created_at'],
                '/admin/equipment/approve',
                ['approved' => 'Freigeben', 'rejected' => 'Ablehnen'],
                'status',
                ''
            );
        }
        return $items;
    }

    /** @return list<array<string, mixed>> */
    private function applicationItems(): array
    {
        $rows = $this->db->query(
            "SELECT * FROM applications WHERE status = 'pending' ORDER BY created_at ASC"
        )->fetchAll();
        $items = [];
        foreach ($rows as $row) {
            $items[] = $this->item(
                'application',
                (string) $row['id'],
                (string) $row['name'],
                (string) $row['email'],
                '',
                'Aufnahme',
                'general',
                (string) $row['created_at'],
                '/admin/bewerbungen',
                ['accepted' => 'Annehmen', 'rejected' => 'Ablehnen'],
                'decision',
                ''
            );
        }
        return $items;
    }

    /** @param array<string, string> $actions */
    private function item(
        string $type,
        string $id,
        string $subject,
        string $requester,
        string $projectTitle,
        string $responsibility,
        string $assignment,
        string $createdAt,
        string $endpoint,
        array $actions,
        string $actionField,
        string $projectId
    ): array {
        $ageDays = $this->ageDays($createdAt);
        return [
            'type' => $type,
            'type_label' => self::TYPE_LABELS[$type],
            'status_label' => self::STATUS_LABELS[$type],
            'id' => $id,
            'subject' => $subject,
            'requester' => $requester,
            'project_title' => $projectTitle,
            'project_id' => $projectId,
            'responsibility' => $responsibility,
            'assignment' => $assignment,
            'created_at' => $createdAt,
            'age_days' => $ageDays,
            'overdue' => $ageDays >= self::OVERDUE_DAYS,
            'endpoint' => $endpoint,
            'actions' => $actions,
            'action_field' => $actionField,
        ];
    }

    private function wantsType(string $filter, string $type): bool
    {
        return $filter === '' || $filter === $type;
    }

    private function ageDays(string $createdAt): int
    {
        $ts = strtotime($createdAt);
        if ($ts === false) {
            return 0;
        }
        return max(0, (int) floor((time() - $ts) / 86400));
    }

    private function projectRoleOf(string $userId, string $projectId): ?string
    {
        $stmt = $this->db->prepare('SELECT role FROM project_memberships WHERE user_id = ? AND project_id = ?');
        $stmt->execute([$userId, $projectId]);
        $role = $stmt->fetchColumn();
        return $role === false ? null : (string) $role;
    }
}
