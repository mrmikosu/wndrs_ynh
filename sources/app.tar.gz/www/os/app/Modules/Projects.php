<?php
declare(strict_types=1);

final class Projects
{
    private const PHASES = [
        'idea', 'concept', 'funding', 'planning', 'execution', 'review', 'archive',
    ];

    private const TEMPLATES = [
        'festival' => [
            'label' => 'Festival',
            'milestones' => ['Line-up fixiert', 'Förderantrag', 'Abbau abgeschlossen'],
            'tasks' => ['Location & Genehmigungen', 'Line-up Koordination', 'Technik-Plot', 'Catering & Bar', 'Aftermovie planen'],
        ],
        'clubnight' => [
            'label' => 'Clubnight',
            'milestones' => ['DJ-Booking', 'Abendkasse-Plan', 'Finale Abrechnung'],
            'tasks' => ['Promo & Flyer', 'Gästeliste / Einlass', 'Tür & Security', 'Bar-Setup'],
        ],
        'tour' => [
            'label' => 'Tour',
            'milestones' => ['Routing steht', 'Transport gebucht', 'Letzte Show'],
            'tasks' => ['Venue-Liste', 'Backline-Check', 'Hotel & Rider', 'Merch-Packliste'],
        ],
        'exhibition' => [
            'label' => 'Ausstellung',
            'milestones' => ['Kuratierung', 'Vernissage', 'Abbau'],
            'tasks' => ['Ausstellungskonzept', 'Künstler-Kommunikation', 'Raum-Layout', 'Presse'],
        ],
        'workshop' => [
            'label' => 'Workshop',
            'milestones' => ['Programm final', 'Anmeldungen offen', 'Feedback eingeholt'],
            'tasks' => ['Zielgruppe & Format', 'Materialien', 'Raum buchen', 'Teilnehmer-Follow-up'],
        ],
        'openair' => [
            'label' => 'Open Air',
            'milestones' => ['Wetter-Backup', 'Bühne steht', 'Fläche geräumt'],
            'tasks' => ['Genehmigungen Outdoor', 'Strom & Wasser', 'Sanitär & Müll', 'Nachbarschafts-Info'],
        ],
    ];

    public static function membersProjectFromTemplate(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        if (!Rbac::can($user['roles'], 'projects.task') && !Rbac::can($user['roles'], '*')) {
            http_response_code(403);
            echo 'Keine Projektberechtigung.';
            return;
        }
        $template = $_POST['template'] ?? '';
        $title = trim($_POST['title'] ?? '');
        if (!isset(self::TEMPLATES[$template])) {
            flash('error', 'Unbekannte Vorlage.');
            redirect('/members/projekte');
        }
        if ($title === '') {
            $title = self::TEMPLATES[$template]['label'] . ' ' . date('Y-m');
        }
        $db = Db::pdo();
        $projectId = uuid();
        $desc = 'Aus Vorlage „' . self::TEMPLATES[$template]['label'] . '“ angelegt.';
        $db->prepare('INSERT INTO projects (id, title, description, status, priority, lead_id) VALUES (?,?,?,?,?,?)')
            ->execute([$projectId, $title, $desc, 'planned', 'medium', $user['id']]);

        foreach (self::PHASES as $i => $phase) {
            $status = $phase === 'idea' ? 'active' : 'pending';
            $db->prepare('INSERT INTO project_phases (id, project_id, phase, status, sort_order) VALUES (?,?,?,?,?)')
                ->execute([uuid(), $projectId, $phase, $status, $i]);
        }

        $tpl = self::TEMPLATES[$template];
        foreach ($tpl['milestones'] as $i => $ms) {
            $db->prepare('INSERT INTO project_milestones (id, project_id, title, status, sort_order) VALUES (?,?,?,?,?)')
                ->execute([uuid(), $projectId, $ms, 'open', $i]);
        }

        foreach ($tpl['tasks'] as $i => $taskTitle) {
            $db->prepare('INSERT INTO tasks (id, project_id, title, status, sort_order) VALUES (?,?,?,?,?)')
                ->execute([uuid(), $projectId, $taskTitle, 'todo', $i]);
        }

        $boardId = uuid();
        $db->prepare('INSERT INTO boards (id, project_id, title, template) VALUES (?,?,?,?)')
            ->execute([$boardId, $projectId, $title . ' Board', $template]);
        foreach (['Todo', 'Doing', 'Done'] as $i => $colTitle) {
            $db->prepare('INSERT INTO board_columns (id, board_id, title, sort_order) VALUES (?,?,?,?)')
                ->execute([uuid(), $boardId, $colTitle, $i]);
        }

        $db->prepare('INSERT INTO project_memberships (id, project_id, user_id, role) VALUES (?,?,?,?)')
            ->execute([uuid(), $projectId, $user['id'], 'lead']);
        audit($db, $user['id'], 'project.from_template', 'project', $projectId, ['template' => $template]);
        flash('success', 'Projekt aus Vorlage angelegt.');
        redirect('/members/projekte/view?id=' . urlencode($projectId));
    }

    public static function membersTaskComment(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $taskId = $_POST['task_id'] ?? '';
        $body = trim($_POST['body'] ?? '');
        if ($taskId === '' || $body === '') {
            flash('error', 'Kommentar fehlt.');
            redirect($_POST['return_to'] ?? '/members/projekte');
        }
        $db = Db::pdo();
        $task = $db->prepare('SELECT id, project_id FROM tasks WHERE id = ?');
        $task->execute([$taskId]);
        $row = $task->fetch();
        if (!$row) {
            flash('error', 'Task nicht gefunden.');
            redirect('/members/projekte');
        }
        $id = uuid();
        $db->prepare('INSERT INTO card_comments (id, task_id, author_id, body) VALUES (?,?,?,?)')
            ->execute([$id, $taskId, $user['id'], $body]);
        audit($db, $user['id'], 'task.comment', 'task', $taskId, ['comment_id' => $id]);
        $back = $_POST['return_to'] ?? '/members/projekte/view?id=' . urlencode((string) $row['project_id']) . '&task=' . urlencode($taskId);
        redirect($back);
    }

    public static function membersTaskChecklist(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $taskId = $_POST['task_id'] ?? '';
        $action = $_POST['form_action'] ?? 'add';
        $db = Db::pdo();
        $task = $db->prepare('SELECT id, project_id FROM tasks WHERE id = ?');
        $task->execute([$taskId]);
        $row = $task->fetch();
        if (!$row) {
            flash('error', 'Task nicht gefunden.');
            redirect('/members/projekte');
        }
        $back = $_POST['return_to'] ?? '/members/projekte/view?id=' . urlencode((string) $row['project_id']) . '&task=' . urlencode($taskId);
        if ($action === 'toggle') {
            $itemId = $_POST['item_id'] ?? '';
            $own = $db->prepare('SELECT id, done FROM card_checklists WHERE id = ? AND task_id = ?');
            $own->execute([$itemId, $taskId]);
            $item = $own->fetch();
            if ($item) {
                $done = empty($item['done']) ? 1 : 0;
                $db->prepare('UPDATE card_checklists SET done = ? WHERE id = ?')->execute([$done, $itemId]);
            }
            redirect($back);
        }
        if ($action === 'delete') {
            $itemId = $_POST['item_id'] ?? '';
            $db->prepare('DELETE FROM card_checklists WHERE id = ? AND task_id = ?')->execute([$itemId, $taskId]);
            redirect($back);
        }
        $title = trim($_POST['title'] ?? '');
        if ($title === '') {
            flash('error', 'Checklistenpunkt fehlt.');
            redirect($back);
        }
        $max = $db->prepare('SELECT COALESCE(MAX(sort_order), -1) FROM card_checklists WHERE task_id = ?');
        $max->execute([$taskId]);
        $order = ((int) $max->fetchColumn()) + 1;
        $id = uuid();
        $db->prepare('INSERT INTO card_checklists (id, task_id, title, sort_order) VALUES (?,?,?,?)')
            ->execute([$id, $taskId, $title, $order]);
        audit($db, $user['id'], 'task.checklist_add', 'task', $taskId, ['item_id' => $id]);
        redirect($back);
    }

    /** @return list<string> */
    public static function templateKeys(): array
    {
        return array_keys(self::TEMPLATES);
    }

    /** @return array<string, string> */
    public static function templateLabels(): array
    {
        $out = [];
        foreach (self::TEMPLATES as $key => $def) {
            $out[$key] = $def['label'];
        }
        return $out;
    }

    /**
     * @return array{comments: list<array>, checklists: list<array>}|null
     */
    public static function taskDetail(PDO $db, string $taskId, string $projectId): ?array
    {
        $stmt = $db->prepare('SELECT id FROM tasks WHERE id = ? AND project_id = ?');
        $stmt->execute([$taskId, $projectId]);
        if (!$stmt->fetchColumn()) {
            return null;
        }
        $c = $db->prepare(
            'SELECT c.*, u.display_name AS author_name FROM card_comments c
             JOIN users u ON u.id = c.author_id WHERE c.task_id = ? ORDER BY c.created_at ASC'
        );
        $c->execute([$taskId]);
        $comments = $c->fetchAll();
        $cl = $db->prepare('SELECT * FROM card_checklists WHERE task_id = ? ORDER BY sort_order, title');
        $cl->execute([$taskId]);
        $checklists = $cl->fetchAll();
        return ['comments' => $comments, 'checklists' => $checklists];
    }
}
