<?php
declare(strict_types=1);

/**
 * ApplicationRepository — Datenzugriff für Mitgliedschaftsbewerbungen.
 * Statuswechsel ausschließlich atomar (UPDATE ... WHERE id = ? AND status = ?).
 */
final class ApplicationRepository
{
    public function __construct(private readonly PDO $db)
    {
    }

    /** @return array<string, mixed>|null */
    public function find(string $id): ?array
    {
        if ($id === '') {
            return null;
        }
        $stmt = $this->db->prepare('SELECT * FROM applications WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    /** @return int geänderte Zeilen (0 = nicht mehr 'pending' → Konflikt) */
    public function applyDecision(string $id, string $newStatus, string $decidedBy, string $note): int
    {
        $stmt = $this->db->prepare(
            "UPDATE applications
             SET status = ?, decided_by = ?, decided_at = datetime('now'), decision_note = ?
             WHERE id = ? AND status = 'pending'"
        );
        $stmt->execute([$newStatus, $decidedBy, $note, $id]);
        return $stmt->rowCount();
    }
}
