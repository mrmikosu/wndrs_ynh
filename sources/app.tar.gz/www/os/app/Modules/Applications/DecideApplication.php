<?php
declare(strict_types=1);

/**
 * DecideApplication — Bewerbungsentscheidung nach dem Muster aus Phase 2.
 *
 * Regeln:
 * - Grundrecht 'applications.decide'.
 * - Nur status = 'pending' ist entscheidbar; Doppelentscheidung = 409.
 * - Ablehnung erfordert eine Begründung.
 * - Bei Annahme wird in derselben Transaktion ein Invite erzeugt
 *   (bisheriges Verhalten, jetzt transaktional abgesichert).
 * - Audit + Outbox in derselben Transaktion.
 */
final class DecideApplication
{
    public const DECISIONS = ['accepted', 'rejected'];

    public function __construct(private readonly PDO $db)
    {
    }

    /**
     * @return array{application: array<string, mixed>, invite_token: string|null}
     */
    public function decide(Actor $actor, string $applicationId, string $decision, string $note = ''): array
    {
        if (!$actor->active || !$actor->can('applications.decide')) {
            throw new ApprovalForbidden('Keine Berechtigung zur Bewerbungsentscheidung.');
        }
        if (!in_array($decision, self::DECISIONS, true)) {
            throw new ApprovalValidation('Ungültige Entscheidung.');
        }
        $note = trim($note);
        if ($decision === 'rejected' && $note === '') {
            throw new ApprovalValidation('Ablehnung erfordert eine Begründung.');
        }

        $repo = new ApplicationRepository($this->db);
        $application = $repo->find($applicationId);
        if ($application === null) {
            throw new ApprovalNotFound('Bewerbung nicht gefunden.');
        }

        $inviteToken = null;
        $this->db->beginTransaction();
        try {
            $changed = $repo->applyDecision($applicationId, $decision, $actor->id, $note);
            if ($changed === 0) {
                throw new ApprovalConflict('Bewerbung wurde bereits entschieden.');
            }
            if ($decision === 'accepted') {
                $inviteToken = bin2hex(random_bytes(16));
                $this->db->prepare('INSERT INTO invites (id, email, token, roles, invited_by_id, expires_at) VALUES (?,?,?,?,?,datetime("now","+14 days"))')
                    ->execute([uuid(), strtolower((string) $application['email']), $inviteToken, json_encode_db(['member']), $actor->id]);
            }
            audit($this->db, $actor->id, 'application.' . $decision, 'application', $applicationId, ['note' => $note]);
            (new Outbox($this->db))->append('application.decision', [
                'application_id' => $applicationId,
                'decision' => $decision,
                'decided_by' => $actor->id,
                'email' => (string) $application['email'],
                'note' => $note,
            ]);
            $this->db->commit();
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }

        return [
            'application' => $repo->find($applicationId) ?? $application,
            'invite_token' => $inviteToken,
        ];
    }
}
