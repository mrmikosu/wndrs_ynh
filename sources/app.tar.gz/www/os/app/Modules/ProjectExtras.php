<?php
declare(strict_types=1);

final class ProjectExtras
{
    public static function adminFunding(): void
    {
        $user = Auth::requireAdmin();
        $db = Db::pdo();
        $programs = $db->query('SELECT * FROM funding_programs ORDER BY deadline IS NULL, deadline')->fetchAll();
        $apps = $db->query(
            'SELECT a.*, p.title AS project_title, g.name AS program_name
             FROM funding_applications a
             JOIN projects p ON p.id = a.project_id
             LEFT JOIN funding_programs g ON g.id = a.program_id
             ORDER BY a.submitted_at DESC'
        )->fetchAll();
        $projects = $db->query('SELECT id, title FROM projects ORDER BY title')->fetchAll();
        layout('admin', 'admin/funding', compact('user', 'programs', 'apps', 'projects'));
    }

    public static function adminFundingSave(): void
    {
        $user = Auth::requireAdmin();
        require_csrf();
        $db = Db::pdo();
        $kind = $_POST['kind'] ?? 'program';
        if ($kind === 'program') {
            $id = uuid();
            $db->prepare('INSERT INTO funding_programs (id, name, funder, deadline, max_amount_cents, requirements, url) VALUES (?,?,?,?,?,?,?)')
                ->execute([
                    $id,
                    trim($_POST['name'] ?? ''),
                    trim($_POST['funder'] ?? ''),
                    $_POST['deadline'] ?: null,
                    (int) round(((float) ($_POST['max_amount'] ?? 0)) * 100),
                    trim($_POST['requirements'] ?? ''),
                    trim($_POST['url'] ?? ''),
                ]);
            audit($db, $user['id'], 'funding.program_create', 'funding_program', $id);
            flash('success', 'Förderprogramm angelegt.');
        } else {
            $id = uuid();
            $db->prepare('INSERT INTO funding_applications (id, project_id, program_id, status, amount_cents, note) VALUES (?,?,?,?,?,?)')
                ->execute([
                    $id,
                    $_POST['project_id'] ?? '',
                    $_POST['program_id'] ?: null,
                    $_POST['status'] ?? 'planned',
                    (int) round(((float) ($_POST['amount'] ?? 0)) * 100),
                    trim($_POST['note'] ?? ''),
                ]);
            audit($db, $user['id'], 'funding.app_create', 'funding_application', $id);
            flash('success', 'Antrag angelegt.');
        }
        redirect('/admin/foerderung');
    }

    public static function adminRisks(): void
    {
        $user = Auth::requireAdmin();
        $projectId = $_GET['project_id'] ?? '';
        $db = Db::pdo();
        $projects = $db->query('SELECT id, title FROM projects ORDER BY title')->fetchAll();
        $rows = [];
        if ($projectId !== '') {
            $s = $db->prepare('SELECT * FROM risks WHERE project_id = ? ORDER BY probability * impact DESC');
            $s->execute([$projectId]);
            $rows = $s->fetchAll();
        }
        layout('admin', 'admin/risks', compact('user', 'projects', 'projectId', 'rows'));
    }

    public static function adminRisksSave(): void
    {
        $user = Auth::requireAdmin();
        require_csrf();
        $id = uuid();
        $projectId = $_POST['project_id'] ?? '';
        Db::pdo()->prepare('INSERT INTO risks (id, project_id, title, probability, impact, mitigation, status) VALUES (?,?,?,?,?,?,?)')
            ->execute([
                $id,
                $projectId,
                trim($_POST['title'] ?? ''),
                max(1, min(5, (int) ($_POST['probability'] ?? 1))),
                max(1, min(5, (int) ($_POST['impact'] ?? 1))),
                trim($_POST['mitigation'] ?? ''),
                'open',
            ]);
        audit(Db::pdo(), $user['id'], 'risk.create', 'risk', $id);
        flash('success', 'Risiko erfasst.');
        redirect('/admin/risiken?project_id=' . urlencode($projectId));
    }

    public static function adminCrm(): void
    {
        $user = Auth::requireAdmin();
        $db = Db::pdo();
        $contacts = $db->query('SELECT * FROM contacts ORDER BY name')->fetchAll();
        $deals = $db->query(
            'SELECT d.*, c.name AS contact_name, p.title AS project_title
             FROM contact_deals d
             JOIN contacts c ON c.id = d.contact_id
             LEFT JOIN projects p ON p.id = d.project_id
             ORDER BY d.updated_at DESC'
        )->fetchAll();
        $projects = $db->query('SELECT id, title FROM projects ORDER BY title')->fetchAll();
        layout('admin', 'admin/crm', compact('user', 'contacts', 'deals', 'projects'));
    }

    public static function adminCrmSave(): void
    {
        $user = Auth::requireAdmin();
        require_csrf();
        $db = Db::pdo();
        $kind = $_POST['kind'] ?? 'contact';
        if ($kind === 'contact') {
            $id = uuid();
            $db->prepare('INSERT INTO contacts (id, kind, name, org, email, phone, note) VALUES (?,?,?,?,?,?,?)')
                ->execute([
                    $id,
                    $_POST['contact_kind'] ?? 'partner',
                    trim($_POST['name'] ?? ''),
                    trim($_POST['org'] ?? ''),
                    trim($_POST['email'] ?? ''),
                    trim($_POST['phone'] ?? ''),
                    trim($_POST['note'] ?? ''),
                ]);
            audit($db, $user['id'], 'crm.contact_create', 'contact', $id);
            flash('success', 'Kontakt angelegt.');
        } else {
            $id = uuid();
            $db->prepare('INSERT INTO contact_deals (id, contact_id, project_id, stage, next_step, note) VALUES (?,?,?,?,?,?)')
                ->execute([
                    $id,
                    $_POST['contact_id'] ?? '',
                    $_POST['project_id'] ?: null,
                    $_POST['stage'] ?? 'contact',
                    trim($_POST['next_step'] ?? ''),
                    trim($_POST['note'] ?? ''),
                ]);
            audit($db, $user['id'], 'crm.deal_create', 'contact_deal', $id);
            flash('success', 'Pipeline-Eintrag angelegt.');
        }
        redirect('/admin/crm');
    }
}
