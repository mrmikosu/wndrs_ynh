<?php
declare(strict_types=1);

/**
 * MemberEventCreate — Event-Anlage durch Mitglieder (Phase 5d).
 *
 * Mitglieder legen grundsätzlich nur ENTWÜRFE an: status = 'draft' und
 * public = 0 werden serverseitig erzwungen — egal, was das Formular sendet.
 * Veröffentlichung erfolgt ausschließlich über die Admin-Endpunkte
 * (Recht 'cms.publish', z. B. /admin/events). Audit + Outbox in einer
 * Transaktion; die Automation „Event → Projekt" feuert bewusst erst bei
 * der Admin-Anlage/Veröffentlichung, nicht bei Mitglieder-Entwürfen.
 */
final class MemberEventCreate
{
    public function __construct(private readonly PDO $db)
    {
    }

    /**
     * @param array<string, mixed> $data rohe Formulardaten (public/status werden ignoriert)
     * @return string ID des angelegten Entwurfs
     */
    public function create(Actor $actor, array $data): string
    {
        if (!$actor->active) {
            throw new ApprovalForbidden('Konto nicht aktiv.');
        }
        $title = trim((string) ($data['title'] ?? ''));
        if ($title === '') {
            throw new ApprovalValidation('Titel fehlt.');
        }
        $startsAt = trim((string) ($data['starts_at'] ?? ''));
        $id = uuid();
        $this->db->beginTransaction();
        try {
            $this->db->prepare('INSERT INTO events (id, title, description, venue, starts_at, status, public) VALUES (?,?,?,?,?,?,0)')
                ->execute([
                    $id,
                    $title,
                    trim((string) ($data['description'] ?? '')),
                    trim((string) ($data['venue'] ?? '')),
                    $startsAt !== '' ? $startsAt : null,
                    'draft',
                ]);
            audit($this->db, $actor->id, 'event.create_draft', 'event', $id, ['title' => $title]);
            (new Outbox($this->db))->append('event.draft_created', [
                'event_id' => $id,
                'title' => $title,
                'created_by' => $actor->id,
            ]);
            $this->db->commit();
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
        return $id;
    }
}
