<?php
declare(strict_types=1);

final class Ops
{
    public static function membersShifts(): void
    {
        $user = Auth::requireMember();
        if (!Rbac::can($user['roles'], 'events.shift_respond') && !Rbac::can($user['roles'], '*')) {
            http_response_code(403);
            echo 'Keine Berechtigung für Schichten.';
            return;
        }
        $db = Db::pdo();
        $stmt = $db->prepare(
            "SELECT sa.*, s.role AS shift_role, s.starts_at, s.ends_at, s.note AS shift_note,
                    e.title AS event_title, e.venue, p.title AS project_title
             FROM shift_assignments sa
             JOIN shifts s ON s.id = sa.shift_id
             JOIN events e ON e.id = s.event_id
             LEFT JOIN projects p ON p.id = s.project_id
             WHERE sa.user_id = ?
             ORDER BY s.starts_at DESC"
        );
        $stmt->execute([$user['id']]);
        $assignments = $stmt->fetchAll();
        layout('members', 'members/shifts', compact('user', 'assignments'));
    }

    public static function membersShiftRespond(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        if (!Rbac::can($user['roles'], 'events.shift_respond') && !Rbac::can($user['roles'], '*')) {
            http_response_code(403);
            echo 'Keine Berechtigung.';
            exit;
        }
        $id = $_POST['assignment_id'] ?? '';
        $action = $_POST['action'] ?? '';
        if (!in_array($action, ['accept', 'decline'], true)) {
            flash('error', 'Ungültige Aktion.');
            redirect('/members/schichten');
        }
        $status = $action === 'accept' ? 'accepted' : 'declined';
        $db = Db::pdo();
        $own = $db->prepare('SELECT id FROM shift_assignments WHERE id = ? AND user_id = ?');
        $own->execute([$id, $user['id']]);
        if (!$own->fetchColumn()) {
            flash('error', 'Zuweisung nicht gefunden.');
            redirect('/members/schichten');
        }
        $db->prepare('UPDATE shift_assignments SET status = ?, responded_at = datetime("now") WHERE id = ? AND user_id = ?')
            ->execute([$status, $id, $user['id']]);
        audit($db, $user['id'], 'shift.' . $status, 'shift_assignment', $id);
        flash('success', $status === 'accepted' ? 'Schicht zugesagt.' : 'Schicht abgesagt.');
        redirect('/members/schichten');
    }

    public static function membersAvailability(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM availability WHERE user_id = ? ORDER BY starts_at DESC LIMIT 100');
        $stmt->execute([$user['id']]);
        $rows = $stmt->fetchAll();
        layout('members', 'members/availability', compact('user', 'rows'));
    }

    public static function membersAvailabilitySave(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $action = $_POST['form_action'] ?? 'create';
        $db = Db::pdo();
        if ($action === 'delete') {
            $id = $_POST['id'] ?? '';
            $db->prepare('DELETE FROM availability WHERE id = ? AND user_id = ?')->execute([$id, $user['id']]);
            flash('success', 'Eintrag gelöscht.');
            redirect('/members/verfuegbarkeit');
        }
        $kind = $_POST['kind'] ?? 'available';
        if (!in_array($kind, ['available', 'unavailable', 'vacation'], true)) {
            $kind = 'available';
        }
        $starts = trim($_POST['starts_at'] ?? '');
        $ends = trim($_POST['ends_at'] ?? '');
        if ($starts === '' || $ends === '') {
            flash('error', 'Start und Ende sind Pflicht.');
            redirect('/members/verfuegbarkeit');
        }
        $startsDb = str_replace('T', ' ', $starts);
        $endsDb = str_replace('T', ' ', $ends);
        if (strlen($startsDb) === 16) {
            $startsDb .= ':00';
        }
        if (strlen($endsDb) === 16) {
            $endsDb .= ':00';
        }
        $note = trim($_POST['note'] ?? '');
        $id = uuid();
        $db->prepare('INSERT INTO availability (id, user_id, kind, starts_at, ends_at, note) VALUES (?,?,?,?,?,?)')
            ->execute([$id, $user['id'], $kind, $startsDb, $endsDb, $note]);
        audit($db, $user['id'], 'availability.create', 'availability', $id);
        flash('success', 'Verfügbarkeit gespeichert.');
        redirect('/members/verfuegbarkeit');
    }

    public static function adminInbox(): void
    {
        $user = Auth::requireAdmin();
        $actor = Actor::fromUser($user);
        $db = Db::pdo();

        // Filter aus GET (Whitelist-Validierung).
        $type = (string) ($_GET['type'] ?? '');
        if (!in_array($type, ['', 'expense', 'equipment', 'application'], true)) {
            $type = '';
        }
        $scope = (string) ($_GET['scope'] ?? '');
        if (!in_array($scope, ['', 'mine', 'unassigned'], true)) {
            $scope = '';
        }
        $projectId = (string) ($_GET['project_id'] ?? '');
        $filters = [
            'type' => $type,
            'scope' => $scope,
            'overdue' => !empty($_GET['overdue']),
            'project_id' => $projectId,
        ];

        $query = new ApprovalInboxQuery($db);
        $items = $query->forActor($actor, $filters);
        $counts = $query->countsByType($actor);
        $projects = $db->query('SELECT id, title FROM projects ORDER BY title')->fetchAll();
        layout('admin', 'admin/inbox', compact('user', 'items', 'counts', 'filters', 'projects'));
    }

    public static function adminInboxJobAppDecide(): void
    {
        $user = Auth::requirePerm('jobs.moderate');
        require_csrf();
        $id = $_POST['id'] ?? '';
        $status = $_POST['status'] ?? '';
        if (!in_array($status, ['accepted', 'rejected'], true)) {
            redirect(admin_return('/admin/inbox'));
        }
        $db = Db::pdo();
        $db->prepare("UPDATE job_applications SET status = ? WHERE id = ? AND status = 'applied'")
            ->execute([$status, $id]);
        audit($db, $user['id'], 'job_application.' . $status, 'job_application', $id);
        flash('success', 'Jobbewerbung bearbeitet.');
        redirect(admin_return('/admin/inbox'));
    }

    /** SEO-/AI-Crawler-Defaults (werden in app_settings überschrieben). */
    private const SEO_DEFAULTS = [
        'seo.site_title' => 'WNDRS KLLKTV — Kollektiv für Kunst, Musik & Aktionen · Berlin',
        'seo.site_description' => 'WNDRS KLLKTV Berlin — Kollektiv für Kunst, Musik und Aktionen. Woanders Bar, i.g NEORAVE und Eulenlaut Events; wir unterstützen Künstler:innen mit Raum, Technik und Coaching.',
        'seo.site_keywords' => 'Kollektiv, Berlin, Kunst, Musik, Events, Woanders Bar, NEORAVE, Eulenlaut, Förderung, Künstler',
        'seo.canonical_url' => 'https://kllktv.wndrs.de/',
        'seo.og_image' => 'https://kllktv.wndrs.de/images/og-image.png',
        'seo.llms_intro' => 'Kollektiv aus Berlin für Kunst, Musik und Aktionen — eigene Projekte (Woanders Bar, i.g NEORAVE, Eulenlaut Events) und Unterstützung für Künstler:innen.',
        'seo.ai_policy' => 'allow',
    ];

    public static function adminSeo(): void
    {
        $user = Auth::requirePerm('cms.publish');
        $db = Db::pdo();
        $stored = [];
        foreach ($db->query("SELECT key, value FROM app_settings WHERE key LIKE 'seo.%'")->fetchAll() as $row) {
            $stored[$row['key']] = $row['value'];
        }
        $seo = array_merge(self::SEO_DEFAULTS, $stored);
        layout('admin', 'admin/seo', compact('user', 'seo'));
    }

    public static function adminSeoSave(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $db = Db::pdo();
        $map = [
            'site_title' => 'seo.site_title',
            'site_description' => 'seo.site_description',
            'site_keywords' => 'seo.site_keywords',
            'canonical_url' => 'seo.canonical_url',
            'og_image' => 'seo.og_image',
            'llms_intro' => 'seo.llms_intro',
            'ai_policy' => 'seo.ai_policy',
        ];
        $upd = $db->prepare('INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?,?,datetime("now"))');
        foreach ($map as $field => $key) {
            $value = trim((string) ($_POST[$field] ?? ''));
            if ($value === '') {
                $value = self::SEO_DEFAULTS[$key];
            }
            if ($key === 'seo.ai_policy' && !in_array($value, ['allow', 'block'], true)) {
                $value = 'allow';
            }
            $upd->execute([$key, $value]);
        }
        audit($db, $user['id'], 'seo.save', 'app_settings', '', ['keys' => count($map)]);
        flash('success', 'SEO- & Crawler-Einstellungen gespeichert.');
        redirect('/admin/seo');
    }

    public static function adminSettings(): void
    {
        $user = Auth::requirePerm('settings.manage');
        $db = Db::pdo();
        $flags = $db->query('SELECT * FROM feature_flags ORDER BY key')->fetchAll();
        $settings = $db->query('SELECT * FROM app_settings ORDER BY key')->fetchAll();
        $health = Health::report();
        $pendingMail = (int) $db->query("SELECT COUNT(*) FROM mail_queue WHERE status = 'pending'")->fetchColumn();
        layout('admin', 'admin/settings', compact('user', 'flags', 'settings', 'health', 'pendingMail'));
    }

    public static function adminSettingsSave(): void
    {
        $user = Auth::requirePerm('settings.manage');
        require_csrf();
        $db = Db::pdo();
        $enabled = $_POST['flag_enabled'] ?? [];
        if (!is_array($enabled)) {
            $enabled = [];
        }
        $flags = $db->query('SELECT key FROM feature_flags')->fetchAll();
        foreach ($flags as $row) {
            $key = $row['key'];
            $on = !empty($enabled[$key]) ? 1 : 0;
            $db->prepare('UPDATE feature_flags SET enabled = ? WHERE key = ?')->execute([$on, $key]);
        }
        $newFlagKey = trim($_POST['new_flag_key'] ?? '');
        if ($newFlagKey !== '' && preg_match('/^[a-z][a-z0-9_.-]{1,48}$/', $newFlagKey)) {
            $db->prepare('INSERT OR IGNORE INTO feature_flags (key, enabled, note) VALUES (?,?,?)')
                ->execute([$newFlagKey, !empty($_POST['new_flag_enabled']) ? 1 : 0, trim($_POST['new_flag_note'] ?? '')]);
        }
        $values = $_POST['setting_value'] ?? [];
        if (is_array($values)) {
            foreach ($values as $key => $value) {
                if (!is_string($key) || $key === '') {
                    continue;
                }
                $db->prepare('UPDATE app_settings SET value = ?, updated_at = datetime("now") WHERE key = ?')
                    ->execute([(string) $value, $key]);
            }
        }
        $newSettingKey = trim($_POST['new_setting_key'] ?? '');
        $newSettingValue = (string) ($_POST['new_setting_value'] ?? '');
        if ($newSettingKey !== '' && preg_match('/^[a-z][a-z0-9_.-]{1,48}$/', $newSettingKey)) {
            $db->prepare('INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?,?,datetime("now"))')
                ->execute([$newSettingKey, $newSettingValue]);
        }
        audit($db, $user['id'], 'settings.save', 'app_settings', '', ['flags' => count($flags)]);
        flash('success', 'Einstellungen gespeichert.');
        redirect('/admin/einstellungen');
    }

    public static function membersNotifications(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY read_at IS NULL DESC, created_at DESC LIMIT 100');
        $stmt->execute([$user['id']]);
        $rows = $stmt->fetchAll();
        $unread = 0;
        foreach ($rows as $n) {
            if (empty($n['read_at'])) {
                ++$unread;
            }
        }
        layout('members', 'members/notifications', compact('user', 'rows', 'unread'));
    }

    public static function membersNotificationRead(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $db = Db::pdo();
        $id = $_POST['id'] ?? '';
        if ($id === 'all') {
            $db->prepare('UPDATE notifications SET read_at = datetime("now") WHERE user_id = ? AND read_at IS NULL')
                ->execute([$user['id']]);
            flash('success', 'Alle als gelesen markiert.');
        } elseif ($id !== '') {
            $db->prepare('UPDATE notifications SET read_at = datetime("now") WHERE id = ? AND user_id = ?')
                ->execute([$id, $user['id']]);
        }
        redirect('/members/benachrichtigungen');
    }

    public static function membersProjectCockpit(): void
    {
        $user = Auth::requireMember();
        $projectId = $_GET['project_id'] ?? ($_GET['id'] ?? '');
        $db = Db::pdo();
        $projects = $db->query("SELECT id, title FROM projects WHERE status != 'archived' ORDER BY title")->fetchAll();
        $project = null;
        $phase = null;
        $milestones = [];
        $openTasks = 0;
        $budgetCents = 0;
        $risks = [];
        if ($projectId !== '') {
            $stmt = $db->prepare('SELECT p.*, u.display_name AS lead_name FROM projects p LEFT JOIN users u ON u.id = p.lead_id WHERE p.id = ?');
            $stmt->execute([$projectId]);
            $project = $stmt->fetch() ?: null;
            if ($project) {
                if (!Rbac::can($user['roles'], 'projects.read') && !Rbac::can($user['roles'], '*')) {
                    http_response_code(403);
                    echo 'Kein Projektzugriff.';
                    return;
                }
                $ph = $db->prepare(
                    "SELECT * FROM project_phases WHERE project_id = ? AND status != 'done' ORDER BY sort_order LIMIT 1"
                );
                $ph->execute([$projectId]);
                $phase = $ph->fetch() ?: null;
                $ms = $db->prepare('SELECT * FROM project_milestones WHERE project_id = ? ORDER BY sort_order, due_at');
                $ms->execute([$projectId]);
                $milestones = $ms->fetchAll();
                $tc = $db->prepare("SELECT COUNT(*) FROM tasks WHERE project_id = ? AND status != 'done'");
                $tc->execute([$projectId]);
                $openTasks = (int) $tc->fetchColumn();
                $bc = $db->prepare('SELECT COALESCE(SUM(amount_cents), 0) FROM budget_items WHERE project_id = ?');
                $bc->execute([$projectId]);
                $budgetCents = (int) $bc->fetchColumn();
                $rk = $db->prepare("SELECT r.*, u.display_name AS owner_name FROM risks r LEFT JOIN users u ON u.id = r.owner_id WHERE r.project_id = ? AND r.status = 'open' ORDER BY impact DESC, probability DESC");
                $rk->execute([$projectId]);
                $risks = $rk->fetchAll();
            }
        }
        layout('members', 'members/project_cockpit', compact(
            'user',
            'projects',
            'project',
            'projectId',
            'phase',
            'milestones',
            'openTasks',
            'budgetCents',
            'risks'
        ));
    }

    public static function adminBudget(): void
    {
        $user = Auth::requirePerm('projects.budget');
        $db = Db::pdo();
        $projectId = $_GET['project_id'] ?? '';
        $projects = $db->query("SELECT id, title FROM projects ORDER BY title")->fetchAll();
        $items = [];
        $project = null;
        $totals = ['planned' => 0, 'actual' => 0];
        if ($projectId !== '') {
            $ps = $db->prepare('SELECT * FROM projects WHERE id = ?');
            $ps->execute([$projectId]);
            $project = $ps->fetch() ?: null;
            if ($project) {
                $stmt = $db->prepare('SELECT * FROM budget_items WHERE project_id = ? ORDER BY category, title');
                $stmt->execute([$projectId]);
                $items = $stmt->fetchAll();
                foreach ($items as $it) {
                    $totals['planned'] += (int) $it['amount_cents'];
                    $totals['actual'] += (int) $it['actual_cents'];
                }
            }
        }
        layout('admin', 'admin/budget', compact('user', 'projects', 'project', 'projectId', 'items', 'totals'));
    }

    public static function adminBudgetSave(): void
    {
        $user = Auth::requirePerm('projects.budget');
        require_csrf();
        $projectId = $_POST['project_id'] ?? '';
        if ($projectId === '') {
            flash('error', 'Projekt fehlt.');
            redirect('/admin/budget');
        }
        $action = $_POST['form_action'] ?? 'save';
        $db = Db::pdo();
        if ($action === 'delete') {
            $id = $_POST['id'] ?? '';
            $db->prepare('DELETE FROM budget_items WHERE id = ? AND project_id = ?')->execute([$id, $projectId]);
            audit($db, $user['id'], 'budget.delete', 'budget_item', $id);
            flash('success', 'Position gelöscht.');
            redirect('/admin/budget?project_id=' . urlencode($projectId));
        }
        $title = trim($_POST['title'] ?? '');
        if ($title === '') {
            flash('error', 'Titel fehlt.');
            redirect('/admin/budget?project_id=' . urlencode($projectId));
        }
        $kind = $_POST['kind'] ?? 'cost';
        if (!in_array($kind, ['cost', 'revenue'], true)) {
            $kind = 'cost';
        }
        $category = trim($_POST['category'] ?? 'other');
        $amountCents = (int) round(((float) ($_POST['amount'] ?? 0)) * 100);
        $actualCents = (int) round(((float) ($_POST['actual'] ?? 0)) * 100);
        $scenario = $_POST['scenario'] ?? 'base';
        $note = trim($_POST['note'] ?? '');
        $id = $_POST['id'] ?? '';
        if ($id) {
            $db->prepare(
                'UPDATE budget_items SET kind=?, category=?, title=?, amount_cents=?, scenario=?, actual_cents=?, note=? WHERE id=? AND project_id=?'
            )->execute([$kind, $category, $title, $amountCents, $scenario, $actualCents, $note, $id, $projectId]);
            audit($db, $user['id'], 'budget.update', 'budget_item', $id);
        } else {
            $id = uuid();
            $db->prepare(
                'INSERT INTO budget_items (id, project_id, kind, category, title, amount_cents, scenario, actual_cents, note) VALUES (?,?,?,?,?,?,?,?,?)'
            )->execute([$id, $projectId, $kind, $category, $title, $amountCents, $scenario, $actualCents, $note]);
            audit($db, $user['id'], 'budget.create', 'budget_item', $id);
        }
        flash('success', 'Budgetposition gespeichert.');
        redirect('/admin/budget?project_id=' . urlencode($projectId));
    }

    public static function membersIcal(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $uidHost = preg_replace('/[^a-z0-9.-]/i', '', (string) parse_url((string) Config::get('base_url', 'wndrs.local'), PHP_URL_HOST)) ?: 'wndrs.local';

        $shifts = $db->prepare(
            "SELECT s.starts_at, s.ends_at, s.role, e.title AS event_title, e.venue
             FROM shift_assignments sa
             JOIN shifts s ON s.id = sa.shift_id
             JOIN events e ON e.id = s.event_id
             WHERE sa.user_id = ? AND sa.status IN ('invited','accepted')
             AND s.starts_at >= datetime('now','-30 days')
             ORDER BY s.starts_at"
        );
        $shifts->execute([$user['id']]);
        $shiftRows = $shifts->fetchAll();

        $events = $db->query(
            "SELECT title, description, venue, starts_at, ends_at, id
             FROM events
             WHERE starts_at IS NOT NULL AND starts_at >= datetime('now','-30 days')
             ORDER BY starts_at"
        )->fetchAll();

        $lines = [
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'PRODID:-//WNDRS//Team//DE',
            'CALSCALE:GREGORIAN',
            'METHOD:PUBLISH',
            'X-WR-CALNAME:WNDRS ' . self::icalEscape($user['display_name'] ?? 'Team'),
        ];

        foreach ($shiftRows as $row) {
            $lines = array_merge($lines, self::icalEvent(
                'shift-' . md5($row['starts_at'] . $row['event_title']),
                $row['event_title'] . ' (' . $row['role'] . ')',
                $row['venue'] ?? '',
                $row['starts_at'],
                $row['ends_at'],
                $uidHost
            ));
        }
        foreach ($events as $ev) {
            $end = $ev['ends_at'] ?: date('Y-m-d H:i:s', strtotime((string) $ev['starts_at'] . ' +2 hours'));
            $lines = array_merge($lines, self::icalEvent(
                'event-' . $ev['id'],
                (string) $ev['title'],
                (string) ($ev['venue'] ?? ''),
                (string) $ev['starts_at'],
                $end,
                $uidHost
            ));
        }
        $lines[] = 'END:VCALENDAR';

        header('Content-Type: text/calendar; charset=utf-8');
        header('Content-Disposition: inline; filename="wndrs-' . $user['id'] . '.ics"');
        echo implode("\r\n", $lines);
        exit;
    }

    /** @return list<string> */
    private static function icalEvent(string $id, string $summary, string $location, string $start, string $end, string $host): array
    {
        return [
            'BEGIN:VEVENT',
            'UID:' . $id . '@' . $host,
            'DTSTAMP:' . gmdate('Ymd\THis\Z'),
            'DTSTART:' . self::icalDt($start),
            'DTEND:' . self::icalDt($end),
            'SUMMARY:' . self::icalEscape($summary),
            'LOCATION:' . self::icalEscape($location),
            'END:VEVENT',
        ];
    }

    private static function icalDt(string $local): string
    {
        $ts = strtotime($local);
        if ($ts === false) {
            return gmdate('Ymd\THis\Z');
        }
        return gmdate('Ymd\THis\Z', $ts);
    }

    private static function icalEscape(string $text): string
    {
        return str_replace(["\r", "\n", ',', ';'], ['', '\\n', '\\,', '\\;'], $text);
    }

    public static function membersJobApply(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        if (!Rbac::can($user['roles'], 'jobs.apply') && !Rbac::can($user['roles'], '*')) {
            http_response_code(403);
            echo 'Keine Berechtigung zum Bewerben.';
            return;
        }
        $jobId = $_POST['job_id'] ?? '';
        $note = trim($_POST['note'] ?? '');
        $db = Db::pdo();
        $job = $db->prepare("SELECT id, title, author_id, status FROM job_posts WHERE id = ?");
        $job->execute([$jobId]);
        $post = $job->fetch();
        if (!$post || $post['status'] !== 'open') {
            flash('error', 'Job nicht offen.');
            redirect('/members/jobs');
        }
        if ($post['author_id'] === $user['id']) {
            flash('error', 'Eigene Anzeige.');
            redirect('/members/jobs');
        }
        $dup = $db->prepare('SELECT id FROM job_applications WHERE job_id = ? AND user_id = ?');
        $dup->execute([$jobId, $user['id']]);
        if ($dup->fetchColumn()) {
            flash('error', 'Bereits beworben.');
            redirect('/members/jobs');
        }
        $id = uuid();
        $db->prepare('INSERT INTO job_applications (id, job_id, user_id, status, note) VALUES (?,?,?,?,?)')
            ->execute([$id, $jobId, $user['id'], 'applied', $note]);
        notify(
            $db,
            (string) $post['author_id'],
            'job.application',
            'Neue Bewerbung: ' . $post['title'],
            $user['display_name'] . ($note !== '' ? ' — ' . $note : ''),
            '/members/jobs'
        );
        audit($db, $user['id'], 'job.apply', 'job_application', $id, ['job_id' => $jobId]);
        flash('success', 'Bewerbung gesendet.');
        redirect('/members/jobs');
    }

    public static function membersCertificatesSave(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $db = Db::pdo();
        $action = $_POST['form_action'] ?? 'add';
        if ($action === 'delete') {
            $id = $_POST['id'] ?? '';
            $db->prepare('DELETE FROM certificates WHERE id = ? AND user_id = ?')->execute([$id, $user['id']]);
            audit($db, $user['id'], 'certificate.delete', 'certificate', $id);
            flash('success', 'Zertifikat entfernt.');
            redirect('/members/profil');
        }
        $name = trim($_POST['name'] ?? '');
        if ($name === '') {
            flash('error', 'Name fehlt.');
            redirect('/members/profil');
        }
        $id = uuid();
        $db->prepare(
            'INSERT INTO certificates (id, user_id, name, issuer, issued_at, expires_at, reminder_days, note) VALUES (?,?,?,?,?,?,?,?)'
        )->execute([
            $id,
            $user['id'],
            $name,
            trim($_POST['issuer'] ?? ''),
            ($_POST['issued_at'] ?? '') ?: null,
            ($_POST['expires_at'] ?? '') ?: null,
            (int) ($_POST['reminder_days'] ?? 30),
            trim($_POST['note'] ?? ''),
        ]);
        audit($db, $user['id'], 'certificate.add', 'certificate', $id);
        flash('success', 'Zertifikat hinzugefügt.');
        redirect('/members/profil');
    }

    public static function apiPushSubscribe(): void
    {
        $user = Auth::requireLogin();
        $raw = file_get_contents('php://input');
        $json = $raw !== false && $raw !== '' ? json_decode($raw, true) : null;
        if (!is_array($json)) {
            $json = $_POST;
        }
        $csrf = (string) ($json['_csrf'] ?? $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        if (!hash_equals(csrf_token(), $csrf)) {
            json_response(['ok' => false, 'error' => 'csrf'], 419);
        }
        $endpoint = trim((string) ($json['endpoint'] ?? ''));
        $p256dh = trim((string) ($json['p256dh'] ?? $json['keys']['p256dh'] ?? ''));
        $authKey = trim((string) ($json['auth'] ?? $json['keys']['auth'] ?? ''));
        if ($endpoint === '' || $p256dh === '' || $authKey === '') {
            json_response(['ok' => false, 'error' => 'missing_fields'], 422);
        }
        $db = Db::pdo();
        $existing = $db->prepare('SELECT id FROM push_subscriptions WHERE endpoint = ?');
        $existing->execute([$endpoint]);
        $subId = $existing->fetchColumn();
        $ua = substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 240);
        $device = trim((string) ($json['device_name'] ?? ''));
        if ($subId) {
            $db->prepare(
                'UPDATE push_subscriptions SET user_id = ?, p256dh = ?, auth = ?, device_name = ?, user_agent = ?, last_seen_at = datetime("now") WHERE id = ?'
            )->execute([$user['id'], $p256dh, $authKey, $device, $ua, $subId]);
        } else {
            $subId = uuid();
            $db->prepare(
                'INSERT INTO push_subscriptions (id, user_id, endpoint, p256dh, auth, device_name, user_agent) VALUES (?,?,?,?,?,?,?)'
            )->execute([$subId, $user['id'], $endpoint, $p256dh, $authKey, $device, $ua]);
        }
        audit($db, $user['id'], 'push.subscribe', 'push_subscription', (string) $subId);
        json_response(['ok' => true, 'subscription_id' => $subId]);
    }

    public static function apiPushUnsubscribe(): void
    {
        $user = Auth::requireLogin();
        $raw = file_get_contents('php://input');
        $json = $raw !== false && $raw !== '' ? json_decode($raw, true) : null;
        if (!is_array($json)) {
            $json = $_POST;
        }
        $csrf = (string) ($json['_csrf'] ?? $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        if (!hash_equals(csrf_token(), $csrf)) {
            json_response(['ok' => false, 'error' => 'csrf'], 419);
        }
        $endpoint = trim((string) ($json['endpoint'] ?? ''));
        $db = Db::pdo();
        if ($endpoint !== '') {
            $db->prepare('DELETE FROM push_subscriptions WHERE endpoint = ? AND user_id = ?')->execute([$endpoint, $user['id']]);
        } else {
            $id = $json['id'] ?? '';
            $db->prepare('DELETE FROM push_subscriptions WHERE id = ? AND user_id = ?')->execute([$id, $user['id']]);
        }
        audit($db, $user['id'], 'push.unsubscribe', 'push_subscription', $endpoint);
        json_response(['ok' => true]);
    }

    public static function apiNotificationsUnread(): void
    {
        $user = Auth::requireLogin();
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND read_at IS NULL');
        $stmt->execute([$user['id']]);
        $count = (int) $stmt->fetchColumn();
        json_response(['ok' => true, 'unread' => $count]);
    }

    public static function adminShifts(): void
    {
        $user = Auth::requireAdmin();
        $db = Db::pdo();
        $events = $db->query("SELECT id, title, starts_at, venue FROM events ORDER BY starts_at DESC LIMIT 100")->fetchAll();
        $members = $db->query('SELECT id, display_name FROM users WHERE is_active = 1 ORDER BY display_name')->fetchAll();
        $shifts = $db->query(
            "SELECT s.*, e.title AS event_title,
                    (SELECT COUNT(*) FROM shift_assignments sa WHERE sa.shift_id = s.id) AS assigned
             FROM shifts s JOIN events e ON e.id = s.event_id ORDER BY s.starts_at DESC LIMIT 80"
        )->fetchAll();
        layout('admin', 'admin/shifts', compact('user', 'events', 'members', 'shifts'));
    }

    public static function adminShiftsSave(): void
    {
        $user = Auth::requireAdmin();
        require_csrf();
        $db = Db::pdo();
        $action = $_POST['form_action'] ?? 'create_shift';
        if ($action === 'assign') {
            $shiftId = $_POST['shift_id'] ?? '';
            $memberId = $_POST['user_id'] ?? '';
            if ($shiftId === '' || $memberId === '') {
                flash('error', 'Schicht oder Mitglied fehlt.');
                redirect('/admin/schichten');
            }
            $id = uuid();
            try {
                $db->prepare('INSERT INTO shift_assignments (id, shift_id, user_id, status) VALUES (?,?,?,?)')
                    ->execute([$id, $shiftId, $memberId, 'invited']);
                notify($db, $memberId, 'shift.invite', 'Neue Schicht', 'Du wurdest einer Schicht zugewiesen.', '/members/schichten');
                audit($db, $user['id'], 'shift.assign', 'shift_assignment', $id);
                flash('success', 'Mitglied zugewiesen.');
            } catch (Throwable) {
                flash('error', 'Bereits zugewiesen.');
            }
            redirect('/admin/schichten');
        }
        $eventId = $_POST['event_id'] ?? '';
        $starts = trim($_POST['starts_at'] ?? '');
        $ends = trim($_POST['ends_at'] ?? '');
        if ($eventId === '' || $starts === '' || $ends === '') {
            flash('error', 'Event, Start und Ende sind Pflicht.');
            redirect('/admin/schichten');
        }
        $startsDb = str_replace('T', ' ', $starts);
        $endsDb = str_replace('T', ' ', $ends);
        if (strlen($startsDb) === 16) {
            $startsDb .= ':00';
        }
        if (strlen($endsDb) === 16) {
            $endsDb .= ':00';
        }
        $role = trim($_POST['role'] ?? 'crew');
        $slots = max(1, (int) ($_POST['slots'] ?? 1));
        $projectId = ($_POST['project_id'] ?? '') ?: null;
        $note = trim($_POST['note'] ?? '');
        $id = uuid();
        $db->prepare(
            'INSERT INTO shifts (id, event_id, project_id, role, starts_at, ends_at, slots, note) VALUES (?,?,?,?,?,?,?,?)'
        )->execute([$id, $eventId, $projectId, $role, $startsDb, $endsDb, $slots, $note]);
        $assignUser = $_POST['assign_user_id'] ?? '';
        if ($assignUser !== '') {
            $aid = uuid();
            $db->prepare('INSERT INTO shift_assignments (id, shift_id, user_id, status) VALUES (?,?,?,?)')
                ->execute([$aid, $id, $assignUser, 'invited']);
            notify($db, $assignUser, 'shift.invite', 'Neue Schicht', $role . ' — bitte zusagen.', '/members/schichten');
        }
        audit($db, $user['id'], 'shift.create', 'shift', $id, ['event_id' => $eventId]);
        flash('success', 'Schicht angelegt.');
        redirect('/admin/schichten');
    }

    public static function membersDataExport(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $profile = $db->prepare('SELECT * FROM profiles WHERE user_id = ?');
        $profile->execute([$user['id']]);
        $prof = $profile->fetch() ?: [];
        $membership = $db->prepare('SELECT * FROM memberships WHERE user_id = ?');
        $membership->execute([$user['id']]);
        $mem = $membership->fetch() ?: [];
        $times = $db->prepare('SELECT * FROM time_entries WHERE user_id = ? ORDER BY work_date DESC');
        $times->execute([$user['id']]);
        $timeRows = $times->fetchAll();
        $apps = $db->prepare('SELECT ja.*, j.title AS job_title FROM job_applications ja JOIN job_posts j ON j.id = ja.job_id WHERE ja.user_id = ?');
        $apps->execute([$user['id']]);
        $jobApps = $apps->fetchAll();
        $export = [
            'exported_at' => date('c'),
            'user' => [
                'id' => $user['id'],
                'email' => $user['email'],
                'display_name' => $user['display_name'],
                'created_at' => $user['created_at'] ?? null,
            ],
            'profile' => $prof,
            'membership' => $mem,
            'time_entries' => $timeRows,
            'job_applications' => $jobApps,
        ];
        audit($db, $user['id'], 'gdpr.export', 'user', $user['id']);
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="wndrs-daten-' . $user['id'] . '.json"');
        echo json_encode($export, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    public static function membersAccountDelete(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $confirm = $_POST['confirm'] ?? '';
        if ($confirm !== 'LOESCHEN') {
            flash('error', 'Bestätigung fehlt (LOESCHEN eingeben).');
            redirect('/members/profil');
        }
        $db = Db::pdo();
        $db->prepare('UPDATE users SET is_active = 0, updated_at = datetime("now") WHERE id = ?')->execute([$user['id']]);
        $db->prepare("UPDATE memberships SET status = 'former' WHERE user_id = ?")->execute([$user['id']]);
        audit($db, $user['id'], 'gdpr.account_deactivate', 'user', $user['id']);
        Auth::logout();
        flash('success', 'Konto deaktiviert.');
        redirect('/');
    }

    public static function seedPlatform(PDO $db): array
    {
        $inserted = ['time_activity_types' => 0, 'feature_flags' => 0];
        $types = [
            ['aufbau', 'Aufbau', 0],
            ['show', 'Show / Spielzeit', 0],
            ['abbau', 'Abbau', 0],
            ['orga', 'Organisation', 0],
            ['proben', 'Proben', 0],
            ['fahrt', 'Fahrt / Anreise', 0],
        ];
        foreach ($types as [$code, $label, $pct]) {
            $stmt = $db->prepare('INSERT OR IGNORE INTO time_activity_types (id, code, label, surcharge_pct) VALUES (?,?,?,?)');
            $stmt->execute([uuid(), $code, $label, $pct]);
            if ($stmt->rowCount() > 0) {
                ++$inserted['time_activity_types'];
            }
        }
        $flag = $db->prepare('INSERT OR IGNORE INTO feature_flags (key, enabled, note) VALUES (?,?,?)');
        $flag->execute(['platform.ops_v1', 1, 'Seed: Plattform-Ops aktiviert']);
        if ($flag->rowCount() > 0) {
            ++$inserted['feature_flags'];
        }
        return $inserted;
    }
}
