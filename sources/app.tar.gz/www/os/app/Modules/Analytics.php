<?php
declare(strict_types=1);

final class Analytics
{
    public static function adminIndex(): void
    {
        $user = Auth::requirePerm('cms.publish');
        $db = Db::pdo();
        $settings = \Analytics\Store::settings($db);
        $site = \Analytics\Store::activeSite($db);
        $cfg = \Analytics\Store::loadCollectorConfig($site);
        $conn = \Analytics\Store::collectorPdo($site);
        [$d0, $d1, $rangeLabel] = self::range($site, $cfg);

        $rep = null;
        $charts = [];
        $kpis = [];
        $rows = [];
        if ($conn !== null && $site !== null) {
            $siteId = (string) ($cfg['site_id'] ?? $site['sid']);
            $tz = new DateTimeZone((string) ($site['tz'] ?? $cfg['tz'] ?? Config::get('timezone', 'Europe/Berlin')));
            $rep = \Analytics\Report::build($conn, $siteId, $tz, $d0, $d1, true);
            $span = $d1->diff($d0)->days + 1;
            $prev = \Analytics\Report::build(
                $conn,
                $siteId,
                $tz,
                $d0->sub(new DateInterval('P' . $span . 'D')),
                $d0->sub(new DateInterval('P1D')),
                false
            );
            $kpis = self::kpis($rep, $prev);
            $vis = self::series($rep, 'vis');
            $pv = self::series($rep, 'pv');
            $charts = [
                'daily' => \Analytics\Charts::daily($rep['days'], $vis, $pv),
                'hours' => \Analytics\Charts::bars(array_map(static fn(int $h): string => sprintf('%02d', $h), range(0, 23)), $rep['hours'] ?? []),
                'channels' => \Analytics\Charts::shareBars($rep['channels'] ?? []),
            ];
            foreach ($rep['days'] as $day) {
                $key = $day->format('Y-m-d');
                $rows[] = ['day' => $key] + ($rep['per'][$key] ?? []);
            }
            $rows = array_reverse($rows);
        }

        $warnings = self::warnings($settings, $site, $cfg, $conn);
        $pythonUrl = (string) $settings['analytics.python_url'];
        layout('admin', 'admin/analytics', compact('user', 'settings', 'site', 'cfg', 'rep', 'charts', 'kpis', 'warnings', 'pythonUrl', 'd0', 'd1', 'rangeLabel', 'rows'));
    }

    public static function adminSettingsSave(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $db = Db::pdo();
        $site = self::siteById($db, (int) ($_POST['active_site_id'] ?? 0));
        $pythonUrl = trim((string) ($_POST['python_url'] ?? ''));
        if ($pythonUrl !== '' && !preg_match('#^https?://#i', $pythonUrl)) {
            flash('error', 'Python-URL muss leer sein oder mit http(s):// beginnen.');
            redirect('/admin/analytics');
        }

        self::saveSetting($db, 'analytics.enabled', !empty($_POST['enabled']) ? '1' : '0');
        self::saveSetting($db, 'analytics.python_url', $pythonUrl);
        if ($site !== null) {
            self::saveSetting($db, 'analytics.active_site_id', (string) $site['id']);
            \Analytics\Store::writeCollectorConfigOverrides($site, [
                'visitor_mode' => in_array(($_POST['visitor_mode'] ?? ''), ['hash', 'off'], true) ? $_POST['visitor_mode'] : 'hash',
                'geo_enabled' => !empty($_POST['geo_enabled']),
                'origins' => self::originLines((string) ($_POST['origins'] ?? '')),
            ]);
        }

        audit($db, $user['id'], 'analytics.settings_save', 'app_settings', '', ['site_id' => $site['id'] ?? null]);
        flash('success', 'Besucher-Einstellungen gespeichert.');
        redirect('/admin/analytics');
    }

    public static function adminSites(): void
    {
        $user = Auth::requirePerm('cms.publish');
        $db = Db::pdo();
        $settings = \Analytics\Store::settings($db);
        $sites = $db->query('SELECT * FROM analytics_sites ORDER BY active DESC, name')->fetchAll();
        layout('admin', 'admin/analytics_sites', compact('user', 'settings', 'sites'));
    }

    public static function adminSitesSave(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $db = Db::pdo();
        $activeId = (int) ($_POST['active_site_id'] ?? 0);
        if (self::siteById($db, $activeId) !== null) {
            self::saveSetting($db, 'analytics.active_site_id', (string) $activeId);
        }

        $name = trim((string) ($_POST['name'] ?? ''));
        $domain = strtolower(trim((string) ($_POST['domain'] ?? '')));
        $sid = strtolower(trim((string) ($_POST['sid'] ?? '')));
        if ($name !== '' && $domain !== '' && preg_match('/^[a-z0-9_-]{2,40}$/', $sid)) {
            $configPath = \Analytics\Store::normalizeCollectorConfigPath((string) ($_POST['config_path'] ?? ''));
            if ($configPath === null) {
                flash('error', 'Config-Pfad muss unter data/analytics/ liegen.');
                redirect('/admin/analytics/sites');
            }
            $db->prepare('INSERT OR IGNORE INTO analytics_sites (name, domain, endpoint, sid, config_path, tz, active) VALUES (?,?,?,?,?,?,0)')
                ->execute([
                    $name,
                    $domain,
                    trim((string) ($_POST['endpoint'] ?? '')) ?: '/a/x.php',
                    $sid,
                    $configPath,
                    trim((string) ($_POST['tz'] ?? 'Europe/Berlin')) ?: 'Europe/Berlin',
                ]);
        }

        audit($db, $user['id'], 'analytics.sites_save', 'analytics_sites', '', ['active_site_id' => $activeId]);
        flash('success', 'Besucher-Sites gespeichert.');
        redirect('/admin/analytics/sites');
    }

    public static function adminExportCsv(): void
    {
        $user = Auth::requirePerm('cms.publish');
        $db = Db::pdo();
        $site = \Analytics\Store::activeSite($db);
        $cfg = \Analytics\Store::loadCollectorConfig($site);
        $conn = \Analytics\Store::collectorPdo($site);
        if ($site === null || $conn === null) {
            http_response_code(404);
            echo 'Keine Analytics-Daten verfügbar.';
            return;
        }

        $kind = (string) ($_GET['t'] ?? 'days');
        if (!in_array($kind, ['pages', 'days', 'sources', 'countries'], true)) {
            $kind = 'days';
        }

        [$d0, $d1] = self::range($site, $cfg);
        $tz = new DateTimeZone((string) ($site['tz'] ?? $cfg['tz'] ?? Config::get('timezone', 'Europe/Berlin')));
        $rep = \Analytics\Report::build($conn, (string) ($cfg['site_id'] ?? $site['sid']), $tz, $d0, $d1, true);

        $slug = substr(preg_replace('/[^\w-]+/', '_', (string) $site['name']), 0, 40);
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $slug . '-' . $kind . '.csv"');
        audit($db, $user['id'], 'analytics.export', 'analytics', $kind);

        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");

        if ($kind === 'pages') {
            self::csvPutRow($out, ['Pfad', 'Aufrufe', 'Einstiege', 'Ausstiege', 'Ausstiegsrate', 'Verweildauer_s']);
            foreach ($rep['pages'] as $page) {
                self::csvPutRow($out, [
                    $page['path'],
                    $page['pv'],
                    $page['ent'],
                    $page['exits'],
                    $page['exit_rate'] === null ? '' : round((float) $page['exit_rate'], 3),
                    $page['avg'] === null ? '' : round((float) $page['avg'], 1),
                ]);
            }
        } elseif ($kind === 'sources') {
            self::csvPutRow($out, ['Quelle', 'Kanal', 'Einstiege']);
            foreach ($rep['sources'] as $source) {
                self::csvPutRow($out, [$source['ref'], $source['channel'], $source['n']]);
            }
        } elseif ($kind === 'countries') {
            self::csvPutRow($out, ['Land', 'Aufrufe']);
            foreach ($rep['countries'] as $country) {
                self::csvPutRow($out, [$country[0], $country[1]]);
            }
        } else {
            self::csvPutRow($out, ['Datum', 'Tagesbesucher', 'Aufrufe', 'Einstiege', 'Verweildauer_s_Summe', 'Messungen']);
            foreach ($rep['days'] as $day) {
                $p = $rep['per'][$day->format('Y-m-d')] ?? ['vis' => 0, 'pv' => 0, 'ent' => 0, 'dws' => 0, 'dwn' => 0];
                self::csvPutRow($out, [$day->format('Y-m-d'), $p['vis'], $p['pv'], $p['ent'], $p['dws'], $p['dwn']]);
            }
        }
    }

    private static function csvSafe(string $v): string
    {
        if ($v !== '' && in_array($v[0], ['=', '+', '-', '@'], true)) {
            $v = "'" . $v;
        }

        return $v;
    }

    /** @param list<mixed> $row */
    private static function csvPutRow($out, array $row): void
    {
        $cells = [];
        foreach ($row as $cell) {
            if (is_string($cell)) {
                $cells[] = self::csvSafe($cell);
            } elseif (is_int($cell) || is_float($cell)) {
                $cells[] = (string) $cell;
            } else {
                $cells[] = self::csvSafe((string) $cell);
            }
        }
        fputcsv($out, $cells, ';');
    }

    /** @return array{0:DateTimeImmutable,1:DateTimeImmutable,2?:string} */
    private static function range(?array $site, ?array $cfg): array
    {
        $tz = new DateTimeZone((string) ($site['tz'] ?? $cfg['tz'] ?? Config::get('timezone', 'Europe/Berlin')));
        $today = new DateTimeImmutable('today', $tz);
        $label = '30';
        if (!empty($_GET['from']) && !empty($_GET['to'])) {
            try {
                $d0 = new DateTimeImmutable((string) $_GET['from'], $tz);
                $d1 = new DateTimeImmutable((string) $_GET['to'], $tz);
                $label = 'custom';
            } catch (Throwable) {
                $d0 = $today->sub(new DateInterval('P29D'));
                $d1 = $today;
            }
        } else {
            $r = (int) ($_GET['r'] ?? 30);
            $r = in_array($r, [7, 30, 90, 365], true) ? $r : 30;
            $d0 = $today->sub(new DateInterval('P' . ($r - 1) . 'D'));
            $d1 = $today;
            $label = (string) $r;
        }
        if ($d1 > $today) {
            $d1 = $today;
        }
        if ($d0 > $d1 || $d0->diff($d1)->days > 400) {
            $d0 = $today->sub(new DateInterval('P29D'));
            $d1 = $today;
            $label = '30';
        }
        return [$d0, $d1, $label];
    }

    private static function saveSetting(PDO $db, string $key, string $value): void
    {
        $db->prepare('INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?,?,datetime("now"))')
            ->execute([$key, $value]);
    }

    private static function siteById(PDO $db, int $id): ?array
    {
        if ($id <= 0) {
            return null;
        }
        $stmt = $db->prepare('SELECT * FROM analytics_sites WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    private static function originLines(string $raw): array
    {
        $lines = preg_split('/\R+/', $raw) ?: [];
        $origins = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '' && preg_match('#^https?://#i', $line)) {
                $origins[] = $line;
            }
        }
        return array_values(array_unique($origins));
    }

    private static function series(array $rep, string $key): array
    {
        return array_map(static fn(DateTimeImmutable $day): int => (int) ($rep['per'][$day->format('Y-m-d')][$key] ?? 0), $rep['days']);
    }

    private static function kpis(array $rep, array $prev): array
    {
        return [
            ['title' => 'Tagesbesucher (Summe)', 'value' => self::num((int) $rep['tot']['vis']), 'delta' => \Analytics\Report::delta($rep['tot']['vis'], $prev['tot']['vis'] ?? null)],
            ['title' => 'Seitenaufrufe', 'value' => self::num((int) $rep['tot']['pv']), 'delta' => \Analytics\Report::delta($rep['tot']['pv'], $prev['tot']['pv'] ?? null)],
            ['title' => 'Einstiege (ca. Besuche)', 'value' => self::num((int) $rep['tot']['ent']), 'delta' => \Analytics\Report::delta($rep['tot']['ent'], $prev['tot']['ent'] ?? null)],
            ['title' => 'Durchschnitt pro Seite', 'value' => self::dur($rep['tot']['avg'] ?? null), 'delta' => \Analytics\Report::delta($rep['tot']['avg'] ?? null, $prev['tot']['avg'] ?? null)],
        ];
    }

    private static function warnings(array $settings, ?array $site, ?array $cfg, ?PDO $conn): array
    {
        $warnings = [];
        if ($settings['analytics.enabled'] !== '1') {
            $warnings[] = 'Analytics ist in den App-Settings deaktiviert.';
        }
        if ($site === null) {
            $warnings[] = 'Keine aktive Analytics-Site gefunden.';
        }
        if ($cfg === null) {
            $warnings[] = 'Collector-Konfiguration fehlt oder ist nicht lesbar.';
        }
        if ($settings['analytics.enabled'] === '1' && $cfg !== null) {
            $siteKey = (string) ($cfg['site_key'] ?? '');
            if ($siteKey === '' || str_starts_with($siteKey, 'CHANGE_ME')) {
                $warnings[] = 'Analytics ist aktiv, aber der site_key fehlt oder ist noch ein CHANGE_ME-Platzhalter.';
            }
        }
        if ($cfg !== null && !empty($cfg['geo_enabled'])) {
            $geoDb = (string) ($cfg['geo_db'] ?? 'geo/GeoLite2-Country.mmdb');
            $geoPath = $geoDb;
            if ($geoDb !== '' && $geoDb[0] !== '/') {
                $configDir = \Analytics\Store::collectorConfigDir($site);
                $geoPath = ($configDir ?? dirname(__DIR__, 2) . '/data/analytics') . '/' . $geoDb;
            }
            if ($geoDb === '' || !is_file($geoPath)) {
                $warnings[] = 'Geo-Auswertung ist aktiv, aber die .mmdb-Datenbank fehlt.';
            }
        }
        if ($conn === null) {
            $warnings[] = 'Collector-Datenbank ist noch nicht verfügbar.';
        }
        return $warnings;
    }

    private static function num(int $n): string
    {
        return number_format($n, 0, '', '.');
    }

    private static function dur(mixed $seconds): string
    {
        if ($seconds === null) {
            return '–';
        }
        $seconds = (int) round((float) $seconds);
        return $seconds >= 60 ? intdiv($seconds, 60) . ':' . sprintf('%02d', $seconds % 60) . ' min' : $seconds . ' s';
    }
}
