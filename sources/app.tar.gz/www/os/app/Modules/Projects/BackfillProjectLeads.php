<?php
declare(strict_types=1);

/**
 * BackfillProjectLeads — Altbestand-Projekte ohne project_memberships reparieren.
 *
 * Neue Projekte (Router::membersProjectCreate / Projects::membersProjectFromTemplate)
 * legen den Ersteller als lead an. Ältere Zeilen haben oft nur projects.lead_id
 * und keinen Membership-Eintrag — dadurch sperrt ProjectPolicy Nicht-Admins aus.
 *
 * Nutzung (CLI, idempotent):
 *   php site/scripts/backfill_project_leads.php
 */
final class BackfillProjectLeads
{
    /**
     * Für jedes Projekt ohne Eintrag in project_memberships einen lead anlegen.
     *
     * Quelle: projects.lead_id (falls Nutzer existiert), sonst erster aktiver
     * Admin/Superadmin. Bereits vorhandene Memberships bleiben unberührt.
     *
     * @return array{
     *   scanned: int,
     *   created: int,
     *   skipped: int,
     *   warnings: list<string>
     * }
     */
    public static function run(PDO $db): array
    {
        $stats = [
            'scanned' => 0,
            'created' => 0,
            'skipped' => 0,
            'warnings' => [],
        ];

        $projects = $db->query('SELECT id, title, lead_id FROM projects ORDER BY created_at, id')->fetchAll();
        $fallbackAdminId = null;

        foreach ($projects as $project) {
            $stats['scanned']++;
            $projectId = (string) $project['id'];

            $exists = $db->prepare('SELECT 1 FROM project_memberships WHERE project_id = ? LIMIT 1');
            $exists->execute([$projectId]);
            if ($exists->fetchColumn()) {
                $stats['skipped']++;
                continue;
            }

            $leadUserId = self::resolveLeadUserId($db, $project, $fallbackAdminId, $stats['warnings']);
            if ($leadUserId === null) {
                $stats['warnings'][] = sprintf(
                    'Projekt %s (%s): kein lead_id und kein Admin/Superadmin — übersprungen.',
                    $projectId,
                    (string) ($project['title'] ?? '')
                );
                $stats['skipped']++;
                continue;
            }

            // Idempotent auch bei parallelem Lauf / UNIQUE(project_id, user_id).
            $ins = $db->prepare(
                'INSERT OR IGNORE INTO project_memberships (id, project_id, user_id, role) VALUES (?,?,?,?)'
            );
            $ins->execute([uuid(), $projectId, $leadUserId, 'lead']);
            if ($ins->rowCount() > 0) {
                $stats['created']++;
            } else {
                // Zwischen SELECT und INSERT hat jemand nachgezogen — als übersprungen zählen.
                $stats['skipped']++;
            }
        }

        return $stats;
    }

    /**
     * @param array<string, mixed> $project
     * @param list<string> $warnings
     */
    private static function resolveLeadUserId(PDO $db, array $project, ?string &$fallbackAdminId, array &$warnings): ?string
    {
        $leadId = trim((string) ($project['lead_id'] ?? ''));
        if ($leadId !== '') {
            $user = $db->prepare('SELECT id FROM users WHERE id = ?');
            $user->execute([$leadId]);
            if ($user->fetchColumn()) {
                return $leadId;
            }
            $warnings[] = sprintf(
                'Projekt %s: lead_id=%s existiert nicht — Admin-Fallback.',
                (string) $project['id'],
                $leadId
            );
        } else {
            $warnings[] = sprintf(
                'Projekt %s (%s): kein lead_id — Admin-Fallback.',
                (string) $project['id'],
                (string) ($project['title'] ?? '')
            );
        }

        if ($fallbackAdminId === null) {
            $fallbackAdminId = self::firstAdminUserId($db);
        }
        return $fallbackAdminId;
    }

    /** Erster aktiver Superadmin, sonst aktiver Admin. */
    private static function firstAdminUserId(PDO $db): ?string
    {
        $stmt = $db->query(
            "SELECT u.id
             FROM users u
             JOIN role_assignments ra ON ra.user_id = u.id
             WHERE u.is_active = 1 AND ra.role IN ('superadmin', 'admin')
             ORDER BY CASE ra.role WHEN 'superadmin' THEN 0 ELSE 1 END, u.created_at, u.id
             LIMIT 1"
        );
        $id = $stmt->fetchColumn();
        return $id === false ? null : (string) $id;
    }
}
