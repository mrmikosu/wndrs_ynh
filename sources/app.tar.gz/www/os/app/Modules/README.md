# Modules

Feature modules live here as the monolith grows. Core infrastructure stays in `app/Core/`.
Existing routes remain in `Router.php` during the transition; new domain logic should
prefer classes under `app/Modules/<name>/`.
