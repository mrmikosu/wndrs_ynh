<?php
declare(strict_types=1);

/**
 * DecideExpense — Service für die Auslagenfreigabe (Phase 2).
 *
 * Regeln (vom Nutzer freigegeben):
 * - Grundrecht 'finance.approve' erforderlich.
 * - Bei Projekt-Auslagen zusätzlich Bereichszuständigkeit:
 *   ProjectPolicy::canManage() für das verknüpfte Projekt
 *   (global 'projects.manage'/'*' oder Lead-Rolle in diesem Projekt).
 * - Keine Selbstfreigabe — auch nicht für Admins.
 * - Entscheidungen nur aus status = 'submitted' (approved/rejected);
 *   'freigegeben' (approved) und 'ausgezahlt' (paid) sind getrennte Zustände:
 *   paid ist nur aus approved erreichbar, kein Sprung submitted → paid.
 * - Ablehnung erfordert eine Begründung.
 * - Atomarer Wechsel (WHERE status = erwartet + rowCount); 0 Zeilen = 409.
 * - Audit + Outbox in derselben Transaktion.
 */
final class DecideExpense
{
    /** Erlaubte Zielzustände einer Entscheidung/Auszahlungsmarkierung. */
    public const DECISIONS = ['approved', 'rejected', 'paid'];

    /** Deutsche Zustandstexte für die Oberfläche. */
    public const STATUS_LABELS = [
        'submitted' => 'eingereicht',
        'approved' => 'freigegeben',
        'rejected' => 'abgelehnt',
        'paid' => 'ausgezahlt',
    ];

    public function __construct(private readonly PDO $db)
    {
    }

    /**
     * @return array<string, mixed> die aktualisierte Auslage
     */
    public function decide(Actor $actor, string $expenseId, string $decision, string $note = ''): array
    {
        if (!$actor->active || !$actor->can('finance.approve')) {
            throw new ApprovalForbidden('Keine Berechtigung zur Auslagenfreigabe.');
        }
        if (!in_array($decision, self::DECISIONS, true)) {
            throw new ApprovalValidation('Ungültige Entscheidung.');
        }
        $note = trim($note);
        if ($decision === 'rejected' && $note === '') {
            throw new ApprovalValidation('Ablehnung erfordert eine Begründung.');
        }

        $repo = new ExpenseRepository($this->db);
        $expense = $repo->find($expenseId);
        if ($expense === null) {
            throw new ApprovalNotFound('Auslage nicht gefunden.');
        }
        // Keine Selbstfreigabe — gilt auch für Admin- und Finanzrollen.
        if ((string) $expense['submitter_id'] === $actor->id) {
            throw new ApprovalForbidden('Selbstfreigabe ist nicht erlaubt.');
        }
        // Bereichszuständigkeit bei projektverknüpften Auslagen.
        $projectId = (string) ($expense['project_id'] ?? '');
        if ($projectId !== '') {
            $project = $this->findProject($projectId);
            if ($project === null || !ProjectPolicy::canManage($actor, $project, $this->db)) {
                throw new ApprovalForbidden('Keine Zuständigkeit für das Projekt dieser Auslage.');
            }
        }

        $expected = $decision === 'paid' ? 'approved' : 'submitted';

        $this->db->beginTransaction();
        try {
            $changed = $repo->applyDecision($expenseId, $expected, $decision, $actor->id, $note);
            if ($changed === 0) {
                throw new ApprovalConflict(
                    'Auslage wurde bereits entschieden oder hat einen anderen Status (erwartet: „'
                    . (self::STATUS_LABELS[$expected] ?? $expected) . '“).'
                );
            }
            audit($this->db, $actor->id, 'expense.' . $decision, 'expense', $expenseId, ['note' => $note]);
            (new Outbox($this->db))->append('expense.decision', [
                'expense_id' => $expenseId,
                'decision' => $decision,
                'decided_by' => $actor->id,
                'submitter_id' => (string) $expense['submitter_id'],
                'amount_cents' => (int) $expense['amount_cents'],
                'note' => $note,
            ]);
            $this->db->commit();
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }

        return $repo->find($expenseId) ?? $expense;
    }

    /** @return array<string, mixed>|null */
    private function findProject(string $projectId): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM projects WHERE id = ?');
        $stmt->execute([$projectId]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }
}
