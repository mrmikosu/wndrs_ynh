<?php
declare(strict_types=1);

/**
 * ExpenseRepository — Datenzugriff für Auslagen.
 * Der atomare Statuswechsel passiert ausschließlich über applyDecision()
 * (UPDATE ... WHERE id = ? AND status = ? + rowCount).
 */
final class ExpenseRepository
{
    public function __construct(private readonly PDO $db)
    {
    }

    /** @return array<string, mixed>|null */
    public function find(string $expenseId): ?array
    {
        if ($expenseId === '') {
            return null;
        }
        $stmt = $this->db->prepare('SELECT * FROM expenses WHERE id = ?');
        $stmt->execute([$expenseId]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    /**
     * Atomarer Statuswechsel mit Vorbedingung.
     *
     * @return int Anzahl geänderter Zeilen (0 = Vorbedingung nicht erfüllt → Konflikt)
     */
    public function applyDecision(string $expenseId, string $expectedStatus, string $newStatus, string $decidedBy, string $note): int
    {
        $stmt = $this->db->prepare(
            "UPDATE expenses
             SET status = ?, decided_by = ?, decided_at = datetime('now'), decision_note = ?
             WHERE id = ? AND status = ?"
        );
        $stmt->execute([$newStatus, $decidedBy, $note, $expenseId, $expectedStatus]);
        return $stmt->rowCount();
    }
}
