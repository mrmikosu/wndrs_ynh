<?php
declare(strict_types=1);

/**
 * DashboardQuery — persönliches Mitglieder-Dashboard (Phase 4).
 *
 * Alle Daten kommen aus dem berechtigten Datenbereich des Actors:
 * - Einsätze/Rückmeldungen: nur eigene Datensätze.
 * - Projekte/Aufgaben: nur Projekte mit Eintrag in project_memberships
 *   (bzw. alle bei 'projects.manage'/'*'), keine globalen Gesamtlisten.
 * - Zeit-Rückmeldungen nur, wenn der Actor /team überhaupt betreten darf
 *   (team.access), sonst zeigt der Link ins Leere.
 * - Zukunftsfilter überall, wo Termine gezeigt werden (starts_at >= jetzt);
 *   Vergangenes steht nicht dauerhaft oben.
 */
final class DashboardQuery
{
    public function __construct(private readonly PDO $db)
    {
    }

    /** @return array<string, mixed> */
    public function forActor(Actor $actor): array
    {
        return [
            'nextShifts' => $this->nextShifts($actor),
            'feedback' => $this->feedback($actor),
            'projects' => $this->myProjects($actor),
            'joinIn' => [
                'tasks' => $this->openTasks($actor),
                'jobs' => $this->openJobs($actor),
            ],
            'community' => [
                'board' => $this->boardPosts(),
                'news' => $this->publishedNews(),
            ],
            'myTasks' => $this->myTasks($actor),
            'accessibleTasks' => $this->accessibleTasks($actor),
        ];
    }

    /** Nächster Einsatz: eigene ZUSAGEN, nur Zukunft, aufsteigend. @return list<array<string, mixed>> */
    private function nextShifts(Actor $actor): array
    {
        $stmt = $this->db->prepare(
            "SELECT sa.id AS assignment_id, s.starts_at, s.ends_at, s.role,
                    e.title AS event_title, e.venue
             FROM shift_assignments sa
             JOIN shifts s ON s.id = sa.shift_id
             JOIN events e ON e.id = s.event_id
             WHERE sa.user_id = ? AND sa.status = 'accepted'
               AND s.starts_at >= datetime('now')
             ORDER BY s.starts_at ASC
             LIMIT 3"
        );
        $stmt->execute([$actor->id]);
        return $stmt->fetchAll();
    }

    /**
     * Braucht Rückmeldung: offene Schicht-Einladungen, abgelehnte eigene
     * Auslagen (Beleg/Rückfrage) und — nur mit team.access — zurückgewiesene
     * Zeiteinträge. Jeder Eintrag trägt eine konkrete nächste Handlung.
     *
     * @return list<array<string, string>>
     */
    private function feedback(Actor $actor): array
    {
        $items = [];

        $shifts = $this->db->prepare(
            "SELECT sa.id, s.starts_at, s.role, e.title AS event_title
             FROM shift_assignments sa
             JOIN shifts s ON s.id = sa.shift_id
             JOIN events e ON e.id = s.event_id
             WHERE sa.user_id = ? AND sa.status = 'invited'
               AND s.starts_at >= datetime('now')
             ORDER BY s.starts_at ASC
             LIMIT 5"
        );
        $shifts->execute([$actor->id]);
        foreach ($shifts->fetchAll() as $row) {
            $items[] = [
                'kind' => 'Schicht-Einladung',
                'text' => $row['event_title'] . ' (' . $row['role'] . ', ' . $row['starts_at'] . ')',
                'action_label' => 'Jetzt zu- oder absagen',
                'href' => '/members/schichten',
            ];
        }

        $expenses = $this->db->prepare(
            "SELECT id, title, amount_cents, decision_note
             FROM expenses
             WHERE submitter_id = ? AND status = 'rejected'
             ORDER BY decided_at DESC
             LIMIT 5"
        );
        $expenses->execute([$actor->id]);
        foreach ($expenses->fetchAll() as $row) {
            $note = trim((string) ($row['decision_note'] ?? ''));
            $items[] = [
                'kind' => 'Auslage abgelehnt',
                'text' => $row['title'] . ' (' . number_format(((int) $row['amount_cents']) / 100, 2, ',', '.') . ' €)'
                    . ($note !== '' ? ' — Grund: ' . $note : ''),
                'action_label' => 'Beleg prüfen und erneut einreichen',
                'href' => '/members/finanzen',
            ];
        }

        // Zeitrückfragen nur anzeigen, wenn der Actor den Team-Bereich betreten darf.
        if ($actor->can('team.access')) {
            $times = $this->db->prepare(
                "SELECT id, work_date, minutes, note
                 FROM time_entries
                 WHERE user_id = ? AND status = 'rejected'
                 ORDER BY work_date DESC
                 LIMIT 5"
            );
            $times->execute([$actor->id]);
            foreach ($times->fetchAll() as $row) {
                $items[] = [
                    'kind' => 'Zeiteintrag zurückgewiesen',
                    'text' => $row['work_date'] . ' (' . (int) round(((int) $row['minutes']) / 60) . ' h)',
                    'action_label' => 'Eintrag korrigieren und erneut einreichen',
                    'href' => '/team/zeit',
                ];
            }
        }

        return $items;
    }

    /**
     * Meine Projekte (project_memberships) mit nächster Frist (früheste offene
     * Meilenstein-Fälligkeit), eigener nächster offener Aufgabe und Status.
     * Aktive Projekte zuerst, dann nach nächster Frist (nulls zuletzt).
     *
     * @return list<array<string, mixed>>
     */
    private function myProjects(Actor $actor): array
    {
        $stmt = $this->db->prepare(
            "SELECT p.*, pm.role AS my_role
             FROM project_memberships pm
             JOIN projects p ON p.id = pm.project_id
             WHERE pm.user_id = ?
             ORDER BY CASE p.status WHEN 'active' THEN 0 WHEN 'planned' THEN 1 ELSE 2 END, p.title
             LIMIT 20"
        );
        $stmt->execute([$actor->id]);
        $projects = [];
        foreach ($stmt->fetchAll() as $project) {
            $pid = (string) $project['id'];

            $ms = $this->db->prepare(
                "SELECT title, due_at FROM project_milestones
                 WHERE project_id = ? AND status = 'open' AND due_at IS NOT NULL AND due_at != ''
                 ORDER BY due_at ASC LIMIT 1"
            );
            $ms->execute([$pid]);
            $milestone = $ms->fetch() ?: null;

            $task = $this->db->prepare(
                "SELECT id, title, status, due_at FROM tasks
                 WHERE project_id = ? AND assignee_id = ? AND status != 'done'
                 ORDER BY (due_at IS NULL OR due_at = ''), due_at ASC LIMIT 1"
            );
            $task->execute([$pid, $actor->id]);
            $nextTask = $task->fetch() ?: null;

            $dueAt = $milestone !== null ? (string) $milestone['due_at'] : null;
            $projects[] = [
                'id' => $pid,
                'title' => (string) $project['title'],
                'status' => (string) $project['status'],
                'my_role' => (string) $project['my_role'],
                'next_deadline' => $dueAt,
                'deadline_label' => $milestone !== null ? (string) $milestone['title'] : null,
                'deadline_overdue' => $dueAt !== null && $dueAt < date('Y-m-d H:i:s'),
                'my_next_task' => $nextTask,
            ];
        }
        // Aktive zuerst, dann nächste Frist (ohne Frist zuletzt).
        usort($projects, static function (array $a, array $b): int {
            $rank = static fn (string $s): int => $s === 'active' ? 0 : 1;
            if (($c = $rank($a['status']) <=> $rank($b['status'])) !== 0) {
                return $c;
            }
            if ($a['next_deadline'] === null && $b['next_deadline'] === null) {
                return strcmp($a['title'], $b['title']);
            }
            if ($a['next_deadline'] === null) {
                return 1;
            }
            if ($b['next_deadline'] === null) {
                return -1;
            }
            return strcmp($a['next_deadline'], $b['next_deadline']);
        });
        return array_slice($projects, 0, 5);
    }

    /** Mitmachen: unzugewiesene offene Aufgaben in Projekten des Actors (bei projects.manage: alle). @return list<array<string, mixed>> */
    private function openTasks(Actor $actor): array
    {
        if (ProjectPolicy::managesAll($actor)) {
            $stmt = $this->db->query(
                "SELECT t.id, t.title, t.due_at, p.id AS project_id, p.title AS project_title
                 FROM tasks t
                 JOIN projects p ON p.id = t.project_id
                 WHERE t.assignee_id IS NULL AND t.status = 'todo'
                   AND p.status NOT IN ('archived', 'paused')
                 ORDER BY (t.due_at IS NULL OR t.due_at = ''), t.due_at ASC
                 LIMIT 5"
            );
            return $stmt->fetchAll();
        }
        $stmt = $this->db->prepare(
            "SELECT t.id, t.title, t.due_at, p.id AS project_id, p.title AS project_title
             FROM tasks t
             JOIN projects p ON p.id = t.project_id
             JOIN project_memberships pm ON pm.project_id = p.id AND pm.user_id = ?
             WHERE t.assignee_id IS NULL AND t.status = 'todo'
               AND p.status NOT IN ('archived', 'paused')
             ORDER BY (t.due_at IS NULL OR t.due_at = ''), t.due_at ASC
             LIMIT 5"
        );
        $stmt->execute([$actor->id]);
        return $stmt->fetchAll();
    }

    /** Mitmachen: offene Jobs (nicht die eigenen). @return list<array<string, mixed>> */
    private function openJobs(Actor $actor): array
    {
        $stmt = $this->db->prepare(
            "SELECT j.id, j.title, j.kind, j.role, j.event_date, j.location
             FROM job_posts j
             WHERE j.status = 'open' AND j.author_id != ?
             ORDER BY j.created_at DESC
             LIMIT 5"
        );
        $stmt->execute([$actor->id]);
        return $stmt->fetchAll();
    }

    /** Aus dem Kollektiv: Mitteilungen (angeheftet zuerst). @return list<array<string, mixed>> */
    private function boardPosts(): array
    {
        return $this->db->query(
            'SELECT b.*, u.display_name FROM board_posts b JOIN users u ON u.id = b.author_id
             ORDER BY b.pinned DESC, b.created_at DESC LIMIT 5'
        )->fetchAll();
    }

    /** Aus dem Kollektiv: veröffentlichte News. @return list<array<string, mixed>> */
    private function publishedNews(): array
    {
        return $this->db->query(
            "SELECT id, title, created_at FROM news_posts
             WHERE status = 'published'
             ORDER BY created_at DESC LIMIT 3"
        )->fetchAll();
    }

    /** Meine Aufgaben: nur mir zugewiesene, offene. @return list<array<string, mixed>> */
    private function myTasks(Actor $actor): array
    {
        $stmt = $this->db->prepare(
            "SELECT t.*, p.title AS project_title
             FROM tasks t
             LEFT JOIN projects p ON p.id = t.project_id
             WHERE t.assignee_id = ? AND t.status != 'done'
             ORDER BY (t.due_at IS NULL OR t.due_at = ''), t.due_at ASC
             LIMIT 10"
        );
        $stmt->execute([$actor->id]);
        return $stmt->fetchAll();
    }

    /**
     * Alle zugänglichen Aufgaben: offene Aufgaben in Projekten des Actors
     * (bei projects.manage/'*': alle Projekte). Aufgaben ohne Projektbezug
     * sind nur bei globaler Verwaltung sichtbar.
     *
     * @return list<array<string, mixed>>
     */
    private function accessibleTasks(Actor $actor): array
    {
        if (ProjectPolicy::managesAll($actor)) {
            $stmt = $this->db->query(
                "SELECT t.*, p.title AS project_title
                 FROM tasks t
                 LEFT JOIN projects p ON p.id = t.project_id
                 WHERE t.status != 'done'
                 ORDER BY (t.due_at IS NULL OR t.due_at = ''), t.due_at ASC
                 LIMIT 10"
            );
            return $stmt->fetchAll();
        }
        $stmt = $this->db->prepare(
            "SELECT t.*, p.title AS project_title
             FROM tasks t
             JOIN projects p ON p.id = t.project_id
             JOIN project_memberships pm ON pm.project_id = p.id AND pm.user_id = ?
             WHERE t.status != 'done'
             ORDER BY (t.due_at IS NULL OR t.due_at = ''), t.due_at ASC
             LIMIT 10"
        );
        $stmt->execute([$actor->id]);
        return $stmt->fetchAll();
    }
}
