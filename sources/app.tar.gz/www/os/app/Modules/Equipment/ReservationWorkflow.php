<?php
declare(strict_types=1);

/**
 * ReservationWorkflow — Equipment-Reservierung nach dem Muster aus Phase 2.
 *
 * Zustände: requested → approved/rejected (Entscheidung, equipment.approve)
 *           approved  → checked_out (Ausgabe quittiert, equipment.approve)
 *           checked_out → returned (Rückgabe quittiert, equipment.approve)
 *
 * Regeln:
 * - Grundrecht 'equipment.approve' für alle Aktionen.
 * - Entscheidungen nur aus 'requested'; Ablehnung erfordert Begründung.
 * - Konflikterkennung: Freigabe nur, wenn keine freigegebene/ausgegebene
 *   Reservierung desselben Equipments den Zeitraum überschneidet (sonst 409).
 * - Atomare Wechsel (WHERE status = erwartet + rowCount); 0 Zeilen = 409.
 * - Audit + Outbox in derselben Transaktion.
 */
final class ReservationWorkflow
{
    public const STATUS_LABELS = [
        'requested' => 'angefragt',
        'approved' => 'freigegeben',
        'rejected' => 'abgelehnt',
        'checked_out' => 'ausgegeben',
        'returned' => 'zurückgegeben',
    ];

    public function __construct(private readonly PDO $db)
    {
    }

    /** Entscheidung über eine Anfrage: approved|rejected (aus 'requested'). */
    public function decide(Actor $actor, string $id, string $decision, string $note = ''): array
    {
        $this->requireEquipmentRight($actor);
        if (!in_array($decision, ['approved', 'rejected'], true)) {
            throw new ApprovalValidation('Ungültige Entscheidung.');
        }
        $note = trim($note);
        if ($decision === 'rejected' && $note === '') {
            throw new ApprovalValidation('Ablehnung erfordert eine Begründung.');
        }
        $repo = new ReservationRepository($this->db);
        $reservation = $repo->find($id);
        if ($reservation === null) {
            throw new ApprovalNotFound('Reservierung nicht gefunden.');
        }
        if ($decision === 'approved') {
            $this->assertNoOverlap($repo, $reservation);
        }
        return $this->transition($repo, $actor, $id, 'requested', $decision, [
            'decided_by' => $actor->id,
            'decided_at' => date('Y-m-d H:i:s'),
            'decision_note' => $note,
        ], 'equipment.' . $decision, [
            'reservation_id' => $id,
            'decision' => $decision,
            'decided_by' => $actor->id,
            'note' => $note,
        ]);
    }

    /** Ausgabe quittieren: approved → checked_out. */
    public function checkout(Actor $actor, string $id): array
    {
        $this->requireEquipmentRight($actor);
        $repo = new ReservationRepository($this->db);
        if ($repo->find($id) === null) {
            throw new ApprovalNotFound('Reservierung nicht gefunden.');
        }
        return $this->transition($repo, $actor, $id, 'approved', 'checked_out', [
            'checked_out_by' => $actor->id,
            'checked_out_at' => date('Y-m-d H:i:s'),
        ], 'equipment.checkout', [
            'reservation_id' => $id,
            'checked_out_by' => $actor->id,
        ]);
    }

    /** Rückgabe quittieren: checked_out → returned. */
    public function markReturned(Actor $actor, string $id): array
    {
        $this->requireEquipmentRight($actor);
        $repo = new ReservationRepository($this->db);
        if ($repo->find($id) === null) {
            throw new ApprovalNotFound('Reservierung nicht gefunden.');
        }
        return $this->transition($repo, $actor, $id, 'checked_out', 'returned', [
            'returned_by' => $actor->id,
            'returned_at' => date('Y-m-d H:i:s'),
        ], 'equipment.return', [
            'reservation_id' => $id,
            'returned_by' => $actor->id,
        ]);
    }

    /** Konflikterkennung bei Zeitraumüberschneidung. */
    private function assertNoOverlap(ReservationRepository $repo, array $reservation): void
    {
        $conflicts = $repo->overlappingActive(
            (string) $reservation['asset_id'],
            (string) $reservation['starts_at'],
            (string) $reservation['ends_at'],
            (string) $reservation['id']
        );
        if ($conflicts !== []) {
            $first = $conflicts[0];
            throw new ApprovalConflict(
                'Zeitraumkonflikt mit bestehender Reservierung („'
                . (string) ($first['requester_name'] ?? 'unbekannt') . '“, '
                . (string) $first['starts_at'] . ' – ' . (string) $first['ends_at'] . ').'
            );
        }
    }

    /**
     * Atomarer Wechsel + Audit + Outbox in einer Transaktion.
     *
     * @param array<string, mixed> $fields
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function transition(ReservationRepository $repo, Actor $actor, string $id, string $expected, string $new, array $fields, string $auditAction, array $payload): array
    {
        $this->db->beginTransaction();
        try {
            $changed = $repo->applyStatus($id, $expected, $new, $fields);
            if ($changed === 0) {
                throw new ApprovalConflict(
                    'Reservierung ist nicht mehr im Status „' . (self::STATUS_LABELS[$expected] ?? $expected) . '“.'
                );
            }
            audit($this->db, $actor->id, $auditAction, 'asset_reservation', $id, $payload);
            (new Outbox($this->db))->append($auditAction, $payload);
            $this->db->commit();
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            throw $e;
        }
        return $repo->find($id) ?? [];
    }

    private function requireEquipmentRight(Actor $actor): void
    {
        if (!$actor->active || !$actor->can('equipment.approve')) {
            throw new ApprovalForbidden('Keine Berechtigung zur Equipment-Freigabe.');
        }
    }
}
