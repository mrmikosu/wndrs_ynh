<?php
declare(strict_types=1);

/**
 * ReservationRepository — Datenzugriff für Equipment-Reservierungen.
 * Statuswechsel ausschließlich atomar (UPDATE ... WHERE id = ? AND status = ?).
 */
final class ReservationRepository
{
    public function __construct(private readonly PDO $db)
    {
    }

    /** @return array<string, mixed>|null */
    public function find(string $id): ?array
    {
        if ($id === '') {
            return null;
        }
        $stmt = $this->db->prepare('SELECT * FROM asset_reservations WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    /** @return int geänderte Zeilen (0 = Vorbedingung verletzt → Konflikt) */
    public function applyStatus(string $id, string $expectedStatus, string $newStatus, array $fields): int
    {
        $set = 'status = ?';
        $params = [$newStatus];
        foreach ($fields as $column => $value) {
            $set .= ', ' . $column . ' = ?';
            $params[] = $value;
        }
        $params[] = $id;
        $params[] = $expectedStatus;
        $stmt = $this->db->prepare(
            "UPDATE asset_reservations SET {$set} WHERE id = ? AND status = ?"
        );
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    /**
     * Zeitraumüberschneidungen mit bereits freigegebenen/ausgegebenen
     * Reservierungen desselben Equipments.
     *
     * Überlappung: bestand.start < neu.ende UND bestand.ende > neu.start.
     *
     * @return list<array<string, mixed>>
     */
    public function overlappingActive(string $assetId, string $startsAt, string $endsAt, string $excludeId = ''): array
    {
        $stmt = $this->db->prepare(
            "SELECT r.*, u.display_name AS requester_name
             FROM asset_reservations r
             LEFT JOIN users u ON u.id = r.requester_id
             WHERE r.asset_id = ?
               AND r.status IN ('approved', 'checked_out')
               AND r.starts_at < ?
               AND r.ends_at > ?
               AND r.id != ?
             ORDER BY r.starts_at ASC"
        );
        $stmt->execute([$assetId, $endsAt, $startsAt, $excludeId]);
        return $stmt->fetchAll();
    }
}
