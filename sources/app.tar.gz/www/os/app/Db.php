<?php
declare(strict_types=1);

final class Db
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo) {
            return self::$pdo;
        }
        $db = Config::get('db');
        $dsn = $db['dsn'] ?? 'sqlite:' . dirname(__DIR__) . '/data/kollektiv.sqlite';
        $dir = dirname(__DIR__) . '/data';
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        self::$pdo = new PDO($dsn, $db['user'] ?? null, $db['pass'] ?? null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        if (str_starts_with($dsn, 'sqlite:')) {
            self::$pdo->exec('PRAGMA foreign_keys = ON');
        }
        return self::$pdo;
    }

    public static function migrate(): void
    {
        $sql = file_get_contents(__DIR__ . '/schema.sql');
        if ($sql === false) {
            throw new RuntimeException('schema.sql missing');
        }
        $pdo = self::pdo();
        $pdo->exec($sql);
        self::ensureColumn($pdo, 'tasks', 'due_at', 'TEXT');
        self::ensureColumn($pdo, 'projects', 'priority', "TEXT NOT NULL DEFAULT 'medium'");
        // time_entries created via schema.sql CREATE IF NOT EXISTS
    }

    private static function ensureColumn(PDO $pdo, string $table, string $column, string $ddl): void
    {
        $cols = $pdo->query("PRAGMA table_info({$table})")->fetchAll();
        foreach ($cols as $col) {
            if (($col['name'] ?? '') === $column) {
                return;
            }
        }
        $pdo->exec("ALTER TABLE {$table} ADD COLUMN {$column} {$ddl}");
    }
}
