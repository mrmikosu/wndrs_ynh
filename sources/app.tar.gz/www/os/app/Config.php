<?php
declare(strict_types=1);

final class Config
{
    private static array $cfg = [];

    public static function load(): array
    {
        if (self::$cfg) {
            return self::$cfg;
        }
        $path = dirname(__DIR__) . '/config.php';
        if (!is_file($path)) {
            $path = dirname(__DIR__) . '/config.example.php';
        }
        self::$cfg = require $path;
        return self::$cfg;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        $cfg = self::load();
        return $cfg[$key] ?? $default;
    }
}
