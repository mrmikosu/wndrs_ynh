<?php
declare(strict_types=1);

function uuid(): string
{
    $data = random_bytes(16);
    $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
    $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function json_encode_db(mixed $value): string
{
    return json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]';
}

function json_decode_db(?string $value, mixed $default = []): mixed
{
    if ($value === null || $value === '') {
        return $default;
    }
    $decoded = json_decode($value, true);
    return $decoded === null ? $default : $decoded;
}

function base_path(): string
{
    $base = (string) Config::get('base_path', '');
    if ($base === '' || $base === '/') {
        // Auto-detect subdirectory installs (e.g. /site)
        $script = $_SERVER['SCRIPT_NAME'] ?? '';
        $dir = rtrim(str_replace('\\', '/', dirname($script)), '/');
        if ($dir !== '' && $dir !== '/' && $dir !== '.') {
            $base = $dir;
        } else {
            // Yunohost often serves /site while SCRIPT_NAME stays /index.php
            $uri = (string) (parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
            if ($uri === '/site' || str_starts_with($uri, '/site/')) {
                $base = '/site';
            } else {
                $base = '';
            }
        }
    }
    return rtrim($base, '/');
}

/** True when nginx has no try_files rewrite (Yunohost custom webapp at /site). */
function use_query_router(): bool
{
    return (bool) Config::get('url_query_router', false);
}

/** Public marketing site (Vite landing), not the PHP OS home. */
function public_home_url(): string
{
    $home = trim((string) Config::get('public_home', ''));
    if ($home !== '') {
        return $home;
    }
    $base = base_path();
    if (str_ends_with($base, '/os')) {
        $parent = substr($base, 0, -3);
        return ($parent === '' ? '/' : rtrim($parent, '/') . '/');
    }
    return '/';
}

/** App-absolute URL, respecting base_path and optional ?r= router. */
function u(string $path): string
{
    if ($path === '' || str_starts_with($path, 'http://') || str_starts_with($path, 'https://') || str_starts_with($path, '//') || str_starts_with($path, '#')) {
        return $path;
    }
    // Templates may pass already-escaped query strings (&amp;).
    $path = html_entity_decode($path, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if (!str_starts_with($path, '/')) {
        $path = '/' . $path;
    }
    $base = base_path();
    // Already prefixed (e.g. after rewrite pass or explicit u() in templates).
    if ($base !== '' && (str_starts_with($path, $base . '/') || $path === $base || str_starts_with($path, $base . '?'))) {
        return $path;
    }
    $parts = parse_url($path);
    $route = $parts['path'] ?? '/';
    $isStatic = (bool) preg_match(
        '/\.(css|js|mjs|map|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|webmanifest|txt|pdf|zip|mp4|webm)$/i',
        $route
    );
    if ($isStatic || !use_query_router()) {
        return $base . $path;
    }
    $query = [];
    if (!empty($parts['query'])) {
        parse_str($parts['query'], $query);
    }
    $query = ['r' => $route] + $query;
    // Keep slashes in r= readable (/login not %2Flogin); safer for some proxies.
    return $base . '/?' . preg_replace(
        '/%2F/i',
        '/',
        http_build_query($query)
    );
}

function redirect(string $path): never
{
    if (str_starts_with($path, '/') && !str_starts_with($path, '//')) {
        $path = u($path);
    }
    header('Location: ' . $path);
    exit;
}

/** Rewrite root-absolute href/src/action in HTML for subdirectory installs. */
function rewrite_app_urls(string $html): string
{
    $base = base_path();
    if ($base === '' && !use_query_router()) {
        return $html;
    }
    $html = (string) preg_replace_callback(
        '#\b(href|src|action)=([\'"])(/(?!/)[^\'"]*)\2#i',
        static function (array $m): string {
            $raw = html_entity_decode($m[3], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            // Bare "/" is the public landing, not the OS dashboard.
            if ($raw === '/') {
                return $m[1] . '=' . $m[2] . public_home_url() . $m[2];
            }
            $home = rtrim(public_home_url(), '/');
            $appBase = base_path();
            // Already a public/landing URL (e.g. /site/) — do not route through the OS.
            if (
                $home !== ''
                && ($raw === $home || $raw === $home . '/' || (str_starts_with($raw, $home . '/') && ($appBase === '' || !str_starts_with($raw, $appBase))))
            ) {
                return $m[0];
            }
            $url = u($raw);
            return $m[1] . '=' . $m[2] . $url . $m[2];
        },
        $html
    );

    // Browsers drop action query strings on GET submit — inject hidden r=.
    if (use_query_router()) {
        $html = (string) preg_replace_callback(
            '#<form\b([^>]*\bmethod=(["\'])get\2[^>]*)>#i',
            static function (array $m) use ($base): string {
                $attrs = $m[1];
                if (!preg_match('#\baction=(["\'])([^"\']+)\1#i', $attrs, $am)) {
                    return $m[0];
                }
                $action = html_entity_decode($am[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $parts = parse_url($action);
                $query = [];
                if (!empty($parts['query'])) {
                    parse_str($parts['query'], $query);
                }
                $route = $query['r'] ?? '';
                if (!is_string($route) || $route === '' || !str_starts_with($route, '/')) {
                    return $m[0];
                }
                unset($query['r']);
                $formBase = ($base !== '' ? $base . '/' : '/');
                $attrs = (string) preg_replace(
                    '#\baction=(["\'])[^"\']+\1#i',
                    'action=$1' . $formBase . '$1',
                    $attrs,
                    1
                );
                $hidden = '<input type="hidden" name="r" value="' . e($route) . '">';
                foreach ($query as $key => $val) {
                    if (!is_scalar($val)) {
                        continue;
                    }
                    $hidden .= '<input type="hidden" name="' . e((string) $key) . '" value="' . e((string) $val) . '">';
                }
                return '<form' . $attrs . '>' . $hidden;
            },
            $html
        );
    }

    return $html;
}

/** JS boot so client code can build subdirectory-safe URLs. */
function app_url_boot_script(): string
{
    return '<script>'
        . 'window.__wndrsBase=' . json_encode(base_path()) . ';'
        . 'window.__wndrsQueryRouter=' . (use_query_router() ? 'true' : 'false') . ';'
        . 'window.__wndrsUrl=function(path){'
        . 'if(!path||/^(https?:|\\/\\/|#)/.test(path))return path;'
        . 'if(path[0]!=="/")path="/"+path;'
        . 'var base=window.__wndrsBase||"";'
        . 'if(base&&(path===base||path.indexOf(base+"/")===0||path.indexOf(base+"?")===0))return path;'
        . 'if(/\\.(css|js|mjs|map|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|webmanifest)(\\?|$)/i.test(path)||!window.__wndrsQueryRouter)return base+path;'
        . 'var q=path.indexOf("?");var route=q===-1?path:path.slice(0,q);var qs=q===-1?"":path.slice(q+1);'
        . 'return base+"/?r="+encodeURIComponent(route).replace(/%2F/gi,"/")+(qs?"&"+qs:"");'
        . '};'
        . '</script>';
}

function flash(string $key, ?string $message = null): ?string
{
    if ($message !== null) {
        $_SESSION['_flash'][$key] = $message;
        return null;
    }
    $val = $_SESSION['_flash'][$key] ?? null;
    unset($_SESSION['_flash'][$key]);
    return $val;
}

function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function require_csrf(): void
{
    $token = $_POST['_csrf'] ?? '';
    if (!is_string($token) || !hash_equals(csrf_token(), $token)) {
        http_response_code(419);
        echo 'Ungültiges CSRF-Token';
        exit;
    }
}

function method(): string
{
    return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
}

function is_post(): bool
{
    return method() === 'POST';
}

function request_path(): string
{
    // Query router: /site/?r=/login&...
    if (isset($_GET['r']) && is_string($_GET['r']) && str_starts_with($_GET['r'], '/')) {
        return $_GET['r'] === '' ? '/' : $_GET['r'];
    }
    $uri = $_SERVER['REQUEST_URI'] ?? '/';
    $path = parse_url($uri, PHP_URL_PATH) ?: '/';
    // Support subdirectory installs
    $base = base_path();
    if ($base !== '' && str_starts_with($path, $base)) {
        $path = substr($path, strlen($base)) ?: '/';
    } else {
        $script = $_SERVER['SCRIPT_NAME'] ?? '';
        $dir = rtrim(str_replace('\\', '/', dirname($script)), '/');
        if ($dir !== '' && $dir !== '/' && str_starts_with($path, $dir)) {
            $path = substr($path, strlen($dir)) ?: '/';
        }
    }
    return $path === '' ? '/' : $path;
}

function view(string $name, array $data = []): void
{
    extract($data, EXTR_SKIP);
    $file = __DIR__ . '/views/' . $name . '.php';
    if (!is_file($file)) {
        http_response_code(500);
        echo 'View missing: ' . e($name);
        exit;
    }
    require $file;
}

function layout(string $layout, string $contentView, array $data = []): void
{
    $data['contentView'] = $contentView;
    ob_start();
    view('partials/' . $layout, $data);
    echo rewrite_app_urls((string) ob_get_clean());
}

function audit(PDO $db, ?string $actorId, string $action, string $entityType = '', string $entityId = '', array $meta = []): void
{
    $meta = array_merge([
        'ip' => class_exists('Security') ? Security::clientIp() : ($_SERVER['REMOTE_ADDR'] ?? ''),
        'ua' => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 240),
    ], $meta);
    // Prefer extended columns when migration applied
    try {
        $stmt = $db->prepare('INSERT INTO audit_logs (id, actor_id, action, entity_type, entity_id, meta, ip, user_agent) VALUES (?,?,?,?,?,?,?,?)');
        $stmt->execute([
            uuid(),
            $actorId,
            $action,
            $entityType,
            $entityId,
            json_encode_db($meta),
            $meta['ip'] ?? '',
            $meta['ua'] ?? '',
        ]);
    } catch (Throwable) {
        $stmt = $db->prepare('INSERT INTO audit_logs (id, actor_id, action, entity_type, entity_id, meta) VALUES (?,?,?,?,?,?)');
        $stmt->execute([uuid(), $actorId, $action, $entityType, $entityId, json_encode_db($meta)]);
    }
}

function admin_return(string $fallback): string
{
    $next = $_POST['return'] ?? '';
    if (!is_string($next) || !str_starts_with($next, '/admin') || str_contains($next, '//')) {
        return $fallback;
    }
    if (preg_match('/[\r\n\\\\]/', $next)) {
        return $fallback;
    }
    return $next;
}

function admin_entity_href(string $type, string $id): ?string
{
    if ($id === '') {
        return null;
    }
    return match ($type) {
        'user' => '/admin/mitglieder?id=' . urlencode($id),
        'news' => '/admin/news?id=' . urlencode($id),
        'event' => '/admin/events?id=' . urlencode($id),
        'profile' => '/admin/kuenstler?id=' . urlencode($id),
        'page' => '/admin/cms',
        'job_post' => '/admin/jobs',
        'application' => '/admin/bewerbungen',
        'invite' => '/admin/invites',
        'time_entry' => '/admin/zeit',
        'expense' => '/admin',
        'asset_reservation' => '/admin',
        'media' => '/admin/medien',
        default => null,
    };
}

function dt_local(?string $value): string
{
    if ($value === null || trim($value) === '') {
        return '';
    }
    return substr(str_replace(' ', 'T', $value), 0, 16);
}

function list_text(mixed $value): string
{
    if (is_string($value)) {
        $value = json_decode_db($value, []);
    }
    if (!is_array($value)) {
        return '';
    }
    return implode(', ', array_map(static fn ($item): string => (string) $item, $value));
}

function json_response(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function notify(PDO $db, string $userId, string $type, string $title, string $body = '', string $href = ''): void
{
    $db->prepare('INSERT INTO notifications (id, user_id, type, title, body, href) VALUES (?,?,?,?,?,?)')
        ->execute([uuid(), $userId, $type, $title, $body, $href]);
}
