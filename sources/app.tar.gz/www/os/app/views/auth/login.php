<form class="stack" method="post" action="/login">
  <?= csrf_field() ?>
  <input required type="email" name="email" placeholder="E-Mail" autocomplete="username">
  <input required type="password" name="password" placeholder="Passwort" autocomplete="current-password">
  <button class="btn-accent" type="submit">Einloggen</button>
</form>
