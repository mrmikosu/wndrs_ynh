<?php if (!$invite): ?>
  <p class="flash err">Invite ungültig oder bereits genutzt.</p>
<?php else: ?>
  <p class="muted">Account für <strong><?= e($invite['email']) ?></strong> aktivieren.</p>
  <form class="stack" method="post" action="/invite">
    <?= csrf_field() ?>
    <input type="hidden" name="token" value="<?= e($token) ?>">
    <input required name="display_name" placeholder="Anzeigename">
    <input required type="password" name="password" placeholder="Passwort (min. 8)" minlength="8">
    <button class="btn-accent" type="submit">Aktivieren</button>
  </form>
<?php endif; ?>
