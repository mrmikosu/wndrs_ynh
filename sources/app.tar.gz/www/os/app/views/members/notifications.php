<p class="eyebrow">Aktivität</p>
<h2>Benachrichtigungen</h2>
<?php if ($unread): ?>
  <form method="post" action="/members/benachrichtigungen" style="margin:.5rem 0">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="all">
    <button type="submit">Alle als gelesen (<?= (int) $unread ?>)</button>
  </form>
<?php endif; ?>

<?php if (!$rows): ?>
  <p class="muted panel">Keine Benachrichtigungen.</p>
<?php endif; ?>

<ul class="list">
  <?php foreach ($rows as $n): ?>
    <li class="panel <?= empty($n['read_at']) ? '' : 'muted' ?>" style="margin-bottom:.75rem">
      <div style="display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap">
        <div>
          <span class="chip"><?= e($n['type']) ?></span>
          <strong><?= e($n['title']) ?></strong>
          <?php if ($n['body']): ?><p><?= nl2br(e($n['body'])) ?></p><?php endif; ?>
          <p class="muted" style="font-size:.85rem"><?= e($n['created_at']) ?></p>
          <?php if ($n['href']): ?>
            <a href="<?= e($n['href']) ?>">Öffnen</a>
          <?php endif; ?>
        </div>
        <?php if (empty($n['read_at'])): ?>
          <form method="post" action="/members/benachrichtigungen">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($n['id']) ?>">
            <button type="submit">Gelesen</button>
          </form>
        <?php else: ?>
          <span class="muted">gelesen <?= e($n['read_at']) ?></span>
        <?php endif; ?>
      </div>
    </li>
  <?php endforeach; ?>
</ul>
