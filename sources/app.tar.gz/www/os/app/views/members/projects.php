<p class="eyebrow">Organisation</p>
<h2>Projektmanagement</h2>
<p class="muted">Projekte anlegen, Status steuern, Kanban öffnen.</p>

<form class="stack panel" method="post" action="/members/projekte">
  <?= csrf_field() ?>
  <h3>Neues Projekt</h3>
  <input name="title" required placeholder="Projekttitel">
  <textarea name="description" rows="2" placeholder="Ziel / Beschreibung"></textarea>
  <div class="row-2">
    <select name="status">
      <option value="planned">planned</option>
      <option value="active" selected>active</option>
      <option value="paused">paused</option>
    </select>
    <select name="priority">
      <option value="low">low</option>
      <option value="medium" selected>medium</option>
      <option value="high">high</option>
      <option value="urgent">urgent</option>
    </select>
  </div>
  <select name="lead_id">
    <option value="">Lead: ich</option>
    <?php foreach ($members as $m): ?>
      <option value="<?= e($m['id']) ?>"><?= e($m['display_name']) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn-accent" type="submit">Projekt starten (+ Starter-Tasks)</button>
</form>

<form class="stack panel" method="post" action="/members/projekte/template" style="clip-path:none;margin-top:1rem">
  <?= csrf_field() ?>
  <h3>Aus Vorlage</h3>
  <p class="muted">Phasen, Meilensteine, Starter-Tasks und Board werden automatisch angelegt.</p>
  <input name="title" placeholder="Projekttitel (optional)">
  <select name="template" required>
    <?php foreach (Projects::templateLabels() as $key => $label): ?>
      <option value="<?= e($key) ?>"><?= e($label) ?></option>
    <?php endforeach; ?>
  </select>
  <button type="submit">Vorlage starten</button>
</form>

<div class="grid" style="margin-top:1rem">
<?php foreach ($projects as $p):
  $total = (int) ($p['task_count'] ?? 0);
  $done = (int) ($p['done_count'] ?? 0);
  $pct = $total > 0 ? (int) round(100 * $done / $total) : 0;
?>
  <article class="panel project-card">
    <div class="task-card__top">
      <h3 style="margin:0"><a href="/members/projekte/view?id=<?= e($p['id']) ?>"><?= e($p['title']) ?></a></h3>
      <span class="chip"><?= e($p['status']) ?></span>
    </div>
    <p class="muted" style="margin:.4rem 0"><?= e($p['description'] ?: 'Keine Beschreibung') ?></p>
    <p class="muted" style="font-size:.85rem">Lead: <?= e($p['lead_name'] ?? '—') ?> · Prio <?= e($p['priority'] ?? 'medium') ?></p>
    <div class="progress"><span style="width:<?= $pct ?>%"></span></div>
    <p class="muted" style="font-size:.8rem;margin:.35rem 0 0.7rem"><?= $done ?>/<?= $total ?> erledigt · <?= (int)($p['doing_count'] ?? 0) ?> in Arbeit</p>
    <p>
      <a class="btn" href="/members/projekte/view?id=<?= e($p['id']) ?>">Board</a>
      <a class="btn" href="/members/projekte/view?id=<?= e($p['id']) ?>&view=list">Liste</a>
      <a class="btn" href="/members/kanban?project=<?= e($p['id']) ?>">Kanban</a>
    </p>
  </article>
<?php endforeach; ?>
</div>
<?php if (!$projects): ?><p class="muted">Noch keine Projekte.</p><?php endif; ?>
