<h2>Mitglieder</h2>
<table>
  <thead><tr><th>Name</th><th>Artist</th><th>Status</th><th>Ort</th></tr></thead>
  <tbody>
  <?php foreach ($people as $p): ?>
    <tr>
      <td><?= e($p['display_name']) ?></td>
      <td><?= e($p['artist_name'] ?? '') ?></td>
      <td><span class="chip"><?= e($p['membership_status'] ?? '') ?></span></td>
      <td><?= e($p['location'] ?? '') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
