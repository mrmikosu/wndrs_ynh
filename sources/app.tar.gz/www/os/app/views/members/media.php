<h2>Mediathek</h2>
<form class="stack panel" method="post" action="/members/mediathek" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <input type="file" name="file" required>
  <button type="submit">Hochladen</button>
</form>
<table>
  <thead><tr><th>Datei</th><th>ACL</th><th>Link</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['filename']) ?></td>
      <td><?= e($r['acl']) ?></td>
      <td><a href="<?= e($r['path']) ?>" target="_blank">öffnen</a></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
