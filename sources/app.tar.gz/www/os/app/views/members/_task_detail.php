<?php
/** @var string $focusTaskId */
/** @var array|null $taskDetail */
/** @var string $returnTo */
if ($focusTaskId === '' || $taskDetail === null) {
    return;
}
$focusTask = null;
foreach ($tasks as $t) {
    if ($t['id'] === $focusTaskId) {
        $focusTask = $t;
        break;
    }
}
if (!$focusTask) {
    return;
}
?>
<section class="panel stack" style="clip-path:none;margin:1rem 0;border:1px solid var(--accent)">
  <div class="task-card__top">
    <h3 style="margin:0">Task: <?= e($focusTask['title']) ?></h3>
    <a class="muted" href="<?= e(str_replace('&task=' . urlencode($focusTaskId), '', $returnTo)) ?>">Schließen</a>
  </div>
  <?php if (!empty($focusTask['description'])): ?><p><?= nl2br(e($focusTask['description'])) ?></p><?php endif; ?>

  <h4>Kommentare</h4>
  <?php if (!$taskDetail['comments']): ?><p class="muted">Noch keine Kommentare.</p><?php endif; ?>
  <ul class="stack" style="list-style:none;padding:0">
    <?php foreach ($taskDetail['comments'] as $c): ?>
      <li><strong><?= e($c['author_name']) ?></strong> <span class="muted"><?= e(substr($c['created_at'], 0, 16)) ?></span><br><?= nl2br(e($c['body'])) ?></li>
    <?php endforeach; ?>
  </ul>
  <form class="stack" method="post" action="/members/tasks/comment">
    <?= csrf_field() ?>
    <input type="hidden" name="task_id" value="<?= e($focusTaskId) ?>">
    <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
    <textarea name="body" rows="2" required placeholder="Kommentar …"></textarea>
    <button type="submit">Kommentieren</button>
  </form>

  <h4>Checkliste</h4>
  <ul class="stack" style="list-style:none;padding:0">
    <?php foreach ($taskDetail['checklists'] as $item): ?>
      <li style="display:flex;gap:.5rem;align-items:center">
        <form method="post" action="/members/tasks/checklist">
          <?= csrf_field() ?>
          <input type="hidden" name="form_action" value="toggle">
          <input type="hidden" name="task_id" value="<?= e($focusTaskId) ?>">
          <input type="hidden" name="item_id" value="<?= e($item['id']) ?>">
          <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
          <button type="submit"><?= !empty($item['done']) ? '☑' : '☐' ?></button>
        </form>
        <span<?= !empty($item['done']) ? ' style="text-decoration:line-through;opacity:.7"' : '' ?>><?= e($item['title']) ?></span>
      </li>
    <?php endforeach; ?>
  </ul>
  <form class="stack" method="post" action="/members/tasks/checklist">
    <?= csrf_field() ?>
    <input type="hidden" name="form_action" value="add">
    <input type="hidden" name="task_id" value="<?= e($focusTaskId) ?>">
    <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
    <input name="title" required placeholder="Neuer Checklistenpunkt">
    <button type="submit">Hinzufügen</button>
  </form>
</section>
