<h2>Profil</h2>
<form class="stack panel" method="post" action="/members/profil">
  <?= csrf_field() ?>
  <input name="display_name" value="<?= e($user['display_name']) ?>" placeholder="Anzeigename">
  <input name="artist_name" value="<?= e($profile['artist_name'] ?? '') ?>" placeholder="Künstlername">
  <textarea name="bio" rows="4" placeholder="Bio"><?= e($profile['bio'] ?? '') ?></textarea>
  <input name="disciplines" value="<?= e(implode(', ', json_decode_db($profile['disciplines'] ?? '[]'))) ?>" placeholder="Disziplinen">
  <input name="skills" value="<?= e(implode(', ', json_decode_db($profile['skills'] ?? '[]'))) ?>" placeholder="Skills">
  <input name="location" value="<?= e($profile['location'] ?? '') ?>" placeholder="Ort">
  <input name="availability" value="<?= e($profile['availability'] ?? '') ?>" placeholder="Verfügbarkeit">
  <select name="visibility">
    <?php foreach (['public','members','private'] as $v): ?>
      <option value="<?= $v ?>" <?= ($profile['visibility'] ?? 'members')===$v?'selected':'' ?>><?= $v ?></option>
    <?php endforeach; ?>
  </select>
  <label><input type="checkbox" name="public_visible" value="1" <?= !empty($profile['public_visible'])?'checked':'' ?>> Auf www zeigen</label>
  <button type="submit">Speichern</button>
</form>

<section class="panel stack" style="margin-top:1.25rem;clip-path:none">
  <h3>Zertifikate</h3>
  <?php if (!$certificates): ?><p class="muted">Noch keine Zertifikate.</p><?php endif; ?>
  <ul class="stack" style="list-style:none;padding:0;margin:0">
  <?php foreach ($certificates as $c): ?>
    <li style="display:flex;gap:.5rem;align-items:flex-start;flex-wrap:wrap;border-bottom:1px solid var(--line);padding:.5rem 0">
      <div>
        <strong><?= e($c['name']) ?></strong>
        <?php if ($c['issuer']): ?><span class="muted"> · <?= e($c['issuer']) ?></span><?php endif; ?>
        <?php if ($c['expires_at']): ?><p class="muted" style="font-size:.8rem;margin:.2rem 0 0">gültig bis <?= e($c['expires_at']) ?></p><?php endif; ?>
      </div>
      <form method="post" action="/members/zertifikate" onsubmit="return confirm('Entfernen?')">
        <?= csrf_field() ?>
        <input type="hidden" name="form_action" value="delete">
        <input type="hidden" name="id" value="<?= e($c['id']) ?>">
        <button type="submit" class="btn-danger">Löschen</button>
      </form>
    </li>
  <?php endforeach; ?>
  </ul>
  <form class="stack" method="post" action="/members/zertifikate">
    <?= csrf_field() ?>
    <input type="hidden" name="form_action" value="add">
    <input name="name" required placeholder="Bezeichnung z.B. Erste-Hilfe">
    <input name="issuer" placeholder="Aussteller">
    <div class="row-2">
      <input type="date" name="issued_at" placeholder="Ausgestellt">
      <input type="date" name="expires_at" placeholder="Ablauf">
    </div>
    <input name="note" placeholder="Notiz">
    <button type="submit">Zertifikat hinzufügen</button>
  </form>
</section>

<section class="panel stack" style="margin-top:1.25rem;clip-path:none">
  <h3>Datenschutz</h3>
  <p class="muted">Alle bei uns gespeicherten personenbezogenen Daten als JSON exportieren.</p>
  <a class="btn" href="/members/datenexport">Datenexport (JSON)</a>
  <form class="stack" method="post" action="/members/konto-loeschen" onsubmit="return confirm('Konto wirklich deaktivieren?')">
    <?= csrf_field() ?>
    <p class="muted">Konto deaktivieren (soft-delete). Zur Bestätigung <code>LOESCHEN</code> eingeben.</p>
    <input name="confirm" placeholder="LOESCHEN" autocomplete="off">
    <button type="submit" class="btn-danger">Konto deaktivieren</button>
  </form>
</section>
