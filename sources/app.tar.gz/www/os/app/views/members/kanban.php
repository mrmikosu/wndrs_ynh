<p class="eyebrow">Board</p>
<h2>Kanban</h2>
<form method="get" action="/members/kanban" class="panel" style="clip-path:none;margin-bottom:1rem">
  <label class="muted">Projekt</label>
  <div class="row-2" style="align-items:center">
    <select name="project" onchange="this.form.submit()">
      <?php foreach ($projects as $p): ?>
        <option value="<?= e($p['id']) ?>" <?= $projectId === $p['id'] ? 'selected' : '' ?>><?= e($p['title']) ?> (<?= e($p['status']) ?>)</option>
      <?php endforeach; ?>
    </select>
    <?php if ($project): ?>
      <a class="btn" href="/members/projekte/view?id=<?= e($project['id']) ?>">Projekt öffnen</a>
    <?php endif; ?>
  </div>
</form>

<?php if (!$project): ?>
  <p class="muted">Kein Projekt vorhanden. <a href="/members/projekte">Projekt anlegen</a>.</p>
<?php else: ?>
  <p class="muted" style="margin-bottom:1rem"><?= e($project['title']) ?> · Lead <?= e($project['lead_name'] ?? '—') ?> · Karten per Drag & Drop verschieben</p>
  <?php require __DIR__ . '/_task_detail.php'; ?>
  <?php require __DIR__ . '/_kanban_board.php'; ?>
<?php endif; ?>
