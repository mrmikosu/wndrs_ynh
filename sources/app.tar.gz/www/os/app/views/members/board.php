<h2>Schwarzes Brett</h2>
<form class="stack panel" method="post" action="/members/board">
  <?= csrf_field() ?>
  <input name="title" required placeholder="Titel">
  <input name="category" placeholder="Kategorie" value="general">
  <textarea name="body" required rows="3" placeholder="Aufruf / Gesuch…"></textarea>
  <button type="submit">Posten</button>
</form>
<?php foreach ($posts as $p): ?>
  <article class="panel">
    <?php if ($p['pinned']): ?><span class="chip">pin</span><?php endif; ?>
    <h3><?= e($p['title']) ?></h3>
    <p class="muted"><?= e($p['display_name']) ?> · <?= e($p['category']) ?></p>
    <p><?= nl2br(e($p['body'])) ?></p>
  </article>
<?php endforeach; ?>
