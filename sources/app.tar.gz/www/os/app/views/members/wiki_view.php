<?php if (!$page): ?>
  <p class="muted">Seite nicht gefunden.</p>
<?php else: ?>
  <p class="eyebrow">Wiki</p>
  <h2><?= e($page['title']) ?></h2>
  <p class="muted">v<?= (int)$page['version'] ?></p>
  <div class="panel"><pre style="white-space:pre-wrap;font:inherit;margin:0"><?= e($page['body']) ?></pre></div>
  <form class="stack panel" method="post" action="/members/wiki">
    <?= csrf_field() ?>
    <input type="hidden" name="slug" value="<?= e($page['slug']) ?>">
    <input name="title" value="<?= e($page['title']) ?>">
    <textarea name="body" rows="10"><?= e($page['body']) ?></textarea>
    <button type="submit">Aktualisieren</button>
  </form>
<?php endif; ?>
<p><a href="/members/wiki">← Wiki</a></p>
