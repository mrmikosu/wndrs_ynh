<?php
$roleLabels = [
  'runner' => 'Runner',
  'barkeeper' => 'Barkeeper',
  'fotograf' => 'Fotograf',
  'videograf' => 'Videograf',
  'dj' => 'DJ',
  'techniker' => 'Techniker',
  'licht' => 'Licht',
  'ton' => 'Ton',
  'stagehand' => 'Stagehand',
  'security' => 'Security',
  'warden' => 'Warden / Einlass',
  'koch' => 'Küche',
  'service' => 'Service',
  'produktion' => 'Produktion',
  'artist' => 'Artist',
  'other' => 'Sonstiges',
];
?>
<p class="eyebrow">Community</p>
<div class="task-card__top" style="margin-bottom:1rem">
  <div>
    <h2 style="margin:0">Jobbörse</h2>
    <p class="muted" style="margin:.35rem 0 0">Angebote &amp; Gesuche — Runner, Barkeeper, Fotograf, Crew …</p>
  </div>
</div>

<form method="get" action="/members/jobs" class="panel" style="clip-path:none;margin-bottom:1rem">
  <div class="row-2" style="grid-template-columns:repeat(3,1fr)">
    <select name="kind">
      <option value="">Alle Arten</option>
      <option value="gesuch" <?= $kind === 'gesuch' ? 'selected' : '' ?>>Gesuche</option>
      <option value="angebot" <?= $kind === 'angebot' ? 'selected' : '' ?>>Angebote</option>
    </select>
    <select name="role">
      <option value="">Alle Rollen</option>
      <?php foreach ($roles as $r): ?>
        <option value="<?= e($r) ?>" <?= $role === $r ? 'selected' : '' ?>><?= e($roleLabels[$r] ?? $r) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="status">
      <option value="open" <?= $status === 'open' ? 'selected' : '' ?>>Offen</option>
      <option value="filled" <?= $status === 'filled' ? 'selected' : '' ?>>Besetzt</option>
      <option value="closed" <?= $status === 'closed' ? 'selected' : '' ?>>Geschlossen</option>
      <option value="all" <?= $status === 'all' ? 'selected' : '' ?>>Alle</option>
    </select>
  </div>
  <button type="submit" style="margin-top:.5rem">Filtern</button>
</form>

<form class="stack panel" method="post" action="/members/jobs" style="clip-path:none;margin-bottom:1.25rem">
  <?= csrf_field() ?>
  <h3>Eintrag posten</h3>
  <div class="row-2">
    <select name="kind" required>
      <option value="gesuch">Gesuch (wir suchen …)</option>
      <option value="angebot">Angebot (ich biete …)</option>
    </select>
    <select name="role" required>
      <?php foreach ($roles as $r): ?>
        <option value="<?= e($r) ?>"><?= e($roleLabels[$r] ?? $r) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <input name="title" required placeholder="Kurztitel z.B. Runner für Open Studio">
  <textarea name="body" required rows="3" placeholder="Was, wann, Anforderungen …"></textarea>
  <div class="row-2">
    <input name="location" placeholder="Ort / Location">
    <input type="date" name="event_date" placeholder="Datum">
  </div>
  <div class="row-2">
    <input name="pay_note" placeholder="Gage / Aufwandsentschädigung">
    <input name="contact" placeholder="Kontakt" value="<?= e($user['email'] ?? '') ?>">
  </div>
  <button class="btn-accent" type="submit">Veröffentlichen</button>
</form>

<div class="grid">
<?php foreach ($jobs as $j): ?>
  <article class="panel job-card" style="clip-path:none">
    <div class="task-card__top">
      <div>
        <span class="chip job-kind-<?= e($j['kind']) ?>"><?= $j['kind'] === 'angebot' ? 'Angebot' : 'Gesuch' ?></span>
        <span class="chip"><?= e($roleLabels[$j['role']] ?? $j['role']) ?></span>
        <span class="chip"><?= e($j['status']) ?></span>
      </div>
      <span class="muted" style="font-size:.75rem"><?= e(substr($j['created_at'], 0, 10)) ?></span>
    </div>
    <h3 style="margin:.55rem 0 .25rem"><?= e($j['title']) ?></h3>
    <p class="muted" style="font-size:.85rem;margin:0">
      <?= e($j['display_name']) ?>
      <?php if ($j['location']): ?> · <?= e($j['location']) ?><?php endif; ?>
      <?php if ($j['event_date']): ?> · <?= e($j['event_date']) ?><?php endif; ?>
    </p>
    <p><?= nl2br(e($j['body'])) ?></p>
    <?php if ($j['pay_note']): ?><p class="muted">Gage: <?= e($j['pay_note']) ?></p><?php endif; ?>
    <p><strong>Kontakt:</strong> <?= e($j['contact']) ?></p>
    <?php if (!empty($appCounts[$j['id']])): ?>
      <p class="muted" style="font-size:.85rem"><?= (int) $appCounts[$j['id']] ?> Bewerbung(en)</p>
    <?php endif; ?>

    <?php if ($j['status'] === 'open' && $j['author_id'] !== $user['id'] && Rbac::can($user['roles'], 'jobs.apply')): ?>
      <?php if (!empty($myApps[$j['id']])): ?>
        <p class="chip">Beworben (<?= e($myApps[$j['id']]) ?>)</p>
      <?php else: ?>
        <form class="stack" method="post" action="/members/jobs/apply" style="margin-top:.5rem">
          <?= csrf_field() ?>
          <input type="hidden" name="job_id" value="<?= e($j['id']) ?>">
          <input name="note" placeholder="Kurznotiz (optional)">
          <button type="submit" class="btn-accent">Bewerben</button>
        </form>
      <?php endif; ?>
    <?php endif; ?>

    <?php if ($j['author_id'] === $user['id'] || Rbac::can($user['roles'], 'admin.access')): ?>
      <div style="display:flex;gap:.35rem;flex-wrap:wrap;margin-top:.5rem">
        <?php if ($j['status'] === 'open'): ?>
          <form method="post" action="/members/jobs/status"><?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($j['id']) ?>">
            <button name="status" value="filled">Als besetzt</button>
          </form>
          <form method="post" action="/members/jobs/status"><?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($j['id']) ?>">
            <button name="status" value="closed">Schließen</button>
          </form>
        <?php else: ?>
          <form method="post" action="/members/jobs/status"><?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($j['id']) ?>">
            <button name="status" value="open">Wieder öffnen</button>
          </form>
        <?php endif; ?>
        <form method="post" action="/members/jobs/delete" onsubmit="return confirm('Löschen?')"><?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= e($j['id']) ?>">
          <button type="submit" class="btn-danger">Löschen</button>
        </form>
      </div>
    <?php endif; ?>
  </article>
<?php endforeach; ?>
</div>
<?php if (!$jobs): ?><p class="muted">Keine Einträge für diesen Filter.</p><?php endif; ?>
