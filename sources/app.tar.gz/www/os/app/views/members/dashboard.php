<?php
/**
 * Persönliches Mitglieder-Dashboard (Phase 4).
 * Alle Listen kommen berechtigungsgefiltert aus DashboardQuery.
 *
 * @var array $user
 * @var list<array<string, mixed>> $nextShifts
 * @var list<array<string, string>> $feedback
 * @var list<array<string, mixed>> $projects
 * @var array{tasks: list<array<string, mixed>>, jobs: list<array<string, mixed>>} $joinIn
 * @var array{board: list<array<string, mixed>>, news: list<array<string, mixed>>} $community
 * @var list<array<string, mixed>> $myTasks
 * @var list<array<string, mixed>> $accessibleTasks
 */
$roleLabels = ['lead' => 'Leitung', 'contributor' => 'Mitwirkende:r', 'viewer' => 'Betrachter:in'];
$statusLabels = ['active' => 'aktiv', 'planned' => 'geplant', 'paused' => 'pausiert', 'done' => 'abgeschlossen', 'archived' => 'archiviert'];
?>
<p class="eyebrow">Übersicht</p>
<h2>Hallo <?= e($user['display_name']) ?></h2>

<div class="grid" style="margin-top:1rem">

  <section class="panel">
    <p class="eyebrow">Nächster Einsatz</p>
    <?php if ($nextShifts): ?>
      <ul class="list">
        <?php foreach ($nextShifts as $shift): ?>
          <li>
            <strong><?= e($shift['event_title']) ?></strong> (<?= e($shift['role']) ?>)<br>
            <span class="muted"><?= e($shift['starts_at']) ?><?= $shift['venue'] !== '' ? ' · ' . e($shift['venue']) : '' ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
      <a class="btn" href="/members/schichten">Alle meine Schichten →</a>
    <?php else: ?>
      <p class="muted">Kein bevorstehender Einsatz. Sobald du einer Schicht zusagst, erscheint sie hier —
        unter „Mitmachen" findest du Aufgaben und Jobs, in denen du dich einbringen kannst.</p>
    <?php endif; ?>
  </section>

  <section class="panel">
    <p class="eyebrow">Braucht Rückmeldung</p>
    <?php if ($feedback): ?>
      <ul class="list">
        <?php foreach ($feedback as $item): ?>
          <li>
            <span class="chip"><?= e($item['kind']) ?></span> <?= e($item['text']) ?><br>
            <a href="<?= e($item['href']) ?>"><?= e($item['action_label']) ?> →</a>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="muted">Nichts offen — keine Einladungen, Rückfragen oder fehlenden Belege.</p>
    <?php endif; ?>
  </section>

  <section class="panel">
    <p class="eyebrow">Meine Projekte</p>
    <?php if ($projects): ?>
      <ul class="list">
        <?php foreach ($projects as $project): ?>
          <li>
            <a href="/members/projekte/view?id=<?= e($project['id']) ?>"><strong><?= e($project['title']) ?></strong></a>
            <span class="chip"><?= e($statusLabels[$project['status']] ?? $project['status']) ?></span>
            <span class="muted"><?= e($roleLabels[$project['my_role']] ?? $project['my_role']) ?></span><br>
            <?php if ($project['next_deadline'] !== null): ?>
              <span class="muted">
                Nächste Frist: <?= e($project['next_deadline']) ?> (<?= e($project['deadline_label'] ?? '') ?>)
                <?php if ($project['deadline_overdue']): ?><strong>· überfällig</strong><?php endif; ?>
              </span><br>
            <?php endif; ?>
            <?php if ($project['my_next_task']): ?>
              <span class="muted">Deine Aufgabe: <?= e($project['my_next_task']['title']) ?></span>
            <?php else: ?>
              <span class="muted">Dir ist hier keine offene Aufgabe zugewiesen.</span>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="muted">Du bist noch in keinem Projekt eingetragen. Lege unter
        <a href="/members/projekte">Projekte</a> ein eigenes an oder lass dich von der
        Projektleitung hinzufügen — dann siehst du hier Fristen und deine Aufgaben.</p>
    <?php endif; ?>
  </section>

  <section class="panel">
    <p class="eyebrow">Mitmachen</p>
    <?php if ($joinIn['tasks']): ?>
      <p class="muted" style="margin:.2rem 0">Offene Aufgaben in deinen Projekten:</p>
      <ul class="list">
        <?php foreach ($joinIn['tasks'] as $task): ?>
          <li>
            <a href="/members/projekte/view?id=<?= e($task['project_id']) ?>"><?= e($task['title']) ?></a>
            <span class="muted">(<?= e($task['project_title']) ?>)</span>
            <span class="muted">— im Projekt selbst zuweisen</span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
    <?php if ($joinIn['jobs']): ?>
      <p class="muted" style="margin:.2rem 0">Offene Jobs:</p>
      <ul class="list">
        <?php foreach ($joinIn['jobs'] as $job): ?>
          <li>
            <a href="/members/jobs"><?= e($job['title']) ?></a>
            <span class="muted">(<?= e($job['kind']) ?><?= $job['event_date'] ? ', ' . e($job['event_date']) : '' ?>)</span>
            <span class="muted">— bewerben in der Jobbörse</span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
    <?php if (!$joinIn['tasks'] && !$joinIn['jobs']): ?>
      <p class="muted">Gerade nichts Offenes. Neue Aufgaben und Jobs erscheinen hier,
        sobald Projekte oder Mitglieder sie ausschreiben.</p>
    <?php endif; ?>
  </section>

  <section class="panel">
    <p class="eyebrow">Aus dem Kollektiv</p>
    <?php if ($community['board']): ?>
      <ul class="list">
        <?php foreach ($community['board'] as $post): ?>
          <li>
            <?= $post['pinned'] ? '📌 ' : '' ?><a href="/members/board"><?= e($post['title']) ?></a>
            <span class="muted">· <?= e($post['display_name']) ?></span>
          </li>
        <?php endforeach; ?>
        <?php foreach ($community['news'] as $news): ?>
          <li><a href="/news"><?= e($news['title']) ?></a> <span class="chip">News</span></li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="muted">Noch keine Mitteilungen. Das Schwarze Brett lebt von euren Beiträgen —
        teile Aufrufe, Gesuche und Kooperationen.</p>
    <?php endif; ?>
  </section>

</div>

<div class="grid" style="margin-top:1rem;grid-template-columns:1fr 1fr">

  <section class="panel">
    <p class="eyebrow">Meine Aufgaben</p>
    <?php if ($myTasks): ?>
      <ul class="list">
        <?php foreach ($myTasks as $task): ?>
          <li>
            <?= e($task['title']) ?> <span class="chip"><?= e($task['status']) ?></span>
            <?php if ($task['project_title']): ?><span class="muted">· <?= e($task['project_title']) ?></span><?php endif; ?>
            <?php if ($task['due_at']): ?><br><span class="muted">fällig <?= e($task['due_at']) ?></span><?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
      <a class="btn" href="/members/kanban">Zum Board →</a>
    <?php else: ?>
      <p class="muted">Dir ist keine offene Aufgabe zugewiesen. Unter „Mitmachen" findest du
        unzugewiesene Aufgaben, die du dir nehmen kannst.</p>
    <?php endif; ?>
  </section>

  <section class="panel">
    <p class="eyebrow">Alle zugänglichen Aufgaben</p>
    <?php if ($accessibleTasks): ?>
      <ul class="list">
        <?php foreach ($accessibleTasks as $task): ?>
          <li>
            <?= e($task['title']) ?> <span class="chip"><?= e($task['status']) ?></span>
            <?php if ($task['project_title']): ?><span class="muted">· <?= e($task['project_title']) ?></span><?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <p class="muted">Keine offenen Aufgaben in deinen Projekten. Sobald du Projektmitglied bist,
        siehst du hier alle Aufgaben deiner Projekte.</p>
    <?php endif; ?>
  </section>

</div>
