<p class="eyebrow">Einsatzplan</p>
<h2>Meine Schichten</h2>
<p class="muted">Zuweisungen bestätigen oder absagen. Export als Kalender: <a href="/members/ical">iCal-Feed</a>.</p>

<?php if (!$assignments): ?>
  <p class="muted panel">Keine Schichtzuweisungen.</p>
<?php endif; ?>

<?php foreach ($assignments as $a): ?>
  <article class="panel" style="margin-top:1rem">
    <div style="display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap">
      <div>
        <h3><?= e($a['event_title']) ?></h3>
        <p class="muted">
          <?= e(Time::toLocal($a['starts_at'], 'd.m.Y H:i')) ?> – <?= e(Time::toLocal($a['ends_at'], 'H:i')) ?>
          · Rolle <span class="chip"><?= e($a['shift_role']) ?></span>
        </p>
        <?php if ($a['project_title']): ?>
          <p class="muted">Projekt: <?= e($a['project_title']) ?></p>
        <?php endif; ?>
        <?php if ($a['venue']): ?>
          <p class="muted"><?= e($a['venue']) ?></p>
        <?php endif; ?>
        <?php if ($a['shift_note']): ?>
          <p><?= nl2br(e($a['shift_note'])) ?></p>
        <?php endif; ?>
      </div>
      <div>
        <span class="chip"><?= e($a['status']) ?></span>
        <?php if (in_array($a['status'], ['invited', 'pending'], true)): ?>
          <form method="post" action="/members/schichten" class="inline" style="display:flex;gap:.5rem;margin-top:.5rem">
            <?= csrf_field() ?>
            <input type="hidden" name="assignment_id" value="<?= e($a['id']) ?>">
            <button type="submit" name="action" value="accept">Zusagen</button>
            <button type="submit" name="action" value="decline">Absagen</button>
          </form>
        <?php elseif ($a['responded_at']): ?>
          <p class="muted" style="font-size:.85rem">Antwort: <?= e($a['responded_at']) ?></p>
        <?php endif; ?>
      </div>
    </div>
  </article>
<?php endforeach; ?>
