<p class="eyebrow">Planung</p>
<h2>Verfügbarkeit & Abwesenheit</h2>

<section class="panel" style="margin:1rem 0">
  <h3>Neuer Zeitraum</h3>
  <form method="post" action="/members/verfuegbarkeit" class="stack">
    <?= csrf_field() ?>
    <input type="hidden" name="form_action" value="create">
    <label>
      Art
      <select name="kind">
        <option value="available">Verfügbar</option>
        <option value="unavailable">Nicht verfügbar</option>
        <option value="vacation">Urlaub / Abwesenheit</option>
      </select>
    </label>
    <label>Beginn <input type="datetime-local" name="starts_at" required></label>
    <label>Ende <input type="datetime-local" name="ends_at" required></label>
    <label>Notiz <input name="note" placeholder="optional"></label>
    <button type="submit">Speichern</button>
  </form>
</section>

<section>
  <h3>Bestehende Einträge</h3>
  <?php if (!$rows): ?>
    <p class="muted">Noch keine Zeiträume hinterlegt.</p>
  <?php endif; ?>
  <ul class="list">
    <?php foreach ($rows as $r): ?>
      <li class="panel" style="margin-bottom:.75rem">
        <strong><?= e($r['kind']) ?></strong>
        <span class="muted">
          <?= e(Time::toLocal($r['starts_at'], 'd.m.Y H:i')) ?> – <?= e(Time::toLocal($r['ends_at'], 'd.m.Y H:i')) ?>
        </span>
        <?php if ($r['note']): ?><p><?= e($r['note']) ?></p><?php endif; ?>
        <form method="post" action="/members/verfuegbarkeit" style="margin-top:.5rem">
          <?= csrf_field() ?>
          <input type="hidden" name="form_action" value="delete">
          <input type="hidden" name="id" value="<?= e($r['id']) ?>">
          <button type="submit">Löschen</button>
        </form>
      </li>
    <?php endforeach; ?>
  </ul>
</section>
