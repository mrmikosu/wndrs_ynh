<?php if (!$project): ?><p class="muted">Projekt nicht gefunden.</p><?php return; endif; ?>
<p class="eyebrow">Projektmanagement</p>
<div class="task-card__top" style="align-items:flex-start;margin-bottom:.75rem">
  <div>
    <h2 style="margin:0"><?= e($project['title']) ?></h2>
    <p class="muted" style="margin:.35rem 0 0">Lead: <?= e($project['lead_name'] ?? '—') ?> · <span class="chip"><?= e($project['status']) ?></span> · <?= e($project['priority'] ?? 'medium') ?></p>
  </div>
  <div style="display:flex;gap:.4rem;flex-wrap:wrap">
    <a class="btn <?= $viewMode === 'kanban' ? 'btn-accent' : '' ?>" href="/members/projekte/view?id=<?= e($project['id']) ?>&view=kanban">Kanban</a>
    <a class="btn <?= $viewMode === 'list' ? 'btn-accent' : '' ?>" href="/members/projekte/view?id=<?= e($project['id']) ?>&view=list">Liste</a>
    <a class="btn" href="/members/projekte">← Alle</a>
  </div>
</div>
<p><?= nl2br(e($project['description'])) ?></p>

<?php require __DIR__ . '/_task_detail.php'; ?>

<details class="panel" style="clip-path:none;margin:1rem 0">
  <summary>Projektdaten bearbeiten</summary>
  <form class="stack" method="post" action="/members/projekte/update" style="margin-top:.75rem">
    <?= csrf_field() ?>
    <input type="hidden" name="project_id" value="<?= e($project['id']) ?>">
    <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
    <input name="title" value="<?= e($project['title']) ?>" required>
    <textarea name="description" rows="3"><?= e($project['description']) ?></textarea>
    <div class="row-2">
      <select name="status">
        <?php foreach (['planned','active','paused','done','archived'] as $s): ?>
          <option value="<?= $s ?>" <?= $project['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select>
      <select name="priority">
        <?php foreach (['low','medium','high','urgent'] as $p): ?>
          <option value="<?= $p ?>" <?= ($project['priority'] ?? 'medium') === $p ? 'selected' : '' ?>><?= $p ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <select name="lead_id">
      <option value="">— Lead —</option>
      <?php foreach ($members as $m): ?>
        <option value="<?= e($m['id']) ?>" <?= ($project['lead_id'] ?? '') === $m['id'] ? 'selected' : '' ?>><?= e($m['display_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit">Speichern</button>
  </form>
</details>

<?php if ($viewMode === 'list'): ?>
  <table>
    <thead><tr><th>Aufgabe</th><th>Status</th><th>Prio</th><th>Zuweisung</th><th>Fällig</th></tr></thead>
    <tbody>
    <?php foreach ($tasks as $t): ?>
      <tr>
        <td><?= e($t['title']) ?></td>
        <td><?= e($t['status']) ?></td>
        <td><?= e($t['priority']) ?></td>
        <td><?= e($t['assignee_name'] ?? '—') ?></td>
        <td><?= e($t['due_at'] ?? '—') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <form class="stack panel" method="post" action="/members/tasks" style="margin-top:1rem;clip-path:none">
    <?= csrf_field() ?>
    <input type="hidden" name="project_id" value="<?= e($project['id']) ?>">
    <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
    <input name="title" required placeholder="Neue Aufgabe">
    <button type="submit">Task anlegen</button>
  </form>
<?php else: ?>
  <?php require __DIR__ . '/_kanban_board.php'; ?>
<?php endif; ?>
