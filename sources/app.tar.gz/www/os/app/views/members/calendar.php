<?php
$today = date('Y-m-d');
$selectedEvents = $byDay[$selected] ?? [];
$selectedBookings = $bookingsByDay[$selected] ?? [];
?>
<p class="eyebrow">Organisation</p>
<div class="task-card__top" style="margin-bottom:1rem">
  <div>
    <h2 style="margin:0">Veranstaltungskalender</h2>
    <p class="muted" style="margin:.35rem 0 0">Events & Raum-/Studio-Buchungen im Überblick</p>
  </div>
  <div style="display:flex;gap:.4rem;flex-wrap:wrap">
    <a class="btn" href="/members/kalender?y=<?= (int)date('Y', $prev) ?>&m=<?= (int)date('n', $prev) ?>">←</a>
    <span class="chip" style="align-self:center;padding:.45rem .7rem"><?= e($monthLabel) ?></span>
    <a class="btn" href="/members/kalender?y=<?= (int)date('Y', $next) ?>&m=<?= (int)date('n', $next) ?>">→</a>
    <a class="btn" href="/members/events">Liste</a>
  </div>
</div>

<div class="frame-wood">
  <img class="frame-wood__frame" src="/assets/frames/wood-neon-frame.png" alt="" aria-hidden="true">
  <div class="frame-wood__inner">
    <div class="cal-grid">
      <?php foreach (['Mo','Di','Mi','Do','Fr','Sa','So'] as $d): ?>
        <div class="cal-dow"><?= $d ?></div>
      <?php endforeach; ?>

      <?php for ($i = 1; $i < $firstDow; $i++): ?>
        <div class="cal-cell cal-cell--empty"></div>
      <?php endfor; ?>

      <?php for ($day = 1; $day <= $daysInMonth; $day++):
        $ymd = sprintf('%04d-%02d-%02d', $year, $month, $day);
        $evs = $byDay[$ymd] ?? [];
        $bks = $bookingsByDay[$ymd] ?? [];
        $classes = 'cal-cell';
        if ($ymd === $today) $classes .= ' is-today';
        if ($ymd === $selected) $classes .= ' is-selected';
        if ($evs || $bks) $classes .= ' has-items';
      ?>
        <a class="<?= $classes ?>" href="/members/kalender?y=<?= $year ?>&m=<?= $month ?>&day=<?= e($ymd) ?>">
          <span class="cal-daynum"><?= $day ?></span>
          <div class="cal-dots">
            <?php foreach (array_slice($evs, 0, 3) as $ev): ?>
              <span class="cal-pill cal-pill--event" title="<?= e($ev['title']) ?>"><?= e($ev['title']) ?></span>
            <?php endforeach; ?>
            <?php foreach (array_slice($bks, 0, 2) as $bk): ?>
              <span class="cal-pill cal-pill--booking" title="<?= e($bk['resource_name']) ?>"><?= e($bk['resource_name']) ?></span>
            <?php endforeach; ?>
            <?php if (count($evs) + count($bks) > 5): ?>
              <span class="muted" style="font-size:.65rem">+<?= count($evs) + count($bks) - 5 ?></span>
            <?php endif; ?>
          </div>
        </a>
      <?php endfor; ?>
    </div>
  </div>
</div>

<div class="grid" style="margin-top:1.25rem;grid-template-columns:1.2fr .8fr">
  <section class="panel" style="clip-path:none">
    <p class="eyebrow">Tag</p>
    <h3><?= e($selected) ?></h3>
    <?php if (!$selectedEvents && !$selectedBookings): ?>
      <p class="muted">Keine Einträge an diesem Tag.</p>
    <?php endif; ?>
    <?php foreach ($selectedEvents as $ev): ?>
      <article class="cal-detail">
        <span class="chip">Event</span>
        <strong><?= e($ev['title']) ?></strong>
        <p class="muted"><?= e($ev['starts_at']) ?><?= $ev['venue'] ? ' · ' . e($ev['venue']) : '' ?> · <?= e($ev['status']) ?></p>
        <?php if ($ev['description']): ?><p><?= nl2br(e($ev['description'])) ?></p><?php endif; ?>
      </article>
    <?php endforeach; ?>
    <?php foreach ($selectedBookings as $bk): ?>
      <article class="cal-detail">
        <span class="chip">Buchung</span>
        <strong><?= e($bk['resource_type']) ?> · <?= e($bk['resource_name']) ?></strong>
        <p class="muted"><?= e($bk['starts_at']) ?> → <?= e($bk['ends_at']) ?> · <?= e($bk['status']) ?></p>
      </article>
    <?php endforeach; ?>
  </section>

  <section class="panel" style="clip-path:none">
    <p class="eyebrow">Neu</p>
    <h3>Event anlegen</h3>
    <form class="stack" method="post" action="/members/kalender">
      <?= csrf_field() ?>
      <input type="hidden" name="return_to" value="/members/kalender?y=<?= $year ?>&m=<?= $month ?>&day=<?= e($selected) ?>">
      <input name="title" required placeholder="Titel">
      <input name="venue" placeholder="Ort">
      <input type="datetime-local" name="starts_at" value="<?= e($selected) ?>T18:00">
      <textarea name="description" rows="2" placeholder="Beschreibung"></textarea>
      <p class="muted" style="margin:0">Wird als <strong>Entwurf</strong> angelegt — Veröffentlichung nach Freigabe.</p>
      <button class="btn-accent" type="submit">Entwurf speichern</button>
    </form>
  </section>
</div>
