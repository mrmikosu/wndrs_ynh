<p class="eyebrow">Projekt</p>
<h2>Cockpit</h2>

<form method="get" action="/members/projekte/cockpit" style="margin:1rem 0;display:flex;gap:.5rem;flex-wrap:wrap">
  <label>Projekt
    <select name="project_id" onchange="this.form.submit()">
      <option value="">— wählen —</option>
      <?php foreach ($projects as $p): ?>
        <option value="<?= e($p['id']) ?>" <?= $projectId === $p['id'] ? 'selected' : '' ?>><?= e($p['title']) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <?php if ($project): ?>
    <a class="btn" href="/members/projekte/view?id=<?= e($project['id']) ?>">Kanban / Tasks</a>
    <?php if (Rbac::can($user['roles'], 'projects.budget')): ?>
      <a class="btn" href="/admin/budget?project_id=<?= e($project['id']) ?>">Budget (Admin)</a>
    <?php endif; ?>
  <?php endif; ?>
</form>

<?php if (!$projectId): ?>
  <p class="muted">Bitte ein Projekt wählen.</p>
<?php elseif (!$project): ?>
  <p class="muted">Projekt nicht gefunden.</p>
<?php else: ?>

<div class="grid" style="margin-top:1rem">
  <section class="panel stat">
    <p class="eyebrow">Phase</p>
    <?php if ($phase): ?>
      <strong><?= e($phase['phase']) ?></strong>
      <p class="muted"><?= e($phase['status']) ?><?= $phase['note'] ? ' · ' . e($phase['note']) : '' ?></p>
    <?php else: ?>
      <p class="muted">Keine offene Phase.</p>
    <?php endif; ?>
  </section>
  <section class="panel stat">
    <p class="eyebrow">Offene Tasks</p>
    <strong class="stat-value"><?= (int) $openTasks ?></strong>
  </section>
  <section class="panel stat">
    <p class="eyebrow">Budget (geplant)</p>
    <strong class="stat-value"><?= number_format($budgetCents / 100, 2, ',', '.') ?> €</strong>
  </section>
  <section class="panel stat">
    <p class="eyebrow">Risiken offen</p>
    <strong class="stat-value"><?= count($risks) ?></strong>
  </section>
</div>

<section class="panel" style="margin-top:1rem">
  <h3>Projekt</h3>
  <p><strong><?= e($project['title']) ?></strong> · <?= e($project['status']) ?> · Lead <?= e($project['lead_name'] ?? '—') ?></p>
  <?php if ($project['description']): ?>
    <p><?= nl2br(e($project['description'])) ?></p>
  <?php endif; ?>
</section>

<section class="panel" style="margin-top:1rem">
  <h3>Meilensteine</h3>
  <?php if (!$milestones): ?>
    <p class="muted">Keine Meilensteine.</p>
  <?php else: ?>
    <ul class="list">
      <?php foreach ($milestones as $m): ?>
        <li>
          <?= e($m['title']) ?>
          <span class="chip"><?= e($m['status']) ?></span>
          <?php if ($m['due_at']): ?><span class="muted">bis <?= e($m['due_at']) ?></span><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</section>

<?php if ($risks): ?>
  <section class="panel" style="margin-top:1rem">
    <h3>Offene Risiken</h3>
    <ul class="list">
      <?php foreach ($risks as $r): ?>
        <li>
          <strong><?= e($r['title']) ?></strong>
          <span class="muted">P<?= (int) $r['probability'] ?> / I<?= (int) $r['impact'] ?></span>
          <?php if ($r['owner_name']): ?> · <?= e($r['owner_name']) ?><?php endif; ?>
          <?php if ($r['mitigation']): ?><p class="muted"><?= e($r['mitigation']) ?></p><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </section>
<?php endif; ?>

<?php endif; ?>
