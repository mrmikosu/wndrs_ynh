<h2>Nachrichten</h2>
<div class="grid" style="grid-template-columns:200px 1fr">
  <aside class="panel">
    <?php foreach ($channels as $c): ?>
      <div><a href="/members/nachrichten?channel=<?= e($c['id']) ?>"><?= $c['id'] === $channelId ? '› ' : '' ?><?= e($c['name']) ?></a></div>
    <?php endforeach; ?>
  </aside>
  <section class="panel">
    <?php foreach ($messages as $m): ?>
      <div class="msg"><strong><?= e($m['display_name']) ?></strong> <span class="muted"><?= e($m['created_at']) ?></span><br><?= nl2br(e($m['body'])) ?></div>
    <?php endforeach; ?>
    <?php if ($channelId): ?>
      <form class="stack" method="post" action="/members/nachrichten" style="margin-top:1rem">
        <?= csrf_field() ?>
        <input type="hidden" name="channel_id" value="<?= e($channelId) ?>">
        <input name="body" required placeholder="Nachricht…">
        <button type="submit">Senden</button>
      </form>
    <?php endif; ?>
  </section>
</div>
