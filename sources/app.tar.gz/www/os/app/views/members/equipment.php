<h2>Equipment</h2>
<form class="stack panel" method="post" action="/members/equipment">
  <?= csrf_field() ?>
  <select name="asset_id" required>
    <?php foreach ($assets as $a): ?>
      <option value="<?= e($a['id']) ?>"><?= e($a['name']) ?> (<?= e($a['status']) ?>)</option>
    <?php endforeach; ?>
  </select>
  <input type="datetime-local" name="starts_at" required>
  <input type="datetime-local" name="ends_at" required>
  <input name="note" placeholder="Notiz">
  <button type="submit">Reservierung anfragen</button>
</form>
<table>
  <thead><tr><th>Asset</th><th>Wer</th><th>Von–Bis</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($reservations as $r): ?>
    <tr>
      <td><?= e($r['asset_name']) ?></td>
      <td><?= e($r['display_name']) ?></td>
      <td><?= e($r['starts_at']) ?> → <?= e($r['ends_at']) ?></td>
      <td>
        <?= e(ReservationWorkflow::STATUS_LABELS[$r['status']] ?? $r['status']) ?>
        <?php if (($r['decision_note'] ?? '') !== ''): ?><br><span class="muted"><?= e($r['decision_note']) ?></span><?php endif; ?>
      </td>
      <td>
        <?php if (Rbac::can($user['roles'], 'equipment.approve') && $r['status']==='requested'): ?>
          <form method="post" action="/admin/equipment/approve" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($r['id']) ?>">
            <label class="muted" style="display:inline">Begründung (Pflicht bei Ablehnung)
              <input type="text" name="note">
            </label>
            <button name="status" value="approved">Freigeben</button>
            <button name="status" value="rejected">Ablehnen</button>
          </form>
        <?php elseif (Rbac::can($user['roles'], 'equipment.approve') && $r['status']==='approved'): ?>
          <form method="post" action="/admin/equipment/checkout" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($r['id']) ?>">
            <button type="submit">Ausgabe quittieren</button>
          </form>
        <?php elseif (Rbac::can($user['roles'], 'equipment.approve') && $r['status']==='checked_out'): ?>
          <form method="post" action="/admin/equipment/return" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($r['id']) ?>">
            <button type="submit">Rückgabe quittieren</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
