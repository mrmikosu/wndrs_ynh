<div class="task-card__top" style="margin-bottom:1rem">
  <h2 style="margin:0">Events</h2>
  <a class="btn btn-accent" href="/members/kalender">Kalender →</a>
</div>
<form class="stack panel" method="post" action="/members/events">
  <input type="hidden" name="return_to" value="/members/events">
  <?= csrf_field() ?>
  <input name="title" required placeholder="Titel">
  <input name="venue" placeholder="Ort">
  <input type="datetime-local" name="starts_at">
  <textarea name="description" rows="2"></textarea>
  <p class="muted" style="margin:0">Neue Events werden als <strong>Entwurf</strong> angelegt.
    Die Veröffentlichung (auch öffentlich auf der Website) erfolgt nach Freigabe durch das Kollektiv-Team.</p>
  <button type="submit">Entwurf anlegen</button>
</form>
<?php foreach ($events as $ev): ?>
  <article class="panel">
    <h3><?= e($ev['title']) ?></h3>
    <p class="muted">
      <?= e($ev['starts_at'] ?? '') ?> · <?= e($ev['venue']) ?> ·
      <?= e($ev['status'] === 'published' ? 'veröffentlicht' : ($ev['status'] === 'draft' ? 'Entwurf' : $ev['status'])) ?><?= $ev['public'] ? ' · öffentlich' : '' ?>
    </p>
    <p><?= nl2br(e($ev['description'])) ?></p>
  </article>
<?php endforeach; ?>
