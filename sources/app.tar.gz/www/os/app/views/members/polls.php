<h2>Abstimmungen</h2>
<?php foreach ($polls as $poll):
  $opts = json_decode_db($poll['options'], []);
?>
  <article class="panel">
    <span class="chip"><?= e($poll['kind']) ?></span>
    <h3><?= e($poll['title']) ?></h3>
    <p class="muted"><?= e($poll['description']) ?></p>
    <?php if ($poll['status'] === 'open'): ?>
      <form method="post" action="/members/abstimmungen/vote" class="stack">
        <?= csrf_field() ?>
        <input type="hidden" name="poll_id" value="<?= e($poll['id']) ?>">
        <?php foreach ($opts as $opt): ?>
          <label><input type="radio" name="choice" value="<?= e(is_string($opt)?$opt:(string)$opt) ?>" required> <?= e(is_string($opt)?$opt:(string)$opt) ?></label>
        <?php endforeach; ?>
        <button type="submit">Abstimmen</button>
      </form>
    <?php endif; ?>
  </article>
<?php endforeach; ?>
