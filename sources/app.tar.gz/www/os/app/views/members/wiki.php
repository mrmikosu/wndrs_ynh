<h2>Wiki</h2>
<ul class="list panel">
<?php foreach ($pages as $p): ?>
  <li><a href="/members/wiki/view?slug=<?= e($p['slug']) ?>"><?= e($p['title']) ?></a> <span class="muted"><?= e($p['updated_at']) ?></span></li>
<?php endforeach; ?>
</ul>
<form class="stack panel" method="post" action="/members/wiki">
  <?= csrf_field() ?>
  <h3>Seite anlegen / ersetzen</h3>
  <input name="slug" required placeholder="slug">
  <input name="title" required placeholder="Titel">
  <textarea name="body" rows="6" placeholder="Inhalt"></textarea>
  <button type="submit">Speichern</button>
</form>
