<h2>Finanzen</h2>
<form class="stack panel" method="post" action="/members/finanzen">
  <?= csrf_field() ?>
  <input name="title" required placeholder="Auslage">
  <input name="amount" type="number" step="0.01" min="0.01" required placeholder="Betrag EUR">
  <input name="note" placeholder="Notiz">
  <button type="submit">Einreichen</button>
</form>
<table>
  <thead><tr><th>Titel</th><th>Betrag</th><th>Von</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['title']) ?></td>
      <td><?= number_format($r['amount_cents']/100, 2, ',', '.') ?> €</td>
      <td><?= e($r['display_name']) ?></td>
      <td>
        <?= e(DecideExpense::STATUS_LABELS[$r['status']] ?? $r['status']) ?>
        <?php if (($r['decision_note'] ?? '') !== ''): ?><br><span class="muted"><?= e($r['decision_note']) ?></span><?php endif; ?>
      </td>
      <td>
        <?php if (Rbac::can($user['roles'], 'finance.approve') && $r['status']==='submitted'): ?>
          <form method="post" action="/admin/expenses/decide" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($r['id']) ?>">
            <label class="muted" style="display:inline">Begründung (Pflicht bei Ablehnung)
              <input type="text" name="note">
            </label>
            <button name="status" value="approved">Freigeben</button>
            <button name="status" value="rejected">Ablehnen</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
