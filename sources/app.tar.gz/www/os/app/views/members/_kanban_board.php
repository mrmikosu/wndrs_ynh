<?php
/** Shared Kanban board partial
 * @var array $project
 * @var array $tasks
 * @var array $members
 * @var string $returnTo
 * @var string $csrf already via csrf_field()
 */
$cols = ['todo' => [], 'doing' => [], 'done' => []];
foreach ($tasks as $t) {
    $key = $t['status'] ?? 'todo';
    if (!isset($cols[$key])) {
        $key = 'todo';
    }
    $cols[$key][] = $t;
}
$labels = ['todo' => 'To do', 'doing' => 'In Arbeit', 'done' => 'Erledigt'];
$prioClass = ['low' => 'prio-low', 'medium' => 'prio-mid', 'high' => 'prio-high', 'urgent' => 'prio-urgent'];
?>
<div class="kanban" data-kanban data-return="<?= e($returnTo) ?>">
<?php foreach ($labels as $key => $label): ?>
  <div class="col" data-status="<?= e($key) ?>" ondragover="event.preventDefault()" ondrop="wndrsKanbanDrop(event, '<?= e($key) ?>')">
    <div class="col-head">
      <p class="eyebrow"><?= e($label) ?></p>
      <span class="chip"><?= count($cols[$key]) ?></span>
    </div>
    <?php foreach ($cols[$key] as $t): ?>
      <article class="task-card" draggable="true" data-task-id="<?= e($t['id']) ?>" ondragstart="wndrsKanbanDrag(event)">
        <div class="task-card__top">
          <strong><?= e($t['title']) ?></strong>
          <span class="chip <?= e($prioClass[$t['priority'] ?? 'medium'] ?? 'prio-mid') ?>"><?= e($t['priority'] ?? 'medium') ?></span>
        </div>
        <?php if (!empty($t['description'])): ?>
          <p class="muted task-card__desc"><?= e(strlen($t['description']) > 100 ? substr($t['description'], 0, 97) . '…' : $t['description']) ?></p>
        <?php endif; ?>
        <div class="task-card__meta">
          <?php if (!empty($t['assignee_name'])): ?><span><?= e($t['assignee_name']) ?></span><?php endif; ?>
          <?php if (!empty($t['due_at'])): ?><span class="muted"><?= e($t['due_at']) ?></span><?php endif; ?>
          <?php
            $taskHref = $returnTo;
            $sep = str_contains($returnTo, '?') ? '&' : '?';
            $taskHref .= $sep . 'task=' . urlencode($t['id']);
          ?>
          <a href="<?= e($taskHref) ?>" style="font-size:.8rem">Details</a>
        </div>
        <details class="task-card__edit">
          <summary>Bearbeiten</summary>
          <form class="stack" method="post" action="/members/tasks/update">
            <?= csrf_field() ?>
            <input type="hidden" name="task_id" value="<?= e($t['id']) ?>">
            <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
            <input name="title" value="<?= e($t['title']) ?>" required>
            <textarea name="description" rows="2"><?= e($t['description'] ?? '') ?></textarea>
            <select name="status">
              <?php foreach ($labels as $sk => $sl): ?>
                <option value="<?= $sk ?>" <?= ($t['status'] ?? '') === $sk ? 'selected' : '' ?>><?= e($sl) ?></option>
              <?php endforeach; ?>
            </select>
            <select name="priority">
              <?php foreach (['low','medium','high','urgent'] as $p): ?>
                <option value="<?= $p ?>" <?= ($t['priority'] ?? '') === $p ? 'selected' : '' ?>><?= $p ?></option>
              <?php endforeach; ?>
            </select>
            <select name="assignee_id">
              <option value="">— Zuweisung —</option>
              <?php foreach ($members as $m): ?>
                <option value="<?= e($m['id']) ?>" <?= ($t['assignee_id'] ?? '') === $m['id'] ? 'selected' : '' ?>><?= e($m['display_name']) ?></option>
              <?php endforeach; ?>
            </select>
            <input type="date" name="due_at" value="<?= e(substr((string)($t['due_at'] ?? ''), 0, 10)) ?>">
            <button type="submit">Speichern</button>
          </form>
          <form method="post" action="/members/tasks/delete" onsubmit="return confirm('Task löschen?')">
            <?= csrf_field() ?>
            <input type="hidden" name="task_id" value="<?= e($t['id']) ?>">
            <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
            <button type="submit" class="btn-danger">Löschen</button>
          </form>
        </details>
      </article>
    <?php endforeach; ?>

    <form class="stack task-add" method="post" action="/members/tasks">
      <?= csrf_field() ?>
      <input type="hidden" name="project_id" value="<?= e($project['id']) ?>">
      <input type="hidden" name="status" value="<?= e($key) ?>">
      <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
      <input name="title" required placeholder="+ Aufgabe in <?= e($label) ?>">
      <select name="priority">
        <option value="medium">medium</option>
        <option value="low">low</option>
        <option value="high">high</option>
        <option value="urgent">urgent</option>
      </select>
      <select name="assignee_id">
        <option value="">— Zuweisung —</option>
        <?php foreach ($members as $m): ?>
          <option value="<?= e($m['id']) ?>"><?= e($m['display_name']) ?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit">Hinzufügen</button>
    </form>
  </div>
<?php endforeach; ?>
</div>

<form id="kanban-move-form" method="post" action="/members/tasks/status" style="display:none">
  <?= csrf_field() ?>
  <input type="hidden" name="task_id" id="kanban-task-id">
  <input type="hidden" name="status" id="kanban-status">
  <input type="hidden" name="return_to" value="<?= e($returnTo) ?>">
  <input type="hidden" name="ajax" value="0">
</form>
