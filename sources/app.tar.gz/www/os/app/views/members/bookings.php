<h2>Buchungen</h2>
<form class="stack panel" method="post" action="/members/buchungen">
  <?= csrf_field() ?>
  <select name="resource_type"><option>room</option><option>studio</option><option>service</option></select>
  <input name="resource_name" required placeholder="Ressource">
  <input type="datetime-local" name="starts_at" required>
  <input type="datetime-local" name="ends_at" required>
  <input name="note" placeholder="Notiz">
  <button type="submit">Anfragen</button>
</form>
<table>
  <thead><tr><th>Ressource</th><th>Wer</th><th>Zeit</th><th>Status</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['resource_type']) ?> · <?= e($r['resource_name']) ?></td>
      <td><?= e($r['display_name']) ?></td>
      <td><?= e($r['starts_at']) ?> → <?= e($r['ends_at']) ?></td>
      <td><?= e($r['status']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
