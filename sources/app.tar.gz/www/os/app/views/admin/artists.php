<header class="admin-head">
  <p class="eyebrow">Website</p>
  <h2>Künstler</h2>
  <p class="muted">Öffentliche Profile erscheinen auf <a href="/artists" target="_blank" rel="noopener">/artists</a>. Das Konto selbst pflegst du unter Mitglieder.</p>
</header>
<div class="admin-split">
  <section class="panel admin-panel">
    <?php if (!$rows): ?><p class="muted">Noch keine Profile.</p><?php endif; ?>
    <?php foreach ($rows as $row): ?>
      <a class="feed <?= ($edit['id'] ?? '') === $row['id'] ? 'is-current' : '' ?>" href="/admin/kuenstler?id=<?= e(urlencode($row['id'])) ?>">
        <span class="chip"><?= !empty($row['public_visible']) ? 'auf www' : e($row['visibility'] ?? 'intern') ?></span>
        <strong><?= e($row['artist_name'] ?: $row['display_name']) ?></strong>
        <span class="muted"><?= e($row['email']) ?></span>
      </a>
    <?php endforeach; ?>
  </section>
  <?php if ($edit): ?>
    <form class="stack panel" method="post" action="/admin/kuenstler">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= e($edit['id']) ?>">
      <p class="muted">Konto: <a href="/admin/mitglieder?id=<?= e(urlencode($edit['user_id'])) ?>"><?= e($edit['display_name']) ?></a> · <?= e($edit['email']) ?></p>
      <label>Künstlername<input name="artist_name" value="<?= e($edit['artist_name'] ?? '') ?>"></label>
      <label>Bio<textarea name="bio" rows="5"><?= e($edit['bio'] ?? '') ?></textarea></label>
      <label>Disziplinen<input name="disciplines" value="<?= e(list_text($edit['disciplines'] ?? '[]')) ?>" placeholder="z. B. Sound, Licht"></label>
      <label>Ort<input name="location" value="<?= e($edit['location'] ?? '') ?>"></label>
      <label>Sichtbarkeit
        <select name="visibility">
          <?php foreach (['public' => 'öffentlich', 'members' => 'nur Mitglieder', 'private' => 'privat'] as $value => $label): ?>
            <option value="<?= e($value) ?>" <?= ($edit['visibility'] ?? 'members') === $value ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="check"><input type="checkbox" name="public_visible" value="1" <?= !empty($edit['public_visible']) ? 'checked' : '' ?>> Auf www zeigen</label>
      <button type="submit">Profil speichern</button>
    </form>
  <?php else: ?>
    <p class="muted panel">Wähle links ein Profil. Neue Profile entstehen mit dem Mitgliedskonto.</p>
  <?php endif; ?>
</div>
