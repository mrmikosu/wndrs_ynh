<header class="admin-head">
  <p class="eyebrow">Website und Kalender</p>
  <h2>Events</h2>
  <p class="muted">Veröffentlicht und öffentlich heißt sichtbar auf <a href="/events" target="_blank" rel="noopener">/events</a>. Ein neues Event kann ein Projekt im Mitgliederbereich anlegen.</p>
</header>
<div class="admin-split">
  <section class="panel admin-panel">
    <?php if (!$rows): ?><p class="muted">Noch keine Events.</p><?php endif; ?>
    <?php foreach ($rows as $row): ?>
      <a class="feed <?= ($edit['id'] ?? '') === $row['id'] ? 'is-current' : '' ?>" href="/admin/events?id=<?= e(urlencode($row['id'])) ?>">
        <span class="chip"><?= e($row['status']) ?><?= !empty($row['public']) ? ' · www' : '' ?></span>
        <strong><?= e($row['title']) ?></strong>
        <span class="muted"><?= e($row['starts_at'] ?? 'ohne Datum') ?><?= $row['project_title'] ? ' · Projekt ' . e($row['project_title']) : '' ?></span>
      </a>
    <?php endforeach; ?>
    <p><a href="/admin/events">Neues Event</a></p>
  </section>
  <form class="stack panel" method="post" action="/admin/events">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
    <label>Titel<input name="title" required value="<?= e($edit['title'] ?? '') ?>"></label>
    <label>Beschreibung<textarea name="description" rows="5"><?= e($edit['description'] ?? '') ?></textarea></label>
    <label>Ort<input name="venue" value="<?= e($edit['venue'] ?? '') ?>"></label>
    <label>Beginn<input type="datetime-local" name="starts_at" value="<?= e(dt_local($edit['starts_at'] ?? '')) ?>"></label>
    <label>Ende<input type="datetime-local" name="ends_at" value="<?= e(dt_local($edit['ends_at'] ?? '')) ?>"></label>
    <label>Status
      <select name="status">
        <?php foreach (['draft' => 'Entwurf', 'published' => 'Veröffentlicht'] as $value => $label): ?>
          <option value="<?= e($value) ?>" <?= ($edit['status'] ?? 'draft') === $value ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label class="check"><input type="checkbox" name="public" value="1" <?= !empty($edit['public']) ? 'checked' : '' ?>> Auf der Website zeigen</label>
    <?php if (!empty($edit['linked_project_id'])): ?>
      <p class="muted">Verknüpftes Projekt: <a href="/members/projekte/view?id=<?= e(urlencode($edit['linked_project_id'])) ?>"><?= e($edit['project_title'] ?? 'öffnen') ?></a></p>
    <?php endif; ?>
    <button type="submit"><?= $edit ? 'Speichern' : 'Anlegen' ?></button>
  </form>
</div>
<?php if ($edit): ?>
  <form method="post" action="/admin/events/delete" class="inline-form">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= e($edit['id']) ?>">
    <button type="submit">Dieses Event löschen</button>
  </form>
<?php endif; ?>
