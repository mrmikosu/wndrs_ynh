<h2>Arbeitszeiten</h2>
<p class="muted">Freigabe für Team-Zeiteinträge</p>
<table>
  <thead><tr><th>Person</th><th>Datum</th><th>Dauer</th><th>Projekt</th><th>Notiz</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['display_name']) ?></td>
      <td><?= e($r['work_date']) ?></td>
      <td><?= number_format(((int)$r['minutes'])/60, 2, ',', '.') ?> h</td>
      <td><?= e($r['project_title'] ?? '—') ?></td>
      <td><?= e($r['note']) ?></td>
      <td><span class="chip"><?= e($r['status']) ?></span></td>
      <td>
        <?php if ($r['status'] === 'submitted'): ?>
          <form method="post" action="/admin/zeit" style="display:inline">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($r['id']) ?>">
            <button name="status" value="approved">OK</button>
            <button name="status" value="rejected">Reject</button>
          </form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php if (!$rows): ?><p class="muted">Keine Einträge.</p><?php endif; ?>
