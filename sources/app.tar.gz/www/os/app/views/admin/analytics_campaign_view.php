<?php
/** @var array $campaign */
/** @var string $url */
/** @var int $visits */
/** @var DateTimeImmutable $d0 */
/** @var DateTimeImmutable $d1 */
/** @var string $rangeLabel */
/** @var array $warnings */
/** @var PDO|null $conn */
$fmtNum = static fn(int $n): string => number_format($n, 0, ',', '.');
$id = (int) $campaign['id'];
$rangeBase = $rangeLabel === 'custom'
    ? ['from' => $d0->format('Y-m-d'), 'to' => $d1->format('Y-m-d')]
    : ['r' => $rangeLabel];
?>
<header class="admin-head">
  <p class="eyebrow">Besucher</p>
  <h2><?= e((string) $campaign['name']) ?></h2>
  <p class="muted"><?= e($d0->format('d.m.Y')) ?> bis <?= e($d1->format('d.m.Y')) ?></p>
  <p class="admin-actions">
    <a href="<?= e(u('/admin/analytics/campaigns?' . http_build_query($rangeBase))) ?>">Zur Liste</a>
    · <a href="<?= e(u('/admin/analytics/campaigns/form?id=' . $id)) ?>">Bearbeiten</a>
  </p>
</header>

<?php foreach ($warnings as $w): ?>
  <p class="flash flash-warn"><?= e((string) $w) ?></p>
<?php endforeach; ?>

<nav class="ranges" aria-label="Zeitraum">
  <?php foreach ([7, 30, 90, 365] as $r): ?>
    <a class="chip" href="<?= e(u('/admin/analytics/campaigns/view?' . http_build_query(['id' => $id, 'r' => (string) $r]))) ?>" <?= $rangeLabel === (string) $r ? 'aria-current="page"' : '' ?>><?= $r ?> Tage</a>
  <?php endforeach; ?>
</nav>
<form method="get" action="<?= e(u('/admin/analytics/campaigns/view')) ?>" class="range-form">
  <input type="hidden" name="id" value="<?= $id ?>">
  <label>Von <input type="date" name="from" value="<?= e($d0->format('Y-m-d')) ?>"></label>
  <label>Bis <input type="date" name="to" value="<?= e($d1->format('Y-m-d')) ?>"></label>
  <button type="submit">Zeitraum</button>
</form>

<section class="panel admin-panel analytics-section analytics-two">
  <div>
    <h3>Tracking-Link</h3>
    <p><code id="campaign-url"><?= e($url) ?></code></p>
    <p>
      <button type="button" id="copy-campaign-url">Link kopieren</button>
    </p>
    <p class="muted">
      UTM: <code><?= e((string) $campaign['utm_source']) ?></code> /
      <code><?= e((string) $campaign['utm_medium']) ?></code> /
      <code><?= e((string) $campaign['utm_campaign']) ?></code>
      · Ziel: <code><?= e((string) $campaign['landing_path']) ?></code>
    </p>
    <p><strong>Besuche im Zeitraum:</strong> <?= $conn ? e($fmtNum($visits)) : '—' ?></p>
  </div>
  <div>
    <h3>QR-Code</h3>
    <div class="totp-qr" id="campaign-qr" data-uri="<?= e($url) ?>" aria-label="Kampagnen-QR"></div>
  </div>
</section>

<script src="<?= e(u('/assets/qrcode.min.js')) ?>"></script>
<script>
(() => {
  const el = document.getElementById('campaign-qr');
  const uri = el && el.getAttribute('data-uri');
  if (el && uri && typeof QRCode !== 'undefined') {
    new QRCode(el, { text: uri, width: 180, height: 180, correctLevel: QRCode.CorrectLevel.M });
  }
  const btn = document.getElementById('copy-campaign-url');
  const urlEl = document.getElementById('campaign-url');
  btn?.addEventListener('click', async () => {
    const text = urlEl?.textContent || '';
    try {
      await navigator.clipboard.writeText(text);
      btn.textContent = 'Kopiert';
      setTimeout(() => { btn.textContent = 'Link kopieren'; }, 1200);
    } catch (_) {
      window.prompt('Link kopieren:', text);
    }
  });
})();
</script>
