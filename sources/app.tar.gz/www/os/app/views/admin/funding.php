<header class="admin-head">
  <p class="eyebrow">Projektentwicklung</p>
  <h2>Förderung</h2>
  <p class="muted">Programme und Anträge. Fristen erzeugen später Push-/E-Mail-Erinnerungen. Keine Rechts- oder Steuerberatung.</p>
</header>
<div class="admin-split">
  <section class="panel">
    <h3>Programme</h3>
    <?php foreach ($programs as $p): ?>
      <article class="feed">
        <strong><?= e($p['name']) ?></strong>
        <span class="muted"><?= e($p['funder']) ?><?= $p['deadline'] ? ' · Frist ' . e($p['deadline']) : '' ?></span>
      </article>
    <?php endforeach; ?>
    <?php if (!$programs): ?><p class="muted">Noch keine Programme.</p><?php endif; ?>
    <form class="stack" method="post" action="/admin/foerderung" style="margin-top:1rem">
      <?= csrf_field() ?>
      <input type="hidden" name="kind" value="program">
      <input name="name" required placeholder="Programmname">
      <input name="funder" placeholder="Geber">
      <input type="date" name="deadline">
      <input name="max_amount" type="number" step="0.01" placeholder="Max. Summe EUR">
      <textarea name="requirements" rows="2" placeholder="Anforderungen"></textarea>
      <input name="url" placeholder="Link">
      <button type="submit">Programm anlegen</button>
    </form>
  </section>
  <section class="panel">
    <h3>Anträge</h3>
    <?php foreach ($apps as $a): ?>
      <article class="feed">
        <span class="chip"><?= e($a['status']) ?></span>
        <strong><?= e($a['project_title']) ?></strong>
        <span class="muted"><?= e($a['program_name'] ?? 'ohne Programm') ?> · <?= number_format($a['amount_cents']/100, 2, ',', '.') ?> €</span>
      </article>
    <?php endforeach; ?>
    <form class="stack" method="post" action="/admin/foerderung" style="margin-top:1rem">
      <?= csrf_field() ?>
      <input type="hidden" name="kind" value="application">
      <select name="project_id" required>
        <option value="">Projekt</option>
        <?php foreach ($projects as $p): ?><option value="<?= e($p['id']) ?>"><?= e($p['title']) ?></option><?php endforeach; ?>
      </select>
      <select name="program_id">
        <option value="">Programm (optional)</option>
        <?php foreach ($programs as $p): ?><option value="<?= e($p['id']) ?>"><?= e($p['name']) ?></option><?php endforeach; ?>
      </select>
      <select name="status">
        <?php foreach (['planned','in_progress','submitted','approved','rejected'] as $s): ?>
          <option value="<?= $s ?>"><?= $s ?></option>
        <?php endforeach; ?>
      </select>
      <input name="amount" type="number" step="0.01" placeholder="Beantragte Summe">
      <input name="note" placeholder="Notiz">
      <button type="submit">Antrag anlegen</button>
    </form>
  </section>
</div>
