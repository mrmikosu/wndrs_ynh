<?php
/** @var array $settings */
/** @var array|null $site */
/** @var array|null $cfg */
/** @var array|null $rep */
/** @var array $charts */
/** @var array $kpis */
/** @var array $warnings */
/** @var string $pythonUrl */
/** @var DateTimeImmutable $d0 */
/** @var DateTimeImmutable $d1 */
/** @var string $rangeLabel */
/** @var array $rows */
/** @var array{user:string,secret:string,uri:string,path:string}|null $totpSetup */
/** @var bool $totpDismissed */
$totpSetup = $totpSetup ?? null;
$totpDismissed = !empty($totpDismissed);

$fmtNum = static fn(int|float|null $value): string => number_format((float) ($value ?? 0), 0, ',', '.');
$fmtPct = static fn(int|float|null $value): string => $value === null ? '–' : number_format((float) $value * 100, 0, ',', '.') . ' %';
$fmtDur = static function (mixed $seconds): string {
    if ($seconds === null) {
        return '–';
    }
    $seconds = (int) round((float) $seconds);
    return $seconds >= 60 ? intdiv($seconds, 60) . ':' . sprintf('%02d', $seconds % 60) . ' min' : $seconds . ' s';
};
$fmtDelta = static function (?float $delta): string {
    if ($delta === null) {
        return 'kein Vergleich möglich';
    }
    return ($delta >= 0 ? '▲ ' : '▼ ') . number_format(abs($delta), 0, ',', '.') . ' % zum Vorzeitraum';
};
$originLines = is_array($cfg['origins'] ?? null) ? $cfg['origins'] : [];
$origins = implode("\n", array_map('strval', $originLines));
$query = http_build_query(array_filter([
    'r' => $rangeLabel !== 'custom' ? $rangeLabel : null,
    'from' => $rangeLabel === 'custom' ? $d0->format('Y-m-d') : null,
    'to' => $rangeLabel === 'custom' ? $d1->format('Y-m-d') : null,
], static fn($value): bool => $value !== null && $value !== ''));
$csvHref = static function (string $type) use ($query): string {
    $params = $query === '' ? [] : [];
    if ($query !== '') {
        parse_str($query, $params);
    }
    $params['t'] = $type;
    return '/admin/analytics/export.csv?' . http_build_query($params);
};
$hasData = $rep !== null && (($rep['tot']['vis'] ?? 0) > 0 || ($rep['tot']['pv'] ?? 0) > 0 || ($rep['tot']['ent'] ?? 0) > 0);
$siteLabel = $site ? e((string) $site['name']) . ' · ' . e((string) $site['domain']) : 'nicht konfiguriert';
?>
<header class="admin-head">
  <p class="eyebrow">Besucher</p>
  <h2>Besucher-Analyse</h2>
  <p class="muted">Site <?= $siteLabel ?> · <?= e($d0->format('d.m.Y')) ?> bis <?= e($d1->format('d.m.Y')) ?></p>
  <p class="admin-actions">
    <a href="/admin/analytics/sites">Sites verwalten</a>
    <?php if ($pythonUrl !== ''): ?> · <a href="<?= e($pythonUrl) ?>" target="_blank" rel="noopener">Erweiterte Analyse</a><?php endif; ?>
  </p>
</header>

<?php if ($totpSetup && !$totpDismissed): ?>
  <section class="panel admin-panel analytics-totp" id="analytics-totp-setup">
    <h3>Python-Dashboard · 2FA einrichten</h3>
    <p class="muted">Authenticator-App auf dem Handy (Aegis, 2FAS, Google Authenticator). QR scannen oder Secret manuell eintragen (zeitbasiert, 6 Stellen, SHA-1).</p>
    <div class="totp-grid">
      <div class="totp-qr" id="totp-qr" data-uri="<?= e($totpSetup['uri']) ?>" aria-label="TOTP QR-Code"></div>
      <div class="totp-meta">
        <?php if ($pythonUrl !== ''): ?>
          <p><strong>Login:</strong> <a href="<?= e($pythonUrl) ?>" target="_blank" rel="noopener"><?= e($pythonUrl) ?></a></p>
        <?php else: ?>
          <p class="muted">Python-URL unten in den Einstellungen setzen (Dashboard-Domain).</p>
        <?php endif; ?>
        <?php if ($totpSetup['user'] !== ''): ?>
          <p><strong>Benutzer:</strong> <code><?= e($totpSetup['user']) ?></code></p>
        <?php endif; ?>
        <p><strong>Passwort:</strong> das Admin-Passwort aus der Yunohost-/App-Installation (mind. 12 Zeichen).</p>
        <p><strong>Secret:</strong></p>
        <pre class="totp-secret"><?= e($totpSetup['secret']) ?></pre>
        <p class="muted" style="font-size:0.8rem">Quelle: <?= e((string) ($totpSetup['source'] ?? 'file')) ?></p>
        <form method="post" action="<?= e(u('/admin/analytics/totp-setup')) ?>" class="totp-actions">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="dismiss">
          <button type="submit">2FA eingerichtet — ausblenden</button>
        </form>
      </div>
    </div>
  </section>
  <script src="<?= e(u('/assets/qrcode.min.js')) ?>"></script>
  <script>
    (function () {
      function paintTotpQr() {
        var el = document.getElementById('totp-qr');
        if (!el || typeof QRCode === 'undefined') return;
        var uri = el.getAttribute('data-uri') || '';
        if (!uri) return;
        el.innerHTML = '';
        new QRCode(el, { text: uri, width: 180, height: 180, correctLevel: QRCode.CorrectLevel.M });
      }
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', paintTotpQr);
      } else {
        paintTotpQr();
      }
    })();
  </script>
<?php elseif ($totpSetup && $totpDismissed): ?>
  <div class="panel admin-panel muted totp-revealed">
    Dashboard-2FA-Hinweis ausgeblendet.
    <form method="post" action="<?= e(u('/admin/analytics/totp-setup')) ?>" class="inline-form">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="reveal">
      <button type="submit" class="linkish">Wieder anzeigen</button>
    </form>
  </div>
<?php else: ?>
  <section class="panel admin-panel analytics-totp">
    <h3>Python-Dashboard · 2FA</h3>
    <p class="muted">Kein TOTP-Secret gefunden (weder <code>dashboard/data/admin-totp.txt</code> noch Benutzer in <code>dashboard.db</code>). Nach Yunohost-Install oder mit:</p>
    <pre class="totp-secret">cd /var/www/wndrs/dashboard &amp;&amp; sudo -u wndrs .venv/bin/python manage.py reset-totp DEIN_USER
sudo cat /var/www/wndrs/dashboard/data/admin-totp.txt</pre>
    <p class="muted">Dann diese Seite neu laden. App-Code muss Version mit TotpSetup enthalten (<code>yunohost app upgrade wndrs</code>).</p>
  </section>
<?php endif; ?>

<?php if ($warnings): ?>
  <section class="panel admin-panel analytics-checklist">
    <h3>Setup-Checkliste</h3>
    <p class="muted">Die Auswertung bleibt leer, bis App-Setting, Site, Config und Datenbank erreichbar sind.</p>
    <ul>
      <?php foreach ($warnings as $warning): ?>
        <li><?= e($warning) ?></li>
      <?php endforeach; ?>
    </ul>
  </section>
<?php endif; ?>

<nav class="ranges" aria-label="Zeitraum">
  <?php foreach ([7, 30, 90, 365] as $r): ?>
    <a class="chip" href="/admin/analytics?r=<?= $r ?>" <?= $rangeLabel === (string) $r ? 'aria-current="page"' : '' ?>><?= $r ?> Tage</a>
  <?php endforeach; ?>
  <form method="get" action="/admin/analytics" class="range-form">
    <label>Von <input type="date" name="from" value="<?= e($d0->format('Y-m-d')) ?>" required></label>
    <label>Bis <input type="date" name="to" value="<?= e($d1->format('Y-m-d')) ?>" required></label>
    <button type="submit">Anzeigen</button>
  </form>
</nav>

<form method="post" action="/admin/analytics/settings" class="panel admin-panel analytics-settings">
  <?= csrf_field() ?>
  <input type="hidden" name="active_site_id" value="<?= e((string) ($site['id'] ?? $settings['analytics.active_site_id'])) ?>">
  <h3>Einstellungen</h3>
  <div class="settings-grid">
    <label class="check"><input type="checkbox" name="enabled" value="1" <?= $settings['analytics.enabled'] === '1' ? 'checked' : '' ?>> Analytics aktiv</label>
    <label class="check"><input type="checkbox" name="geo_enabled" value="1" <?= !empty($cfg['geo_enabled']) ? 'checked' : '' ?>> Geo-Auswertung aktiv</label>
    <label>Besucher-Modus
      <select name="visitor_mode">
        <option value="hash" <?= ($cfg['visitor_mode'] ?? 'hash') === 'hash' ? 'selected' : '' ?>>hash</option>
        <option value="off" <?= ($cfg['visitor_mode'] ?? '') === 'off' ? 'selected' : '' ?>>off</option>
      </select>
    </label>
    <label>Python-URL
      <input name="python_url" value="<?= e($pythonUrl) ?>" placeholder="https://...">
    </label>
    <label class="span-2">Erlaubte Origins
      <textarea name="origins" rows="4"><?= e($origins) ?></textarea>
    </label>
  </div>
  <button type="submit">Speichern</button>
</form>

<?php if (!$hasData): ?>
  <p class="panel admin-panel muted">Für diesen Zeitraum liegen keine Daten vor. Prüfe, ob das Script-Tag eingebunden ist und der letzte Abruf erfolgreich war.</p>
<?php endif; ?>

<div class="kpis">
  <?php foreach ($kpis as $kpi): ?>
    <article class="kpi">
      <div class="t"><?= e((string) $kpi['title']) ?></div>
      <div class="v"><?= e((string) $kpi['value']) ?></div>
      <div class="d"><?= e($fmtDelta($kpi['delta'])) ?></div>
    </article>
  <?php endforeach; ?>
</div>

<section class="panel admin-panel analytics-section">
  <div class="panel-head">
    <h3>Verlauf pro Tag</h3>
    <a href="<?= e($csvHref('days')) ?>">CSV Export</a>
  </div>
  <div class="legend"><span><i class="k1"></i>Tagesbesucher</span><span><i class="k2"></i>Seitenaufrufe</span></div>
  <?= $charts['daily'] ?? '<p class="muted">Noch keine Messdaten.</p>' ?>
</section>

<section class="panel admin-panel analytics-section">
  <div class="panel-head">
    <h3>Seiten</h3>
    <a href="<?= e($csvHref('pages')) ?>">CSV Export</a>
  </div>
  <div class="scroll">
    <table class="admin-table">
      <caption>Meistbesuchte Seiten</caption>
      <thead><tr><th>Seite</th><th class="num">Aufrufe</th><th class="num">Einstiege</th><th class="num">Ausstiege</th><th class="num">Ausstiegsrate</th><th class="num">Ø Verweildauer</th></tr></thead>
      <tbody>
        <?php foreach (($rep['pages'] ?? []) as $page): ?>
          <tr>
            <td class="path"><?= e((string) $page['path']) ?></td>
            <td class="num"><?= e($fmtNum((int) $page['pv'])) ?></td>
            <td class="num"><?= e($fmtNum((int) $page['ent'])) ?></td>
            <td class="num"><?= e($fmtNum((int) $page['exits'])) ?></td>
            <td class="num"><?= e($fmtPct($page['exit_rate'])) ?></td>
            <td class="num"><?= e($fmtDur($page['avg'])) ?></td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($rep['pages'])): ?><tr><td colspan="6">Keine Daten.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

<div class="admin-cols analytics-two">
  <section class="panel admin-panel">
    <h3>Herkunft nach Kanal</h3>
    <?= $charts['channels'] ?? '<p class="muted">Keine Daten.</p>' ?>
    <table class="admin-table compact"><thead><tr><th>Kanal</th><th class="num">Einstiege</th></tr></thead><tbody>
      <?php foreach (($rep['channels'] ?? []) as $channel): ?><tr><td><?= e((string) $channel[0]) ?></td><td class="num"><?= e($fmtNum((int) $channel[1])) ?></td></tr><?php endforeach; ?>
      <?php if (empty($rep['channels'])): ?><tr><td colspan="2">Keine Daten.</td></tr><?php endif; ?>
    </tbody></table>
  </section>
  <section class="panel admin-panel">
    <div class="panel-head">
      <h3>Quellen</h3>
      <a href="<?= e($csvHref('sources')) ?>">CSV Export</a>
    </div>
    <table class="admin-table"><thead><tr><th>Quelle</th><th>Kanal</th><th class="num">Einstiege</th></tr></thead><tbody>
      <?php foreach (($rep['sources'] ?? []) as $source): ?><tr><td class="path"><?= e((string) $source['ref']) ?></td><td><?= e((string) $source['channel']) ?></td><td class="num"><?= e($fmtNum((int) $source['n'])) ?></td></tr><?php endforeach; ?>
      <?php if (empty($rep['sources'])): ?><tr><td colspan="3">Keine Daten.</td></tr><?php endif; ?>
    </tbody></table>
  </section>
</div>

<div class="admin-cols analytics-two">
  <section class="panel admin-panel">
    <h3>Kampagnen (UTM)</h3>
    <table class="admin-table"><thead><tr><th>Quelle</th><th>Medium / Kampagne</th><th class="num">Einstiege</th></tr></thead><tbody>
      <?php foreach (($rep['utm'] ?? []) as $utm): ?><tr><td class="path"><?= e((string) $utm['source']) ?></td><td class="path"><?= e((string) $utm['medium']) ?></td><td class="num"><?= e($fmtNum((int) $utm['n'])) ?></td></tr><?php endforeach; ?>
      <?php if (empty($rep['utm'])): ?><tr><td colspan="3">Keine Kampagnen-Links erkannt.</td></tr><?php endif; ?>
    </tbody></table>
  </section>
  <section class="panel admin-panel">
    <h3>Klicks</h3>
    <table class="admin-table"><thead><tr><th>Art</th><th>Ziel</th><th class="num">Klicks</th></tr></thead><tbody>
      <?php foreach (($rep['clicks'] ?? []) as $click): ?><tr><td><?= e((string) $click['kind']) ?></td><td class="path"><?= e((string) $click['target']) ?></td><td class="num"><?= e($fmtNum((int) $click['n'])) ?></td></tr><?php endforeach; ?>
      <?php if (empty($rep['clicks'])): ?><tr><td colspan="3">Keine Klicks erfasst.</td></tr><?php endif; ?>
    </tbody></table>
  </section>
</div>

<section class="panel admin-panel analytics-section">
  <h3>Wege von Seite zu Seite</h3>
  <p class="muted">Die zwölf häufigsten Übergänge. Je breiter das Band, desto häufiger der Weg.</p>
  <?= $rep !== null ? \Analytics\Charts::flow($rep['flow'] ?? []) : '<p class="muted">Keine Übergänge erfasst.</p>' ?>
  <details>
    <summary>Als Tabelle</summary>
    <div class="scroll"><table class="admin-table"><thead><tr><th>Von</th><th>Nach</th><th class="num">Übergänge</th></tr></thead><tbody>
      <?php foreach (($rep['trans'] ?? []) as $transition): ?><tr><td class="path"><?= e((string) $transition['a']) ?></td><td class="path"><?= e((string) $transition['b']) ?></td><td class="num"><?= e($fmtNum((int) $transition['n'])) ?></td></tr><?php endforeach; ?>
      <?php if (empty($rep['trans'])): ?><tr><td colspan="3">Keine Daten.</td></tr><?php endif; ?>
    </tbody></table></div>
  </details>
</section>

<section class="panel admin-panel analytics-section">
  <h3>Geräte und Sprache</h3>
  <?php if (($rep['dev_total'] ?? 0) === 0): ?>
    <p class="muted">Keine Gerätedaten im Zeitraum. Sie werden nur erfasst, wenn <code>device_stats</code> in der <code>config.php</code> auf <code>true</code> steht.</p>
  <?php else: ?>
    <p class="muted">Je Tagesbesucher einmal gezählt, bei <code>visitor_mode: off</code> je Aufruf (grobe Klassen aus Browserkennung und Browsersprache, nichts davon wird einzeln gespeichert). Die Browsersprache ist eine Näherung, kein Standort.</p>
    <div class="analytics-bars">
      <div><h4>Gerät</h4><?= \Analytics\Charts::shareBars($rep['devices'] ?? []) ?></div>
      <div><h4>Betriebssystem</h4><?= \Analytics\Charts::shareBars($rep['systems'] ?? []) ?></div>
      <div><h4>Browser</h4><?= \Analytics\Charts::shareBars($rep['browsers'] ?? []) ?></div>
      <div><h4>Browsersprache</h4><?= \Analytics\Charts::shareBars($rep['langs'] ?? []) ?></div>
    </div>
  <?php endif; ?>
  <p class="muted">Als Bots erkannte Aufrufe (nicht in den Zahlen oben enthalten): <?= e($fmtNum((int) ($rep['bots'] ?? 0))) ?><?php if (($rep['bot_share'] ?? null) !== null): ?> · <?= e(number_format((float) $rep['bot_share'] * 100, 0, ',', '.')) ?> % aller Aufrufe<?php endif; ?>. Bots, die kein JavaScript ausführen, sieht der Tracker gar nicht.</p>
</section>

<section class="panel admin-panel analytics-section">
  <div class="panel-head">
    <h3>Länder</h3>
    <a href="<?= e($csvHref('countries')) ?>">CSV Export</a>
  </div>
  <?php if (empty($cfg['geo_enabled'])): ?>
    <p class="muted">Geo-Auswertung ist deaktiviert.</p>
  <?php elseif (empty($rep['countries'])): ?>
    <p class="muted">Keine Länderdaten im Zeitraum.</p>
  <?php else: ?>
    <?= \Analytics\Charts::shareBars($rep['countries']) ?>
  <?php endif; ?>
</section>

<section class="panel admin-panel analytics-section">
  <h3>Seitenaufrufe nach Tageszeit</h3>
  <?= $charts['hours'] ?? '<p class="muted">Noch keine Messdaten.</p>' ?>
</section>

<details class="panel admin-panel analytics-section">
  <summary>Tabellenansicht pro Tag</summary>
  <div class="scroll">
    <table class="admin-table">
      <thead><tr><th>Datum</th><th class="num">Tagesbesucher</th><th class="num">Aufrufe</th><th class="num">Einstiege</th></tr></thead>
      <tbody>
        <?php foreach ($rows as $row): ?>
          <tr><td><?= e((string) $row['day']) ?></td><td class="num"><?= e($fmtNum((int) $row['vis'])) ?></td><td class="num"><?= e($fmtNum((int) $row['pv'])) ?></td><td class="num"><?= e($fmtNum((int) $row['ent'])) ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?><tr><td colspan="4">Keine Daten.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</details>

<p class="note">So sind die Zahlen zu lesen: „Tagesbesucher“ zählt jeden Besucher einmal pro Tag (anonymer Tages-Hash, nach 24 h unwiederbringlich); die Summe über mehrere Tage zählt wiederkehrende Personen mehrfach. „Einstiege“ sind Aufrufe ohne interne Vorgängerseite und entsprechen näherungsweise den Besuchen. „Ausstiege“ werden aus Aufrufen minus Übergängen zu weiteren Seiten berechnet. Es gibt keine Sitzungen und keine Wiedererkennung.</p>
