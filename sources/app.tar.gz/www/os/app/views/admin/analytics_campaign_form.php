<?php
/** @var array|null $edit */
/** @var string $origin */
/** @var array|null $site */
$edit = $edit ?? null;
$isEdit = is_array($edit);
$name = $isEdit ? (string) $edit['name'] : '';
$landing = $isEdit ? (string) $edit['landing_path'] : '/';
$source = $isEdit ? (string) $edit['utm_source'] : '';
$medium = $isEdit ? (string) $edit['utm_medium'] : '';
$campaign = $isEdit ? (string) $edit['utm_campaign'] : '';
?>
<header class="admin-head">
  <p class="eyebrow">Besucher</p>
  <h2><?= $isEdit ? 'Kampagne bearbeiten' : 'Neue Kampagne' ?></h2>
  <p class="admin-actions"><a href="<?= e(u('/admin/analytics/campaigns')) ?>">Zurück zur Liste</a></p>
</header>

<form method="post" action="<?= e(u('/admin/analytics/campaigns')) ?>" class="panel admin-panel analytics-settings" id="campaign-form">
  <?= csrf_field() ?>
  <?php if ($isEdit): ?>
    <input type="hidden" name="id" value="<?= (int) $edit['id'] ?>">
  <?php endif; ?>

  <label>Name
    <input type="text" name="name" required maxlength="120" value="<?= e($name) ?>" placeholder="z. B. Instagram Poster Frühling">
  </label>
  <label>Zielseite (relativ)
    <input type="text" name="landing_path" required maxlength="200" value="<?= e($landing) ?>" placeholder="/ oder /#kontakt">
  </label>
  <label>utm_source
    <input type="text" name="utm_source" required maxlength="40" value="<?= e($source) ?>" placeholder="instagram" data-utm>
  </label>
  <label>utm_medium
    <input type="text" name="utm_medium" required maxlength="40" value="<?= e($medium) ?>" placeholder="social" data-utm>
  </label>
  <label>utm_campaign
    <input type="text" name="utm_campaign" required maxlength="40" value="<?= e($campaign) ?>" placeholder="fruehling-2026" data-utm>
  </label>

  <p class="muted">Vorschau-URL</p>
  <p><code id="campaign-preview" data-origin="<?= e(rtrim($origin, '/')) ?>"><?= e($origin) ?>/</code></p>

  <button type="submit"><?= $isEdit ? 'Speichern' : 'Anlegen' ?></button>
</form>

<script>
(() => {
  const form = document.getElementById('campaign-form');
  const preview = document.getElementById('campaign-preview');
  if (!form || !preview) return;
  const origin = preview.getAttribute('data-origin') || '';
  const update = () => {
    const landing = (form.landing_path.value || '/').trim() || '/';
    let path = landing.startsWith('/') ? landing : '/' + landing;
    let hash = '';
    const hi = path.indexOf('#');
    if (hi >= 0) { hash = path.slice(hi + 1); path = path.slice(0, hi) || '/'; }
    const q = new URLSearchParams({
      utm_source: form.utm_source.value || '',
      utm_medium: form.utm_medium.value || '',
      utm_campaign: form.utm_campaign.value || '',
    });
    preview.textContent = origin + path + '?' + q.toString() + (hash ? '#' + hash : '');
  };
  form.addEventListener('input', update);
  update();
})();
</script>
