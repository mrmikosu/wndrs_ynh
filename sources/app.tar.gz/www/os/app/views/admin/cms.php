<h2>CMS / Pages</h2>
<ul class="list panel">
<?php foreach ($pages as $p): ?>
  <li><a href="/admin/cms?slug=<?= e(urlencode($p['slug'])) ?>"><?= e($p['slug']) ?></a> — <?= e($p['title']) ?> <span class="chip"><?= e($p['status']) ?></span></li>
<?php endforeach; ?>
</ul>
<?php
$slug = $edit['slug'] ?? 'home';
$title = $edit['title'] ?? '';
$status = $edit['status'] ?? 'draft';
$blocks = $edit['blocks'] ?? json_encode([['type'=>'hero','eyebrow'=>'WNDRS','headline'=>'…']], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
if (is_array(json_decode((string)$blocks, true))) {
  $blocks = json_encode(json_decode((string)$blocks, true), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
}
?>
<form class="stack panel" method="post" action="/admin/cms">
  <?= csrf_field() ?>
  <input name="slug" value="<?= e($slug) ?>" required>
  <input name="title" value="<?= e($title) ?>" required>
  <select name="status">
    <option value="draft" <?= $status==='draft'?'selected':'' ?>>draft</option>
    <option value="published" <?= $status==='published'?'selected':'' ?>>published</option>
  </select>
  <textarea name="blocks_json" rows="14"><?= e((string)$blocks) ?></textarea>
  <button type="submit">Speichern / Publish</button>
</form>
