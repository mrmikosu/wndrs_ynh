<header class="admin-head">
  <p class="eyebrow">Netzwerk</p>
  <h2>Kontakte & Pipeline</h2>
</header>
<div class="admin-split">
  <section class="panel">
    <h3>Kontakte</h3>
    <?php foreach ($contacts as $c): ?>
      <article class="feed">
        <span class="chip"><?= e($c['kind']) ?></span>
        <strong><?= e($c['name']) ?></strong>
        <span class="muted"><?= e($c['org']) ?> <?= e($c['email']) ?></span>
      </article>
    <?php endforeach; ?>
    <form class="stack" method="post" action="/admin/crm" style="margin-top:1rem">
      <?= csrf_field() ?>
      <input type="hidden" name="kind" value="contact">
      <select name="contact_kind">
        <?php foreach (['location','artist','vendor','sponsor','funder','authority','press','partner'] as $k): ?>
          <option value="<?= $k ?>"><?= $k ?></option>
        <?php endforeach; ?>
      </select>
      <input name="name" required placeholder="Name">
      <input name="org" placeholder="Organisation">
      <input name="email" type="email" placeholder="E-Mail">
      <input name="phone" placeholder="Telefon">
      <textarea name="note" rows="2"></textarea>
      <button type="submit">Kontakt anlegen</button>
    </form>
  </section>
  <section class="panel">
    <h3>Pipeline</h3>
    <?php foreach ($deals as $d): ?>
      <article class="feed">
        <span class="chip"><?= e($d['stage']) ?></span>
        <strong><?= e($d['contact_name']) ?></strong>
        <span class="muted"><?= e($d['project_title'] ?? 'ohne Projekt') ?> · <?= e($d['next_step']) ?></span>
      </article>
    <?php endforeach; ?>
    <form class="stack" method="post" action="/admin/crm" style="margin-top:1rem">
      <?= csrf_field() ?>
      <input type="hidden" name="kind" value="deal">
      <select name="contact_id" required>
        <option value="">Kontakt</option>
        <?php foreach ($contacts as $c): ?><option value="<?= e($c['id']) ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
      </select>
      <select name="project_id">
        <option value="">Projekt optional</option>
        <?php foreach ($projects as $p): ?><option value="<?= e($p['id']) ?>"><?= e($p['title']) ?></option><?php endforeach; ?>
      </select>
      <select name="stage">
        <?php foreach (['contact','offer','negotiation','won','lost'] as $s): ?><option value="<?= $s ?>"><?= $s ?></option><?php endforeach; ?>
      </select>
      <input name="next_step" placeholder="Nächster Schritt">
      <input name="note" placeholder="Notiz">
      <button type="submit">Deal anlegen</button>
    </form>
  </section>
</div>
