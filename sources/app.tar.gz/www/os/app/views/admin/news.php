<header class="admin-head">
  <p class="eyebrow">Website</p>
  <h2>News</h2>
  <p class="muted">Nur Beiträge mit Status „published“ und „auf www“ erscheinen unter <a href="/news" target="_blank" rel="noopener">/news</a>.</p>
</header>
<div class="admin-split">
  <section class="panel admin-panel">
    <?php if (!$rows): ?><p class="muted">Noch keine News.</p><?php endif; ?>
    <?php foreach ($rows as $row): ?>
      <a class="feed <?= ($edit['id'] ?? '') === $row['id'] ? 'is-current' : '' ?>" href="/admin/news?id=<?= e(urlencode($row['id'])) ?>">
        <span class="chip"><?= e($row['status']) ?><?= !empty($row['public']) ? ' · www' : '' ?></span>
        <strong><?= e($row['title']) ?></strong>
      </a>
    <?php endforeach; ?>
    <p><a href="/admin/news">Neuer Beitrag</a></p>
  </section>
  <form class="stack panel" method="post" action="/admin/news">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
    <label>Titel<input name="title" required value="<?= e($edit['title'] ?? '') ?>"></label>
    <label>Text<textarea name="body" rows="8"><?= e($edit['body'] ?? '') ?></textarea></label>
    <label>Status
      <select name="status">
        <?php foreach (['draft' => 'Entwurf', 'published' => 'Veröffentlicht'] as $value => $label): ?>
          <option value="<?= e($value) ?>" <?= ($edit['status'] ?? 'draft') === $value ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label class="check"><input type="checkbox" name="public" value="1" <?= !empty($edit['public']) ? 'checked' : '' ?>> Auf der Website zeigen</label>
    <button type="submit"><?= $edit ? 'Speichern' : 'Anlegen' ?></button>
  </form>
</div>
<?php if ($edit): ?>
  <form method="post" action="/admin/news/delete" class="inline-form">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= e($edit['id']) ?>">
    <button type="submit">Diesen Beitrag löschen</button>
  </form>
<?php endif; ?>
