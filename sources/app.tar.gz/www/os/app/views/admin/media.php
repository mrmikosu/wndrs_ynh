<h2>Medien</h2>
<form class="stack panel" method="post" action="/admin/medien" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <input type="file" name="file" required>
  <select name="acl"><option>members</option><option>public</option><option>admin</option></select>
  <button type="submit">Upload</button>
</form>
<table>
  <thead><tr><th>Datei</th><th>ACL</th><th>Pfad</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['filename']) ?></td>
      <td><?= e($r['acl']) ?></td>
      <td><a href="<?= e($r['path']) ?>"><?= e($r['path']) ?></a></td>
      <td>
        <form method="post" action="/admin/medien/delete">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= e($r['id']) ?>">
          <button type="submit">Löschen</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
