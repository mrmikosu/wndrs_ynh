<header class="admin-head">
  <p class="eyebrow">Öffentlichkeit</p>
  <h2>Inhalte</h2>
  <p class="muted">Von hier aus landen Seiten, News, Events, Profile, Jobs und Medien auf der Website oder im Mitgliederbereich.</p>
</header>
<div class="link-grid">
  <?php foreach ($cards as $card): ?>
    <article class="link-card">
      <a href="<?= e($card['href']) ?>">
        <span class="muted"><?= e($card['label']) ?></span>
        <strong class="stat-value"><?= (int) $card['value'] ?></strong>
        <span><?= e($card['text']) ?></span>
      </a>
      <a class="preview" href="<?= e($card['preview']) ?>" target="_blank" rel="noopener">Vorschau</a>
    </article>
  <?php endforeach; ?>
</div>
