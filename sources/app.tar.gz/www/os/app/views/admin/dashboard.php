<header class="admin-head">
  <p class="eyebrow">Heute</p>
  <h2>Was gerade zusammenhängt</h2>
  <p class="muted">Freigaben, Öffentlichkeit und das, was zuletzt im Kollektiv passiert ist.</p>
</header>

<div class="stat-grid">
  <?php foreach ($stats as $stat): ?>
    <a class="stat" href="<?= e($stat['href']) ?>">
      <span class="muted"><?= e($stat['label']) ?></span>
      <strong class="stat-value"><?= (int) $stat['value'] ?></strong>
      <span class="stat-hint"><?= e($stat['hint']) ?></span>
    </a>
  <?php endforeach; ?>
</div>

<div class="admin-cols">
  <section class="panel admin-panel">
    <div class="panel-head">
      <h3>Braucht dich<?= $attention ? ' · ' . (int) $attention : '' ?></h3>
      <a href="/admin/bewerbungen">Alle Warteschlangen</a>
    </div>
    <?php if (!$attention): ?>
      <p class="muted">Nichts liegt auf Halde. Bewerbungen, Zeiten, Auslagen und Geräteanfragen sind leer.</p>
    <?php endif; ?>

    <?php foreach ($applications as $row): ?>
      <article class="queue">
        <div>
          <span class="chip">Bewerbung</span>
          <strong><?= e($row['name']) ?></strong>
          <p class="muted"><?= e($row['email']) ?></p>
        </div>
        <form method="post" action="/admin/bewerbungen">
          <?= csrf_field() ?>
          <input type="hidden" name="return" value="/admin">
          <input type="hidden" name="id" value="<?= e($row['id']) ?>">
          <button name="decision" value="accepted">Annehmen</button>
          <button name="decision" value="rejected">Ablehnen</button>
        </form>
      </article>
    <?php endforeach; ?>

    <?php foreach ($times as $row): ?>
      <article class="queue">
        <div>
          <span class="chip">Zeit</span>
          <strong><?= e($row['display_name']) ?></strong>
          <p class="muted"><?= e($row['work_date']) ?> · <?= number_format(((int) $row['minutes']) / 60, 2, ',', '.') ?> h<?= $row['project_title'] ? ' · ' . e($row['project_title']) : '' ?></p>
        </div>
        <form method="post" action="/admin/zeit">
          <?= csrf_field() ?>
          <input type="hidden" name="return" value="/admin">
          <input type="hidden" name="id" value="<?= e($row['id']) ?>">
          <button name="status" value="approved">Freigeben</button>
          <button name="status" value="rejected">Zurück</button>
        </form>
      </article>
    <?php endforeach; ?>

    <?php foreach ($expenses as $row): ?>
      <article class="queue">
        <div>
          <span class="chip">Auslage</span>
          <strong><?= e($row['title']) ?></strong>
          <p class="muted"><?= e($row['display_name']) ?> · <?= number_format(((int) $row['amount_cents']) / 100, 2, ',', '.') ?> €</p>
        </div>
        <?php if (Rbac::can($user['roles'], 'finance.approve')): ?>
          <form method="post" action="/admin/expenses/decide">
            <?= csrf_field() ?>
            <input type="hidden" name="return" value="/admin">
            <input type="hidden" name="id" value="<?= e($row['id']) ?>">
            <label class="muted">Begründung (Pflicht bei Ablehnung)
              <input type="text" name="note">
            </label>
            <button name="status" value="approved">Freigeben</button>
            <button name="status" value="rejected">Ablehnen</button>
          </form>
        <?php endif; ?>
      </article>
    <?php endforeach; ?>

    <?php foreach ($reservations as $row): ?>
      <article class="queue">
        <div>
          <span class="chip">Gerät</span>
          <strong><?= e($row['asset_name']) ?></strong>
          <p class="muted"><?= e($row['display_name']) ?> · <?= e($row['starts_at']) ?></p>
        </div>
        <?php if (Rbac::can($user['roles'], 'equipment.approve')): ?>
          <form method="post" action="/admin/equipment/approve">
            <?= csrf_field() ?>
            <input type="hidden" name="return" value="/admin">
            <input type="hidden" name="id" value="<?= e($row['id']) ?>">
            <button name="status" value="approved">Zusagen</button>
            <button name="status" value="rejected">Ablehnen</button>
          </form>
        <?php endif; ?>
      </article>
    <?php endforeach; ?>
  </section>

  <div class="admin-stack">
    <section class="panel admin-panel">
      <div class="panel-head">
        <h3>Öffentlichkeit</h3>
        <a href="/admin/inhalte">Inhalte</a>
      </div>
      <?php if (!$news && !$events): ?>
        <p class="muted">Noch keine News oder Events. <a href="/admin/news">News anlegen</a></p>
      <?php endif; ?>
      <?php foreach ($news as $row): ?>
        <a class="feed" href="/admin/news?id=<?= e(urlencode($row['id'])) ?>">
          <span class="chip"><?= e($row['status']) ?><?= !empty($row['public']) ? ' · www' : '' ?></span>
          <strong><?= e($row['title']) ?></strong>
        </a>
      <?php endforeach; ?>
      <?php foreach ($events as $row): ?>
        <a class="feed" href="/admin/events?id=<?= e(urlencode($row['id'])) ?>">
          <span class="chip">Event<?= $row['project_title'] ? ' · ' . e($row['project_title']) : '' ?></span>
          <strong><?= e($row['title']) ?></strong>
        </a>
      <?php endforeach; ?>
    </section>

    <section class="panel admin-panel">
      <div class="panel-head">
        <h3>Protokoll</h3>
        <a href="/admin/audit">Alles</a>
      </div>
      <?php foreach ($activity as $row): ?>
        <?php $href = admin_entity_href((string) $row['entity_type'], (string) $row['entity_id']); ?>
        <a class="feed" href="<?= e($href ?? '/admin/audit') ?>">
          <span class="muted"><?= e($row['display_name'] ?? 'System') ?> · <?= e($row['created_at']) ?></span>
          <strong><?= e($row['action']) ?></strong>
        </a>
      <?php endforeach; ?>
      <?php if (!$activity): ?><p class="muted">Noch keine Einträge.</p><?php endif; ?>
    </section>
  </div>
</div>
