<p class="eyebrow">Control Center</p>
<div class="task-card__top" style="margin-bottom:1rem">
  <h2 style="margin:0">Mitgliederverwaltung</h2>
  <a class="btn" href="/admin/invites">Invites →</a>
</div>

<form method="get" action="/admin/mitglieder" class="panel" style="clip-path:none;margin-bottom:1rem">
  <div class="row-2">
    <input type="search" name="q" value="<?= e($q ?? '') ?>" placeholder="Suche Name / E-Mail">
    <select name="status" onchange="this.form.submit()">
      <option value="">Alle Status</option>
      <?php foreach ($statusOptions as $s): ?>
        <option value="<?= e($s) ?>" <?= ($filter ?? '') === $s ? 'selected' : '' ?>><?= e($s) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button type="submit" style="margin-top:.5rem">Filtern</button>
</form>

<div class="grid" style="grid-template-columns:1.1fr .9fr;align-items:start">
  <section>
    <table>
      <thead><tr><th>Name</th><th>E-Mail</th><th>Status</th><th>Rollen</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td>
            <?= e($r['display_name']) ?>
            <?php if (!(int)$r['is_active']): ?><span class="chip">inaktiv</span><?php endif; ?>
          </td>
          <td><?= e($r['email']) ?></td>
          <td><span class="chip"><?= e($r['membership_status'] ?? '—') ?></span></td>
          <td style="font-size:.8rem"><?= e($r['roles'] ?? '') ?></td>
          <td><a class="btn" href="/admin/mitglieder?id=<?= e($r['id']) ?>">Bearbeiten</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php if (!$rows): ?><p class="muted">Keine Treffer.</p><?php endif; ?>
  </section>

  <section>
    <?php if ($edit): ?>
      <form class="stack panel" method="post" action="/admin/mitglieder" style="clip-path:none">
        <?= csrf_field() ?>
        <h3>Bearbeiten</h3>
        <input type="hidden" name="id" value="<?= e($edit['id']) ?>">
        <label class="muted">Name</label>
        <input name="display_name" value="<?= e($edit['display_name']) ?>" required>
        <label class="muted">E-Mail</label>
        <input type="email" name="email" value="<?= e($edit['email']) ?>" required>
        <label class="muted">Mitgliedschaft</label>
        <select name="membership_status">
          <?php foreach ($statusOptions as $s): ?>
            <option value="<?= e($s) ?>" <?= ($edit['membership_status'] ?? '') === $s ? 'selected' : '' ?>><?= e($s) ?></option>
          <?php endforeach; ?>
        </select>
        <label><input type="checkbox" name="is_active" value="1" <?= (int)$edit['is_active'] ? 'checked' : '' ?>> Account aktiv</label>
        <p class="muted" style="margin:0">Rollen</p>
        <div style="display:flex;flex-wrap:wrap;gap:.55rem">
          <?php foreach ($roleOptions as $role): ?>
            <label class="chip" style="cursor:pointer">
              <input type="checkbox" name="roles[]" value="<?= e($role) ?>" <?= in_array($role, $editRoles, true) ? 'checked' : '' ?>>
              <?= e($role) ?>
            </label>
          <?php endforeach; ?>
        </div>
        <p class="muted" style="font-size:.75rem;margin:0">Kreise: <code>member</code> → <code>team</code> → <code>admin</code></p>
        <button class="btn-accent" type="submit">Speichern</button>
      </form>

      <form class="stack panel" method="post" action="/admin/mitglieder/password" style="clip-path:none;margin-top:.75rem">
        <?= csrf_field() ?>
        <h3>Passwort setzen</h3>
        <input type="hidden" name="id" value="<?= e($edit['id']) ?>">
        <input type="password" name="password" minlength="8" required placeholder="Neues Passwort">
        <button type="submit">Passwort speichern</button>
      </form>
    <?php else: ?>
      <p class="muted panel" style="clip-path:none">Mitglied in der Liste wählen zum Bearbeiten.</p>
    <?php endif; ?>

    <form class="stack panel" method="post" action="/admin/mitglieder/create" style="clip-path:none;margin-top:.75rem">
      <?= csrf_field() ?>
      <h3>Neu anlegen</h3>
      <input name="display_name" placeholder="Name" required>
      <input type="email" name="email" placeholder="E-Mail" required>
      <input type="password" name="password" minlength="8" placeholder="Passwort (min. 8)" required>
      <div style="display:flex;flex-wrap:wrap;gap:.55rem">
        <?php foreach ($roleOptions as $role): ?>
          <label class="chip" style="cursor:pointer">
            <input type="checkbox" name="roles[]" value="<?= e($role) ?>" <?= $role === 'member' ? 'checked' : '' ?>>
            <?= e($role) ?>
          </label>
        <?php endforeach; ?>
      </div>
      <button class="btn-accent" type="submit">Anlegen</button>
    </form>
  </section>
</div>
