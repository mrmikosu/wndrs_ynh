<h2>Bewerbungen</h2>
<?php foreach ($rows as $r): ?>
  <article class="panel">
    <h3><?= e($r['name']) ?> · <?= e($r['email']) ?></h3>
    <p class="muted">
      <?= e($r['status'] === 'pending' ? 'offen' : ($r['status'] === 'accepted' ? 'angenommen' : 'abgelehnt')) ?> · <?= e($r['created_at']) ?>
      <?php if (($r['decision_note'] ?? '') !== ''): ?>· Begründung: <?= e($r['decision_note']) ?><?php endif; ?>
    </p>
    <p><?= nl2br(e($r['message'])) ?></p>
    <?php if ($r['status'] === 'pending'): ?>
      <form method="post" action="/admin/bewerbungen" style="display:flex;gap:.5rem;align-items:center">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= e($r['id']) ?>">
        <label class="muted" for="note-<?= e($r['id']) ?>">Begründung (Pflicht bei Ablehnung)</label>
        <input type="text" id="note-<?= e($r['id']) ?>" name="note">
        <button name="decision" value="accepted">Annehmen</button>
        <button name="decision" value="rejected">Ablehnen</button>
      </form>
    <?php endif; ?>
  </article>
<?php endforeach; ?>
<?php if (!$rows): ?><p class="muted">Keine Bewerbungen.</p><?php endif; ?>
