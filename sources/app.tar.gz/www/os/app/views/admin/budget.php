<h2>Projektbudget</h2>

<form method="get" action="/admin/budget" style="margin:1rem 0">
  <label>Projekt
    <select name="project_id" onchange="this.form.submit()">
      <option value="">— wählen —</option>
      <?php foreach ($projects as $p): ?>
        <option value="<?= e($p['id']) ?>" <?= $projectId === $p['id'] ? 'selected' : '' ?>><?= e($p['title']) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
</form>

<?php if ($projectId && $project): ?>
  <div class="stat-grid" style="margin-bottom:1rem">
    <div class="stat panel">
      <span class="muted">Geplant</span>
      <strong><?= number_format($totals['planned'] / 100, 2, ',', '.') ?> €</strong>
    </div>
    <div class="stat panel">
      <span class="muted">Ist</span>
      <strong><?= number_format($totals['actual'] / 100, 2, ',', '.') ?> €</strong>
    </div>
  </div>

  <section class="panel" style="margin-bottom:1rem">
    <h3>Neue Position</h3>
    <form method="post" action="/admin/budget" class="stack">
      <?= csrf_field() ?>
      <input type="hidden" name="project_id" value="<?= e($projectId) ?>">
      <input type="hidden" name="form_action" value="save">
      <label>Titel <input name="title" required></label>
      <label>Art
        <select name="kind"><option value="cost">Kosten</option><option value="revenue">Einnahme</option></select>
      </label>
      <label>Kategorie <input name="category" value="other"></label>
      <label>Szenario <input name="scenario" value="base"></label>
      <label>Geplant (€) <input name="amount" type="number" step="0.01" min="0"></label>
      <label>Ist (€) <input name="actual" type="number" step="0.01" min="0"></label>
      <label>Notiz <input name="note"></label>
      <button type="submit">Anlegen</button>
    </form>
  </section>

  <table class="list" style="width:100%">
    <thead>
      <tr>
        <th>Titel</th>
        <th>Art</th>
        <th>Geplant</th>
        <th>Ist</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $it): ?>
        <tr>
          <td>
            <strong><?= e($it['title']) ?></strong>
            <span class="muted"><?= e($it['category']) ?> / <?= e($it['scenario']) ?></span>
          </td>
          <td><?= e($it['kind']) ?></td>
          <td><?= number_format(((int) $it['amount_cents']) / 100, 2, ',', '.') ?> €</td>
          <td><?= number_format(((int) $it['actual_cents']) / 100, 2, ',', '.') ?> €</td>
          <td>
            <form method="post" action="/admin/budget" style="display:inline">
              <?= csrf_field() ?>
              <input type="hidden" name="project_id" value="<?= e($projectId) ?>">
              <input type="hidden" name="form_action" value="delete">
              <input type="hidden" name="id" value="<?= e($it['id']) ?>">
              <button type="submit">Löschen</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php if (!$items): ?>
    <p class="muted">Noch keine Budgetpositionen.</p>
  <?php endif; ?>
<?php elseif ($projectId): ?>
  <p class="muted">Projekt nicht gefunden.</p>
<?php else: ?>
  <p class="muted">Projekt auswählen.</p>
<?php endif; ?>
