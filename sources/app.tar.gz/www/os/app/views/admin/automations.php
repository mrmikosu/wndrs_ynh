<header class="admin-head">
  <p class="eyebrow">Betrieb</p>
  <h2>Automationen</h2>
  <p class="muted">Regeln legt der Seed an. Läufe entstehen zum Beispiel, wenn ein Event angelegt wird und daraus ein Projekt wird.</p>
</header>
<table>
  <thead><tr><th>Name</th><th>Trigger</th><th>Action</th><th>On</th></tr></thead>
  <tbody>
  <?php foreach ($rules as $r): ?>
    <tr><td><?= e($r['name']) ?></td><td><?= e($r['trigger']) ?></td><td><?= e($r['action']) ?></td><td><?= $r['enabled']?'yes':'no' ?></td></tr>
  <?php endforeach; ?>
  </tbody>
</table>
<h3>Runs</h3>
<table>
  <thead><tr><th>Zeit</th><th>Status</th><th>Message</th></tr></thead>
  <tbody>
  <?php foreach ($runs as $r): ?>
    <tr><td><?= e($r['created_at']) ?></td><td><?= e($r['status']) ?></td><td><?= e($r['message']) ?></td></tr>
  <?php endforeach; ?>
  </tbody>
</table>
