<?php
/** @var array $campaigns */
/** @var array<int,int> $counts */
/** @var array<int,string> $urls */
/** @var DateTimeImmutable $d0 */
/** @var DateTimeImmutable $d1 */
/** @var string $rangeLabel */
/** @var bool $showArchived */
/** @var array $warnings */
/** @var array|null $site */
/** @var PDO|null $conn */
$fmtNum = static fn(int $n): string => number_format($n, 0, ',', '.');
$rangeQs = static function (array $extra = []) use ($rangeLabel, $d0, $d1): string {
    $params = $extra;
    if ($rangeLabel === 'custom') {
        $params['from'] = $d0->format('Y-m-d');
        $params['to'] = $d1->format('Y-m-d');
    } else {
        $params['r'] = $rangeLabel;
    }
    return http_build_query($params);
};
$siteLabel = $site ? e((string) $site['name']) . ' · ' . e((string) $site['domain']) : 'nicht konfiguriert';
?>
<header class="admin-head">
  <p class="eyebrow">Besucher</p>
  <h2>Kampagnen</h2>
  <p class="muted">Site <?= $siteLabel ?> · <?= e($d0->format('d.m.Y')) ?> bis <?= e($d1->format('d.m.Y')) ?></p>
  <p class="admin-actions">
    <a href="<?= e(u('/admin/analytics/campaigns/form')) ?>">Neue Kampagne</a>
    · <a href="<?= e(u('/admin/analytics')) ?>">Zur Auswertung</a>
    <?php if ($showArchived): ?>
      · <a href="<?= e(u('/admin/analytics/campaigns?' . $rangeQs())) ?>">Aktive</a>
    <?php else: ?>
      · <a href="<?= e(u('/admin/analytics/campaigns?' . $rangeQs(['archived' => '1']))) ?>">Archiv</a>
    <?php endif; ?>
  </p>
</header>

<?php foreach ($warnings as $w): ?>
  <p class="flash flash-warn"><?= e((string) $w) ?></p>
<?php endforeach; ?>

<nav class="ranges" aria-label="Zeitraum">
  <?php foreach ([7, 30, 90, 365] as $r): ?>
    <a class="chip" href="<?= e(u('/admin/analytics/campaigns?' . http_build_query(array_filter(['r' => (string) $r, 'archived' => $showArchived ? '1' : null])))) ?>" <?= $rangeLabel === (string) $r ? 'aria-current="page"' : '' ?>><?= $r ?> Tage</a>
  <?php endforeach; ?>
</nav>
<form method="get" action="<?= e(u('/admin/analytics/campaigns')) ?>" class="range-form">
  <?php if ($showArchived): ?><input type="hidden" name="archived" value="1"><?php endif; ?>
  <label>Von <input type="date" name="from" value="<?= e($d0->format('Y-m-d')) ?>"></label>
  <label>Bis <input type="date" name="to" value="<?= e($d1->format('Y-m-d')) ?>"></label>
  <button type="submit">Zeitraum</button>
</form>

<section class="panel admin-panel analytics-section">
  <?php if ($campaigns === []): ?>
    <p class="muted"><?= $showArchived ? 'Keine archivierten Kampagnen.' : 'Noch keine Kampagnen. Lege eine an und teile den Tracking-Link.' ?></p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>UTM</th>
            <th>Besuche</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($campaigns as $row): ?>
            <?php
              $id = (int) $row['id'];
              $utm = e((string) $row['utm_source']) . ' / ' . e((string) $row['utm_medium']) . ' / ' . e((string) $row['utm_campaign']);
              $url = $urls[$id] ?? '';
              $n = $counts[$id] ?? 0;
            ?>
            <tr>
              <td>
                <a href="<?= e(u('/admin/analytics/campaigns/view?id=' . $id . '&' . $rangeQs())) ?>"><?= e((string) $row['name']) ?></a>
                <div class="muted"><?= e((string) $row['landing_path']) ?></div>
              </td>
              <td><code><?= $utm ?></code></td>
              <td><?= $conn ? e($fmtNum($n)) : '—' ?></td>
              <td class="row-actions">
                <button type="button" class="linkish" data-copy="<?= e($url) ?>">Link kopieren</button>
                · <a href="<?= e(u('/admin/analytics/campaigns/form?id=' . $id)) ?>">Bearbeiten</a>
                <?php if ($row['archived_at']): ?>
                  · <form method="post" action="<?= e(u('/admin/analytics/campaigns/restore')) ?>" class="inline-form">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= $id ?>">
                    <button type="submit">Wiederherstellen</button>
                  </form>
                <?php else: ?>
                  · <form method="post" action="<?= e(u('/admin/analytics/campaigns/archive')) ?>" class="inline-form">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= $id ?>">
                    <button type="submit">Archivieren</button>
                  </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<script>
  document.querySelectorAll('[data-copy]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const text = btn.getAttribute('data-copy') || '';
      try {
        await navigator.clipboard.writeText(text);
        btn.textContent = 'Kopiert';
        setTimeout(() => { btn.textContent = 'Link kopieren'; }, 1200);
      } catch (_) {
        window.prompt('Link kopieren:', text);
      }
    });
  });
</script>
