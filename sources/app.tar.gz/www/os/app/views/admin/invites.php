<h2>Invites</h2>
<form class="stack panel" method="post" action="/admin/invites">
  <?= csrf_field() ?>
  <input type="email" name="email" required placeholder="E-Mail">
  <input name="roles" value="member,team" placeholder="Rollen z.B. member · member,team · admin">
  <button type="submit">Invite erstellen</button>
</form>
<table>
  <thead><tr><th>E-Mail</th><th>Token-Link</th><th>Akzeptiert</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['email']) ?></td>
      <td><code>/invite?token=<?= e($r['token']) ?></code></td>
      <td><?= e($r['accepted_at'] ?? '—') ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
