<?php
/** @var array $settings */
/** @var array $sites */
?>
<header class="admin-head">
  <p class="eyebrow">Besucher</p>
  <h2>Analytics-Sites</h2>
  <p class="muted">Registrierte Sites für die Besucher-Analyse. Collector-Dateien werden hier nicht automatisch angelegt.</p>
  <p><a href="/admin/analytics">Zur Auswertung</a></p>
</header>

<form method="post" action="/admin/analytics/sites" class="analytics-sites">
  <?= csrf_field() ?>
  <section class="panel admin-panel">
    <h3>Aktive Site</h3>
    <?php if (!$sites): ?>
      <p class="muted">Noch keine Analytics-Sites vorhanden.</p>
    <?php else: ?>
      <div class="site-options">
        <?php foreach ($sites as $site): ?>
        <label class="site-option">
          <input type="radio" name="active_site_id" value="<?= (int) $site['id'] ?>" <?= (string) $site['id'] === (string) $settings['analytics.active_site_id'] ? 'checked' : '' ?>>
          <span>
            <strong><?= e((string) $site['name']) ?></strong>
            <span class="muted"><?= e((string) $site['domain']) ?> · sid <?= e((string) $site['sid']) ?> · <?= e((string) $site['config_path']) ?></span>
          </span>
        </label>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <?php
      $activeSite = null;
      foreach ($sites as $site) {
          if ((string) $site['id'] === (string) $settings['analytics.active_site_id']) {
              $activeSite = $site;
              break;
          }
      }
      if ($activeSite === null && $sites) {
          $activeSite = $sites[0];
      }
    ?>
    <?php if ($activeSite): ?>
      <label>Domain der aktiven Site (für Kampagnen-Links)
        <input name="active_domain" value="<?= e((string) $activeSite['domain']) ?>" placeholder="kllktv.wndrs.de">
      </label>
    <?php endif; ?>
    <button type="submit">Aktive Site speichern</button>
  </section>

  <section class="panel admin-panel">
    <h3>Site hinzufügen</h3>
    <p class="muted">Hinweis: Collector-Config manuell anlegen.</p>
    <div class="settings-grid">
      <label>Name <input name="name"></label>
      <label>Domain <input name="domain" placeholder="kllktv.wndrs.de"></label>
      <label>Site-ID <input name="sid" pattern="[a-z0-9_-]{2,40}" placeholder="wndrs"></label>
      <label>Endpoint <input name="endpoint" value="/a/x.php"></label>
      <label>Config-Pfad <input name="config_path" value="data/analytics/config.php"></label>
      <label>Zeitzone <input name="tz" value="Europe/Berlin"></label>
    </div>
    <button type="submit">Hinzufügen</button>
  </section>
</form>
