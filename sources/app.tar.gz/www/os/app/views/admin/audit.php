<h2>Audit</h2>
<table>
  <thead><tr><th>Zeit</th><th>Actor</th><th>Action</th><th>Entity</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= e($r['created_at']) ?></td>
      <td><?= e($r['display_name'] ?? $r['actor_id'] ?? '—') ?></td>
      <td><?= e($r['action']) ?></td>
      <td>
        <?php $href = admin_entity_href((string) $r['entity_type'], (string) $r['entity_id']); ?>
        <?php if ($href): ?><a href="<?= e($href) ?>"><?php endif; ?>
        <?= e($r['entity_type']) ?> <?= e($r['entity_id']) ?>
        <?php if ($href): ?></a><?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
