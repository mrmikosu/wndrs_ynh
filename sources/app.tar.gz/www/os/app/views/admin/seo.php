<?php /** @var array $seo */ ?>
<h2>SEO &amp; Crawler</h2>
<p class="muted">Meta, Open Graph, Sitemap &amp; AI-Crawler für die öffentliche Landing.</p>

<form method="post" action="/admin/seo">
  <?= csrf_field() ?>

  <section class="panel" style="margin:1rem 0">
    <h3>Basis</h3>
    <label style="display:block;margin:.5rem 0">
      <span>Titel</span>
      <input name="site_title" value="<?= e($seo['seo.site_title']) ?>" maxlength="70" style="width:100%">
      <span class="muted" style="font-size:.8rem"><span data-count="site_title"><?= mb_strlen($seo['seo.site_title']) ?></span>/70 Zeichen</span>
    </label>
    <label style="display:block;margin:.5rem 0">
      <span>Beschreibung</span>
      <textarea name="site_description" rows="3" maxlength="160" style="width:100%"><?= e($seo['seo.site_description']) ?></textarea>
      <span class="muted" style="font-size:.8rem"><span data-count="site_description"><?= mb_strlen($seo['seo.site_description']) ?></span>/160 Zeichen</span>
    </label>
    <label style="display:block;margin:.5rem 0">
      <span>Keywords (kommagetrennt)</span>
      <input name="site_keywords" value="<?= e($seo['seo.site_keywords']) ?>" style="width:100%">
    </label>
  </section>

  <section class="panel" style="margin:1rem 0">
    <h3>Sharing &amp; Indexierung</h3>
    <label style="display:block;margin:.5rem 0">
      <span>Canonical-URL</span>
      <input name="canonical_url" type="url" value="<?= e($seo['seo.canonical_url']) ?>" style="width:100%">
    </label>
    <label style="display:block;margin:.5rem 0">
      <span>OG-Bild (1200×630)</span>
      <input name="og_image" type="url" value="<?= e($seo['seo.og_image']) ?>" style="width:100%">
    </label>
    <div style="display:flex;gap:1rem;align-items:flex-start;margin-top:.75rem;flex-wrap:wrap">
      <div style="max-width:26rem;width:100%">
        <p class="muted" style="margin:0 0 .4rem;font-size:.8rem">Vorschau: Google-Snippet</p>
        <div style="background:#fff;color:#202124;border-radius:8px;padding:.9rem 1rem;font-family:Arial,sans-serif">
          <div style="color:#1a0dab;font-size:1.05rem;line-height:1.3;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" data-preview-title><?= e($seo['seo.site_title']) ?></div>
          <div style="color:#006621;font-size:.8rem" data-preview-url><?= e($seo['seo.canonical_url']) ?></div>
          <div style="color:#545454;font-size:.82rem;line-height:1.4" data-preview-desc><?= e($seo['seo.site_description']) ?></div>
        </div>
      </div>
      <div style="max-width:16rem">
        <p class="muted" style="margin:0 0 .4rem;font-size:.8rem">OG-Bild</p>
        <img src="<?= e($seo['seo.og_image']) ?>" alt="" style="width:100%;border-radius:6px;border:1px solid var(--line,#333)" onerror="this.style.opacity=.25">
      </div>
    </div>
  </section>

  <section class="panel" style="margin:1rem 0">
    <h3>AI-Crawler</h3>
    <label style="display:block;margin:.5rem 0">
      <span>Kurztext für <code>llms.txt</code></span>
      <textarea name="llms_intro" rows="3" style="width:100%"><?= e($seo['seo.llms_intro']) ?></textarea>
    </label>
    <label style="display:block;margin:.5rem 0">
      <span>Policy</span>
      <select name="ai_policy">
        <option value="allow" <?= $seo['seo.ai_policy'] === 'allow' ? 'selected' : '' ?>>Erlauben (empfohlen — llms.txt steuert Inhalte)</option>
        <option value="block" <?= $seo['seo.ai_policy'] === 'block' ? 'selected' : '' ?>>Blockieren (robots.txt Disallow für AI-Bots)</option>
      </select>
    </label>
    <p class="muted" style="font-size:.82rem">
      Aktive Dateien:
      <a href="<?= e(public_home_url()) ?>robots.txt" target="_blank" rel="noopener">robots.txt</a> ·
      <a href="<?= e(public_home_url()) ?>sitemap.xml" target="_blank" rel="noopener">sitemap.xml</a> ·
      <a href="<?= e(public_home_url()) ?>llms.txt" target="_blank" rel="noopener">llms.txt</a>
    </p>
  </section>

  <button type="submit">Speichern</button>
</form>

<script>
(() => {
  const title = document.querySelector('[name="site_title"]');
  const desc = document.querySelector('[name="site_description"]');
  const url = document.querySelector('[name="canonical_url"]');
  const count = (name, el) => {
    const c = document.querySelector(`[data-count="${name}"]`);
    if (c) c.textContent = String(el.value.length);
  };
  const sync = () => {
    document.querySelector('[data-preview-title]').textContent = title.value;
    document.querySelector('[data-preview-desc]').textContent = desc.value;
    document.querySelector('[data-preview-url]').textContent = url.value;
    count('site_title', title);
    count('site_description', desc);
  };
  [title, desc, url].forEach((el) => el.addEventListener('input', sync));
})();
</script>
