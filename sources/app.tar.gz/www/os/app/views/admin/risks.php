<header class="admin-head">
  <p class="eyebrow">Projektentwicklung</p>
  <h2>Risiken</h2>
  <p class="muted">Ampel aus Wahrscheinlichkeit × Auswirkung (1–5). Vorlagen sind Hilfsmittel ohne Gewähr.</p>
</header>
<form method="get" class="panel" action="/admin/risiken">
  <select name="project_id" onchange="this.form.submit()">
    <option value="">Projekt wählen</option>
    <?php foreach ($projects as $p): ?>
      <option value="<?= e($p['id']) ?>" <?= $projectId === $p['id'] ? 'selected' : '' ?>><?= e($p['title']) ?></option>
    <?php endforeach; ?>
  </select>
</form>
<?php if ($projectId): ?>
<table class="admin-table">
  <thead><tr><th>Risiko</th><th>W</th><th>A</th><th>Score</th><th>Maßnahme</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): $score = (int)$r['probability'] * (int)$r['impact']; ?>
    <tr>
      <td><?= e($r['title']) ?></td>
      <td><?= (int)$r['probability'] ?></td>
      <td><?= (int)$r['impact'] ?></td>
      <td><span class="chip" style="<?= $score >= 12 ? 'border-color:var(--accent);color:var(--accent)' : ($score >= 6 ? 'border-color:var(--warn);color:var(--warn)' : '') ?>"><?= $score ?></span></td>
      <td><?= e($r['mitigation']) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<form class="stack panel" method="post" action="/admin/risiken">
  <?= csrf_field() ?>
  <input type="hidden" name="project_id" value="<?= e($projectId) ?>">
  <input name="title" required placeholder="Risiko">
  <div class="row-2">
    <input type="number" name="probability" min="1" max="5" value="2" placeholder="Wahrscheinlichkeit">
    <input type="number" name="impact" min="1" max="5" value="2" placeholder="Auswirkung">
  </div>
  <textarea name="mitigation" rows="2" placeholder="Gegenmaßnahme"></textarea>
  <button type="submit">Risiko speichern</button>
</form>
<?php endif; ?>
