<header class="admin-head">
  <p class="eyebrow">Mitgliederbereich</p>
  <h2>Jobbörse</h2>
  <p class="muted">Angebote und Gesuche aus <a href="/members/jobs">/members/jobs</a>. Hier moderierst du Status und kannst Einträge entfernen.</p>
</header>
<?php if (!$rows): ?><p class="muted">Keine Einträge.</p><?php endif; ?>
<table class="admin-table">
  <thead>
    <tr><th>Titel</th><th>Von</th><th>Art</th><th>Rolle</th><th>Ort</th><th>Status</th><th></th></tr>
  </thead>
  <tbody>
  <?php foreach ($rows as $row): ?>
    <tr>
      <td>
        <strong><?= e($row['title']) ?></strong>
        <p class="muted"><?= e($row['body']) ?></p>
      </td>
      <td><a href="/admin/mitglieder?id=<?= e(urlencode($row['author_id'])) ?>"><?= e($row['display_name']) ?></a></td>
      <td><span class="chip"><?= e($row['kind']) ?></span></td>
      <td><?= e($row['role']) ?></td>
      <td><?= e($row['location'] ?: '—') ?></td>
      <td><?= e($row['status']) ?></td>
      <td class="row-actions">
        <?php foreach (['open' => 'Offen', 'filled' => 'Besetzt', 'closed' => 'Zu'] as $status => $label): ?>
          <?php if ($row['status'] === $status) continue; ?>
          <form method="post" action="/admin/jobs">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= e($row['id']) ?>">
            <button name="status" value="<?= e($status) ?>"><?= e($label) ?></button>
          </form>
        <?php endforeach; ?>
        <form method="post" action="/admin/jobs/delete">
          <?= csrf_field() ?>
          <input type="hidden" name="id" value="<?= e($row['id']) ?>">
          <button type="submit">Löschen</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
