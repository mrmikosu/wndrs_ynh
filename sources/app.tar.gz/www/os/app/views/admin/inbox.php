<?php
/**
 * Inbox der Freigaben (Phase 3).
 * Daten kommen bereits berechtigungsgefiltert aus ApprovalInboxQuery —
 * die View trifft keine Rechteentscheidungen mehr.
 *
 * @var array $user
 * @var list<array<string, mixed>> $items
 * @var array<string, int> $counts
 * @var array<string, mixed> $filters
 * @var list<array<string, mixed>> $projects
 */
$total = array_sum($counts);
?>
<style>
  /* Fokus sichtbar machen (Tastatur-Bedienbarkeit). */
  .inbox-filters :is(select, input):focus-visible,
  .queue form :is(input, button):focus-visible {
    outline: 2px solid var(--accent, #e8a33d);
    outline-offset: 2px;
  }
  .inbox-filters label { display: flex; flex-direction: column; gap: .25rem; font-size: .85rem; }
  .inbox-meta { display: flex; flex-wrap: wrap; gap: .35rem .9rem; }
</style>

<header class="admin-head">
  <p class="eyebrow">Eingang &amp; Freigaben</p>
  <h2>Inbox</h2>
  <p class="muted">
    <?= (int) $total ?> offen
    (<?= (int) $counts['expense'] ?> Auslagen,
    <?= (int) $counts['equipment'] ?> Equipment,
    <?= (int) $counts['application'] ?> Bewerbungen)
  </p>
</header>

<form class="panel inbox-filters" method="get" action="/admin/inbox" style="display:flex;flex-wrap:wrap;gap:.8rem;align-items:flex-end">
  <label for="f-type">Typ
    <select id="f-type" name="type">
      <option value="">Alle Typen</option>
      <option value="expense" <?= $filters['type'] === 'expense' ? 'selected' : '' ?>>Auslagen</option>
      <option value="equipment" <?= $filters['type'] === 'equipment' ? 'selected' : '' ?>>Equipment</option>
      <option value="application" <?= $filters['type'] === 'application' ? 'selected' : '' ?>>Bewerbungen</option>
    </select>
  </label>
  <label for="f-scope">Zuweisung
    <select id="f-scope" name="scope">
      <option value="">Alle</option>
      <option value="mine" <?= $filters['scope'] === 'mine' ? 'selected' : '' ?>>Mir zugewiesen</option>
      <option value="unassigned" <?= $filters['scope'] === 'unassigned' ? 'selected' : '' ?>>Unzugewiesen</option>
    </select>
  </label>
  <label for="f-project">Projekt
    <select id="f-project" name="project_id">
      <option value="">Alle Projekte</option>
      <?php foreach ($projects as $p): ?>
        <option value="<?= e($p['id']) ?>" <?= $filters['project_id'] === $p['id'] ? 'selected' : '' ?>><?= e($p['title']) ?></option>
      <?php endforeach; ?>
    </select>
  </label>
  <label for="f-overdue" style="flex-direction:row;align-items:center;gap:.4rem">
    <input type="checkbox" id="f-overdue" name="overdue" value="1" <?= !empty($filters['overdue']) ? 'checked' : '' ?>>
    Nur überfällige (älter als <?= ApprovalInboxQuery::OVERDUE_DAYS ?> Tage)
  </label>
  <button type="submit">Filtern</button>
  <a class="btn" href="/admin/inbox">Zurücksetzen</a>
</form>

<?php if (!$items): ?>
  <p class="panel muted">
    <?php if ($total === 0): ?>
      Keine offenen Freigaben — alles erledigt.
    <?php else: ?>
      Keine Einträge für diese Filter. Filter zurücksetzen, um alles zu sehen.
    <?php endif; ?>
  </p>
<?php endif; ?>

<?php foreach ($items as $item): ?>
  <article class="queue panel">
    <div>
      <span class="chip"><?= e($item['type_label']) ?></span>
      <strong><?= e($item['subject']) ?></strong>
      <div class="inbox-meta muted">
        <span>Von: <?= e($item['requester']) ?></span>
        <?php if ($item['project_title'] !== ''): ?><span>Projekt: <?= e($item['project_title']) ?></span><?php endif; ?>
        <span>Zuständig: <?= e($item['responsibility']) ?></span>
        <span>
          Status: <?= e($item['status_label']) ?>
          · wartet seit <?= (int) $item['age_days'] ?> Tag<?= $item['age_days'] === 1 ? '' : 'en' ?>
          <?php if ($item['overdue']): ?><strong>· überfällig</strong><?php endif; ?>
        </span>
      </div>
    </div>
    <form method="post" action="<?= e($item['endpoint']) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="return" value="/admin/inbox">
      <input type="hidden" name="id" value="<?= e($item['id']) ?>">
      <?php if ($item['type'] === 'expense' || $item['type'] === 'application'): ?>
        <label class="muted" for="note-<?= e($item['id']) ?>">Begründung (Pflicht bei Ablehnung)</label>
        <input type="text" id="note-<?= e($item['id']) ?>" name="note">
      <?php endif; ?>
      <?php foreach ($item['actions'] as $value => $label): ?>
        <button name="<?= e($item['action_field']) ?>" value="<?= e($value) ?>"><?= e($label) ?></button>
      <?php endforeach; ?>
    </form>
  </article>
<?php endforeach; ?>
