<h2>Einstellungen</h2>
<p class="muted">Feature-Flags, App-Konfiguration und Betriebsstatus.</p>

<section class="panel" style="margin:1rem 0">
  <h3>Systemstatus</h3>
  <ul class="list">
    <?php foreach ($health['checks'] as $key => $val): ?>
      <li>
        <strong><?= e($key) ?></strong>:
        <?php if (is_bool($val)): ?>
          <?= $val ? 'ja' : 'nein' ?>
        <?php else: ?>
          <?= e((string) $val) ?>
        <?php endif; ?>
      </li>
    <?php endforeach; ?>
    <li><strong>mail_queue_pending</strong>: <?= (int) $pendingMail ?></li>
    <li><strong>health_ok</strong>: <?= !empty($health['ok']) ? 'ja' : 'nein' ?></li>
  </ul>
  <p class="muted"><a href="/health" target="_blank" rel="noopener">JSON Health-Endpoint</a></p>
</section>

<form method="post" action="/admin/einstellungen">
  <?= csrf_field() ?>
  <section class="panel" style="margin:1rem 0">
    <h3>Feature-Flags</h3>
    <?php if (!$flags): ?>
      <p class="muted">Keine Flags in der Datenbank.</p>
    <?php endif; ?>
    <table class="list" style="width:100%">
      <?php foreach ($flags as $f): ?>
        <tr>
          <td><code><?= e($f['key']) ?></code></td>
          <td class="muted"><?= e($f['note']) ?></td>
          <td>
            <label>
              <input type="checkbox" name="flag_enabled[<?= e($f['key']) ?>]" value="1" <?= !empty($f['enabled']) ? 'checked' : '' ?>>
              aktiv
            </label>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>
    <details style="margin-top:1rem">
      <summary>Neues Flag</summary>
      <label>Key <input name="new_flag_key" pattern="[a-z][a-z0-9_.-]{1,48}"></label>
      <label>Notiz <input name="new_flag_note"></label>
      <label><input type="checkbox" name="new_flag_enabled" value="1"> aktiv</label>
    </details>
  </section>

  <section class="panel" style="margin:1rem 0">
    <h3>App-Settings (DB)</h3>
    <?php if (!$settings): ?>
      <p class="muted">Keine Einträge in <code>app_settings</code>.</p>
    <?php endif; ?>
    <?php foreach ($settings as $s): ?>
      <label style="display:block;margin:.5rem 0">
        <code><?= e($s['key']) ?></code>
        <input name="setting_value[<?= e($s['key']) ?>]" value="<?= e($s['value']) ?>" style="width:100%">
        <span class="muted" style="font-size:.8rem">aktualisiert <?= e($s['updated_at']) ?></span>
      </label>
    <?php endforeach; ?>
    <details style="margin-top:1rem">
      <summary>Neuer Schlüssel</summary>
      <label>Key <input name="new_setting_key" pattern="[a-z][a-z0-9_.-]{1,48}"></label>
      <label>Value <input name="new_setting_value"></label>
    </details>
  </section>

  <button type="submit">Speichern</button>
</form>
