<p class="eyebrow">Einsatzplanung</p>
<h2>Schichten</h2>

<form class="stack panel" method="post" action="/admin/schichten" style="clip-path:none;margin-bottom:1.25rem">
  <?= csrf_field() ?>
  <input type="hidden" name="form_action" value="create_shift">
  <h3>Schicht anlegen</h3>
  <select name="event_id" required>
    <option value="">— Event —</option>
    <?php foreach ($events as $ev): ?>
      <option value="<?= e($ev['id']) ?>"><?= e($ev['title']) ?> · <?= e(substr((string)($ev['starts_at'] ?? ''), 0, 10)) ?></option>
    <?php endforeach; ?>
  </select>
  <div class="row-2">
    <input type="datetime-local" name="starts_at" required>
    <input type="datetime-local" name="ends_at" required>
  </div>
  <div class="row-2">
    <input name="role" value="crew" placeholder="Rolle">
    <input type="number" name="slots" value="1" min="1" max="99">
  </div>
  <select name="assign_user_id">
    <option value="">— optional sofort zuweisen —</option>
    <?php foreach ($members as $m): ?>
      <option value="<?= e($m['id']) ?>"><?= e($m['display_name']) ?></option>
    <?php endforeach; ?>
  </select>
  <textarea name="note" rows="2" placeholder="Notiz"></textarea>
  <button class="btn-accent" type="submit">Schicht speichern</button>
</form>

<table>
  <thead><tr><th>Event</th><th>Rolle</th><th>Zeit</th><th>Slots</th><th>Zuweisen</th></tr></thead>
  <tbody>
  <?php foreach ($shifts as $s): ?>
    <tr>
      <td><?= e($s['event_title']) ?></td>
      <td><?= e($s['role']) ?></td>
      <td><?= e($s['starts_at']) ?> – <?= e($s['ends_at']) ?></td>
      <td><?= (int) $s['assigned'] ?>/<?= (int) $s['slots'] ?></td>
      <td>
        <form method="post" action="/admin/schichten" class="row-2" style="gap:.25rem">
          <?= csrf_field() ?>
          <input type="hidden" name="form_action" value="assign">
          <input type="hidden" name="shift_id" value="<?= e($s['id']) ?>">
          <select name="user_id" required>
            <option value="">Mitglied</option>
            <?php foreach ($members as $m): ?>
              <option value="<?= e($m['id']) ?>"><?= e($m['display_name']) ?></option>
            <?php endforeach; ?>
          </select>
          <button type="submit">+</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
<?php if (!$shifts): ?><p class="muted">Noch keine Schichten.</p><?php endif; ?>
