<p class="eyebrow">Team-Kreis</p>
<h2>Hallo <?= e($user['display_name']) ?></h2>
<p class="muted">Arbeitszeit, Crew-Koordination — zwischen Members und Admin.</p>

<div class="grid" style="margin-top:1rem">
  <section class="panel">
    <p class="eyebrow">Diese Woche</p>
    <strong style="font-size:1.8rem"><?= number_format($weekMinutes / 60, 1, ',', '.') ?> h</strong>
    <p class="muted"><?= (int) $weekMinutes ?> Minuten erfasst</p>
    <p><a class="btn btn-accent" href="/team/zeit">Zur Zeiterfassung</a></p>
  </section>
  <section class="panel">
    <p class="eyebrow">Stempeluhr</p>
    <?php if ($running): ?>
      <p>Läuft seit <strong><?= e($running['start_time']) ?></strong></p>
      <form method="post" action="/team/zeit/clock">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="stop">
        <button class="btn-accent" type="submit">Ausstempeln</button>
      </form>
    <?php else: ?>
      <p class="muted">Keine offene Stempelung.</p>
      <form method="post" action="/team/zeit/clock" class="stack">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="start">
        <button type="submit">Einstempeln</button>
      </form>
    <?php endif; ?>
  </section>
</div>

<section class="panel" style="margin-top:1rem">
  <p class="eyebrow">Letzte Einträge</p>
  <table>
    <thead><tr><th>Datum</th><th>Projekt</th><th>Dauer</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($entries as $e): ?>
      <tr>
        <td><?= e($e['work_date']) ?></td>
        <td><?= e($e['project_title'] ?? '—') ?></td>
        <td><?= number_format(((int)$e['minutes'])/60, 2, ',', '.') ?> h</td>
        <td><span class="chip"><?= e($e['status']) ?></span></td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$entries): ?><tr><td colspan="4" class="muted">Noch keine Einträge</td></tr><?php endif; ?>
    </tbody>
  </table>
</section>
