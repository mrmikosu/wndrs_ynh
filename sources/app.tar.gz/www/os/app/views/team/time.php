<p class="eyebrow">Arbeitszeiterfassung</p>
<div class="task-card__top" style="margin-bottom:1rem">
  <h2 style="margin:0">Meine Zeit</h2>
  <form method="get" action="/team/zeit">
    <input type="month" name="month" value="<?= e($month) ?>" onchange="this.form.submit()">
  </form>
</div>

<div class="grid" style="margin-bottom:1rem">
  <section class="panel">
    <p class="eyebrow">Monatssumme</p>
    <strong style="font-size:1.6rem"><?= number_format($total / 60, 1, ',', '.') ?> h</strong>
  </section>
  <section class="panel">
    <p class="eyebrow">Stempeluhr</p>
    <?php if ($running): ?>
      <p>Seit <?= e($running['start_time']) ?></p>
      <form method="post" action="/team/zeit/clock"><?= csrf_field() ?><input type="hidden" name="action" value="stop"><button class="btn-accent" type="submit">Stop</button></form>
    <?php else: ?>
      <form method="post" action="/team/zeit/clock" class="stack">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="start">
        <select name="project_id">
          <option value="">— Projekt optional —</option>
          <?php foreach ($projects as $p): ?><option value="<?= e($p['id']) ?>"><?= e($p['title']) ?></option><?php endforeach; ?>
        </select>
        <button type="submit">Start</button>
      </form>
    <?php endif; ?>
  </section>
</div>

<form class="stack panel" method="post" action="/team/zeit">
  <?= csrf_field() ?>
  <h3>Manueller Eintrag</h3>
  <input type="date" name="work_date" value="<?= e(date('Y-m-d')) ?>" required>
  <div class="row-2">
    <input type="time" name="start_time" value="10:00" required>
    <input type="time" name="end_time" value="18:00" required>
  </div>
  <select name="project_id">
    <option value="">— Projekt —</option>
    <?php foreach ($projects as $p): ?><option value="<?= e($p['id']) ?>"><?= e($p['title']) ?></option><?php endforeach; ?>
  </select>
  <select name="activity_type">
    <?php foreach (($activities ?? []) as $a): ?>
      <option value="<?= e($a['code']) ?>"><?= e($a['label']) ?></option>
    <?php endforeach; ?>
    <?php if (empty($activities)): ?><option value="orga">Orga</option><?php endif; ?>
  </select>
  <input type="number" name="break_minutes" min="0" step="5" value="0" placeholder="Pause (Min)">
  <label class="check"><input type="checkbox" name="night_flag" value="1"> Nachtzuschlag kennzeichnen</label>
  <input name="note" placeholder="Tätigkeit / Notiz">
  <button class="btn-accent" type="submit">Speichern</button>
</form>

<table style="margin-top:1rem">
  <thead><tr><th>Datum</th><th>Zeit</th><th>Min</th><th>Projekt</th><th>Notiz</th><th>Status</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($entries as $e): ?>
    <tr>
      <td><?= e($e['work_date']) ?></td>
      <td class="muted" style="font-size:.8rem"><?= e(substr((string)$e['start_time'], 11, 5)) ?><?= $e['end_time'] ? '–' . e(substr((string)$e['end_time'], 11, 5)) : '…' ?></td>
      <td><?= (int)$e['minutes'] ?></td>
      <td><?= e($e['project_title'] ?? '—') ?></td>
      <td><?= e($e['note']) ?></td>
      <td><span class="chip"><?= e($e['status']) ?></span></td>
      <td style="white-space:nowrap">
        <?php if (in_array($e['status'], ['draft','rejected'], true)): ?>
          <form method="post" action="/team/zeit/submit" style="display:inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($e['id']) ?>"><button type="submit">Einreichen</button></form>
          <form method="post" action="/team/zeit/delete" style="display:inline" onsubmit="return confirm('Löschen?')"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($e['id']) ?>"><button type="submit">×</button></form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
