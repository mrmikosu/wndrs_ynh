<?php
/** @var string $contentView */
/** @var array $user */
// Navigation: Gruppe → href => [Label, erforderliches Recht].
// Links werden nur angezeigt, wenn das Recht vorhanden ist; die Guards in
// den Handlern bleiben davon unberührt (reine Anzeigelogik).
$navDefinition = [
    'Übersicht' => [
        '/admin' => ['Dashboard', 'admin.access'],
    ],
    'Eingang & Freigaben' => [
        '/admin/inbox' => ['Inbox', 'admin.access'],
        '/admin/zeit' => ['Arbeitszeit', 'time.view_all'],
    ],
    'Menschen & Zugänge' => [
        '/admin/mitglieder' => ['Mitglieder', 'members.manage'],
        '/admin/invites' => ['Invites', 'members.invite'],
        '/admin/bewerbungen' => ['Bewerbungen', 'applications.decide'],
        '/admin/jobs' => ['Jobbörse', 'admin.access'],
    ],
    'Projekte & Betrieb' => [
        '/admin/risiken' => ['Risiken', 'admin.access'],
        '/admin/crm' => ['CRM', 'admin.access'],
        '/admin/schichten' => ['Schichten', 'admin.access'],
    ],
    'Inhalte & Veröffentlichungen' => [
        '/admin/inhalte' => ['Übersicht', 'admin.access'],
        '/admin/cms' => ['Seiten', 'cms.publish'],
        '/admin/news' => ['News', 'cms.publish'],
        '/admin/events' => ['Events', 'cms.publish'],
        '/admin/kuenstler' => ['Künstler', 'admin.access'],
        '/admin/medien' => ['Medien', 'media.manage'],
        '/admin/seo' => ['SEO & Crawler', 'cms.publish'],
        '/admin/analytics' => ['Besucher', 'cms.publish'],
    ],
    'Finanzen & Förderung' => [
        '/admin/budget' => ['Budget', 'projects.budget'],
        '/admin/foerderung' => ['Förderung', 'admin.access'],
    ],
    'System & Protokoll' => [
        '/admin/automationen' => ['Automationen', 'admin.access'],
        '/admin/audit' => ['Protokoll', 'audit.read'],
        '/admin/einstellungen' => ['Einstellungen', 'settings.manage'],
    ],
];
$groups = [];
foreach ($navDefinition as $group => $links) {
    $visible = [];
    foreach ($links as $href => [$label, $perm]) {
        if (Rbac::can($user['roles'], $perm)) {
            $visible[$href] = $label;
        }
    }
    if ($visible !== []) {
        $groups[$group] = $visible;
    }
}
$path = request_path();
$crumbs = [['/', 'Website'], ['/admin', 'Admin']];
foreach ($groups as $links) {
    foreach ($links as $href => $label) {
        if ($path === $href) {
            $crumbs[] = [$href, $label];
        }
    }
}
?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#0c0b0a">
  <title>Admin · WNDRS</title>
  <link rel="manifest" href="/manifest.webmanifest">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,520;9..144,640&family=Sora:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/tokens.css">
  <link rel="stylesheet" href="/assets/app.css">
  <link rel="stylesheet" href="/assets/admin.css">
  <?= app_url_boot_script() ?>
  <script src="/assets/pwa.js" defer></script>
  <script src="/assets/command-palette.js" defer></script>
</head>
<body data-theme="admin">
  <div class="shell">
    <aside class="side">
      <a class="admin-brand" href="/admin">
        <span>WNDRS</span>
        <strong>Control</strong>
      </a>
      <nav>
        <?php foreach ($groups as $group => $links): ?>
          <p class="nav-label"><?= e($group) ?></p>
          <?php foreach ($links as $href => $label): ?>
            <?php $active = $path === $href || ($href === '/admin/analytics' && str_starts_with($path, '/admin/analytics/')); ?>
            <a class="<?= $active ? 'active' : '' ?>" href="<?= e($href) ?>"><?= e($label) ?></a>
          <?php endforeach; ?>
        <?php endforeach; ?>
      </nav>
      <div class="side-foot">
        <a href="/" target="_blank" rel="noopener">Website</a>
        <a href="/members">Zum Mitgliederbereich</a>
        <a href="/health" target="_blank" rel="noopener">Health</a>
        <a href="/logout">Logout</a>
      </div>
    </aside>
    <div class="main">
      <header class="admin-top">
        <nav class="breadcrumbs" aria-label="Brotkrumen">
          <?php foreach ($crumbs as $i => [$href, $label]): ?>
            <?php if ($i > 0): ?><span>/</span><?php endif; ?>
            <a href="<?= e($href) ?>"><?= e($label) ?></a>
          <?php endforeach; ?>
        </nav>
        <p class="muted"><?= e($user['display_name'] ?: $user['email']) ?></p>
      </header>
      <?php require __DIR__ . '/flash.php'; ?>
      <?php require __DIR__ . '/../' . $contentView . '.php'; ?>
    </div>
  </div>
  <div id="pwa-update-toast" class="pwa-toast" hidden>
    Update verfügbar
    <button type="button" data-reload>Neu laden</button>
  </div>
</body>
</html>
