<?php /** @var string $contentView */ ?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>WNDRS KLLKTV</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600&family=Space+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/app.css">
  <?= app_url_boot_script() ?>
</head>
<body>
  <div class="wrap">
    <header class="topnav">
      <a class="brand" href="/" aria-label="WNDRS">
        <img class="brand-logo" src="/assets/logo/wndrs-base.png" alt="WNDRS" width="220" height="80">
      </a>
      <nav>
        <a href="/artists">Künstler</a>
        <a href="/events">Events</a>
        <a href="/news">News</a>
        <a href="/apply">Mitmachen</a>
        <a class="nav-quiet" href="/login">Login</a>
      </nav>
    </header>
    <?php require __DIR__ . '/flash.php'; ?>
    <?php require __DIR__ . '/../' . $contentView . '.php'; ?>
  </div>
  <?= \Analytics\Store::publicScriptTag(Db::pdo()) ?>
</body>
</html>
