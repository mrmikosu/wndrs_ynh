<?php
/** @var string $contentView */
/** @var array $user */
$links = [
  '/team' => 'Übersicht',
  '/team/zeit' => 'Arbeitszeit',
  '/members' => 'Team-App →',
];
$path = request_path();
?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#0c0b0a">
  <title>Team · WNDRS</title>
  <link rel="manifest" href="/manifest.webmanifest">
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,520&family=Sora:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/tokens.css">
  <link rel="stylesheet" href="/assets/app.css">
  <link rel="stylesheet" href="/assets/team.css">
  <?= app_url_boot_script() ?>
  <script src="/assets/pwa.js" defer></script>
</head>
<body data-theme="team-app">
  <div class="shell team-shell">
    <aside class="side desktop-nav">
      <a class="admin-brand" href="/team"><span>WNDRS</span><strong>Zeit</strong></a>
      <nav>
        <?php foreach ($links as $href => $label): ?>
          <a class="<?= $path === $href ? 'active' : '' ?>" href="<?= e($href) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
        <?php if (Rbac::can($user['roles'], 'admin.access')): ?>
          <a href="/admin">Admin →</a>
        <?php endif; ?>
        <a href="/logout">Logout</a>
      </nav>
    </aside>
    <div class="main team-main">
      <?php require __DIR__ . '/flash.php'; ?>
      <?php require __DIR__ . '/../' . $contentView . '.php'; ?>
    </div>
  </div>
  <nav class="bottom-bar" aria-label="Hauptnavigation">
    <a href="/members">Home</a>
    <a href="/members/kalender">Plan</a>
    <a class="active" href="/team/zeit">Zeit</a>
    <a href="/members/jobs">Jobs</a>
    <a href="/members/profil">Profil</a>
  </nav>
</body>
</html>
