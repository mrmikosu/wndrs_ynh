<?php /** @var string $contentView */ ?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login · WNDRS</title>
  <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500&family=Space+Grotesk:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/app.css">
  <?= app_url_boot_script() ?>
</head>
<body>
  <div class="wrap" style="max-width:480px;padding-top:4rem">
    <p class="eyebrow">Kollektiv OS</p>
    <h1>Zugang</h1>
    <?php require __DIR__ . '/flash.php'; ?>
    <?php require __DIR__ . '/../' . $contentView . '.php'; ?>
    <p class="muted" style="margin-top:1.5rem"><a href="/">← zur Website</a></p>
  </div>
</body>
</html>
