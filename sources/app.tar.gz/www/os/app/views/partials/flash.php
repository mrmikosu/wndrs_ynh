<?php
$ok = flash('success');
$err = flash('error');
if ($ok): ?><div class="flash ok"><?= e($ok) ?></div><?php endif;
if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif;
?>
