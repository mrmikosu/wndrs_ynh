<?php
/** @var string $contentView */
/** @var array $user */
$primary = [
  '/members' => 'Home',
  '/members/kalender' => 'Plan',
  '/members/jobs' => 'Jobs',
  '/members/projekte' => 'Projekte',
  '/members/profil' => 'Profil',
];
$more = [
  '/members/schichten' => 'Schichten',
  '/members/verfuegbarkeit' => 'Verfügbarkeit',
  '/members/benachrichtigungen' => 'Mitteilungen',
  '/members/mitglieder' => 'Mitglieder',
  '/members/nachrichten' => 'Nachrichten',
  '/members/board' => 'Brett',
  '/members/wiki' => 'Wiki',
  '/members/kanban' => 'Kanban',
  '/members/events' => 'Events',
  '/members/abstimmungen' => 'Abstimmungen',
  '/members/mediathek' => 'Mediathek',
  '/members/equipment' => 'Equipment',
  '/members/buchungen' => 'Buchungen',
  '/members/finanzen' => 'Finanzen',
  '/members/ical' => 'iCal-Abo',
];
$path = request_path();
?>
<!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <meta name="theme-color" content="#0c0b0a">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <title>Team · WNDRS</title>
  <link rel="manifest" href="/manifest.webmanifest">
  <link rel="apple-touch-icon" href="/assets/icons/icon-192.png">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,520;9..144,640&family=Sora:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/tokens.css">
  <link rel="stylesheet" href="/assets/app.css">
  <link rel="stylesheet" href="/assets/team.css">
  <?= app_url_boot_script() ?>
  <script src="/assets/kanban.js" defer></script>
  <script src="/assets/pwa.js" defer></script>
  <script src="/assets/push.js" defer></script>
  <script src="/assets/command-palette.js" defer></script>
</head>
<?php $vapidPublic = (string) Config::get('vapid_public', ''); ?>
<body data-theme="team-app" data-csrf="<?= e(csrf_token()) ?>"<?= $vapidPublic !== '' ? ' data-vapid-public="' . e($vapidPublic) . '"' : '' ?>>
  <div class="shell team-shell">
    <aside class="side desktop-nav">
      <a class="admin-brand" href="/members"><span>WNDRS</span><strong>Team</strong></a>
      <nav>
        <p class="nav-label">Heute</p>
        <?php foreach ($primary as $href => $label): ?>
          <a class="<?= $path === $href ? 'active' : '' ?>" href="<?= e($href) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
        <p class="nav-label">Mehr</p>
        <?php foreach ($more as $href => $label): ?>
          <a class="<?= $path === $href ? 'active' : '' ?>" href="<?= e($href) ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
        <?php if (Rbac::can($user['roles'], 'team.access')): ?><a href="/team/zeit">Arbeitszeit</a><?php endif; ?>
        <?php if (Rbac::can($user['roles'], 'admin.access')): ?><a href="/admin">Admin</a><?php endif; ?>
        <a href="/styleguide">Styleguide</a>
        <a href="/logout">Logout</a>
      </nav>
      <div class="side-foot">
        <button type="button" id="pwa-install" class="btn" hidden>Als App installieren</button>
        <p id="pwa-ios-hint" class="muted" hidden style="font-size:.75rem">iOS: Teilen → Zum Home-Bildschirm</p>
        <?php if ($vapidPublic !== ''): ?>
          <button type="button" id="push-enable" class="btn" style="margin-bottom:.35rem;font-size:.75rem">Push aktivieren</button>
        <?php endif; ?>
        <p class="muted" style="font-size:.75rem"><?= e($user['display_name'] ?? '') ?></p>
      </div>
    </aside>
    <div class="main team-main">
      <?php require __DIR__ . '/flash.php'; ?>
      <?php require __DIR__ . '/../' . $contentView . '.php'; ?>
    </div>
  </div>
  <nav class="bottom-bar" aria-label="Hauptnavigation">
    <?php foreach ($primary as $href => $label): ?>
      <a class="<?= $path === $href || str_starts_with($path, rtrim($href, '/') . '/') ? 'active' : '' ?>" href="<?= e($href) ?>"><?= e($label) ?></a>
    <?php endforeach; ?>
  </nav>
  <div id="pwa-update-toast" class="pwa-toast" hidden>
    Update verfügbar
    <button type="button" data-reload>Neu laden</button>
  </div>
</body>
</html>
