<header class="admin-head">
  <p class="eyebrow">Design-System</p>
  <h2>Styleguide</h2>
  <p class="muted">Tokens und Basiskomponenten für Team und Admin. Akzentfarbe Orange, Gold als Nebenton.</p>
</header>
<section class="panel">
  <h3>Farben</h3>
  <div class="swatch-row">
    <div class="swatch" style="background:var(--color-bg)"></div>
    <div class="swatch" style="background:var(--color-surface)"></div>
    <div class="swatch" style="background:var(--color-gold)"></div>
    <div class="swatch" style="background:var(--color-accent)"></div>
    <div class="swatch" style="background:var(--color-ok)"></div>
  </div>
</section>
<section class="panel">
  <h3>Typografie</h3>
  <p class="eyebrow">Eyebrow</p>
  <h2 style="font-family:var(--font-display)">Display / Überschrift</h2>
  <p>Body-Text mit klarer Du-Ansprache. Fehlermeldungen ohne Jargon.</p>
</section>
<section class="panel">
  <h3>Komponenten</h3>
  <p><button type="button">Sekundär</button> <button class="btn-accent" type="button">Primär</button></p>
  <p><span class="chip">Status</span> <span class="chip" style="color:var(--color-ok);border-color:var(--color-ok)">OK</span></p>
  <div class="flash ok">Erfolg: gespeichert.</div>
  <div class="flash err">Fehler: bitte Eingabe prüfen.</div>
</section>
<style>
.swatch-row{display:flex;gap:.5rem;flex-wrap:wrap}
.swatch{width:56px;height:56px;border-radius:12px;border:1px solid var(--color-line)}
</style>
