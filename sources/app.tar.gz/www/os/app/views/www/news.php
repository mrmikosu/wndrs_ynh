<p class="eyebrow">Aktuelles</p>
<h1>News</h1>
<?php foreach ($news as $n): ?>
  <article class="panel">
    <h2><?= e($n['title']) ?></h2>
    <p><?= nl2br(e($n['body'])) ?></p>
  </article>
<?php endforeach; ?>
<?php if (!$news): ?><p class="muted">Keine News.</p><?php endif; ?>
