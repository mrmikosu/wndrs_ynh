<p class="eyebrow">Kalender</p>
<h1>Events</h1>
<?php foreach ($events as $ev): ?>
  <article class="panel">
    <h2><?= e($ev['title']) ?></h2>
    <p class="muted"><?= e($ev['starts_at'] ?? '') ?> · <?= e($ev['venue']) ?></p>
    <p><?= nl2br(e($ev['description'])) ?></p>
  </article>
<?php endforeach; ?>
<?php if (!$events): ?><p class="muted">Keine Events.</p><?php endif; ?>
