<?php foreach ($blocks as $b): ?>
  <?php if (($b['type'] ?? '') === 'hero'): ?>
    <section class="slant-frame" style="margin-bottom:1.5rem">
      <p class="eyebrow"><?= e($b['eyebrow'] ?? '') ?></p>
      <img class="logo-mark" src="/assets/logo/wndrs-base.png" alt="WNDRS" width="480" height="180">
      <h1 style="font-size:clamp(2.4rem,7vw,4.8rem);margin:0.3rem 0 1rem"><?= e($b['headline'] ?? '') ?></h1>
      <a class="btn btn-accent" href="/events">Events</a>
      <a class="btn" href="/apply" style="margin-left:.5rem">Mitmachen</a>
    </section>
  <?php elseif (($b['type'] ?? '') === 'richtext'): ?>
    <section class="panel"><p class="muted" style="margin:0;max-width:40rem"><?= e($b['body'] ?? '') ?></p></section>
  <?php elseif (($b['type'] ?? '') === 'cta'): ?>
    <p><a class="btn" href="<?= e($b['href'] ?? '#') ?>"><?= e($b['label'] ?? 'Mehr') ?></a></p>
  <?php endif; ?>
<?php endforeach; ?>

<div class="grid" style="margin-top:1.5rem">
  <section class="panel">
    <p class="eyebrow">Events</p>
    <ul class="list">
      <?php foreach ($events as $ev): ?>
        <li><strong><?= e($ev['title']) ?></strong><br><span class="muted"><?= e($ev['starts_at'] ?? '') ?> · <?= e($ev['venue']) ?></span></li>
      <?php endforeach; ?>
      <?php if (!$events): ?><li class="muted">Keine öffentlichen Events</li><?php endif; ?>
    </ul>
  </section>
  <section class="panel">
    <p class="eyebrow">News</p>
    <ul class="list">
      <?php foreach ($news as $n): ?>
        <li><?= e($n['title']) ?></li>
      <?php endforeach; ?>
      <?php if (!$news): ?><li class="muted">Noch keine News</li><?php endif; ?>
    </ul>
  </section>
</div>
