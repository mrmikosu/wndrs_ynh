<p class="eyebrow">Onboarding</p>
<h1>Bewerbung</h1>
<p class="muted">Erzähl kurz, was du mitbringst. Bei Zusage bekommst du einen Invite-Link.</p>
<form class="stack" method="post" action="/apply">
  <?= csrf_field() ?>
  <input required name="name" placeholder="Name">
  <input required type="email" name="email" placeholder="E-Mail">
  <input name="disciplines" placeholder="Disziplinen (kommagetrennt)">
  <textarea required name="message" rows="5" placeholder="Was bringst du mit?"></textarea>
  <button class="btn-accent" type="submit">Absenden</button>
</form>
