<p class="eyebrow">Kollektiv</p>
<h1>Künstler</h1>
<div class="grid">
<?php foreach ($artists as $a): ?>
  <article class="panel">
    <h2><?= e($a['artist_name'] ?: $a['display_name']) ?></h2>
    <p class="muted"><?= e($a['bio'] ?: '') ?></p>
  </article>
<?php endforeach; ?>
<?php if (!$artists): ?><p class="muted">Noch keine öffentlichen Profile.</p><?php endif; ?>
</div>
