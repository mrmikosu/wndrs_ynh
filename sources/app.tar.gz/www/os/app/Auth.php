<?php
declare(strict_types=1);

final class Auth
{
    public static function startSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        $name = Config::get('session_name', 'wndrs_session');
        session_name($name);
        $secure = (bool) Config::get('cookie_secure', Security::isHttps());
        session_start([
            'cookie_httponly' => true,
            'cookie_samesite' => 'Lax',
            'cookie_secure' => $secure,
            'use_strict_mode' => true,
        ]);
    }

    public static function user(): ?array
    {
        $id = $_SESSION['user_id'] ?? null;
        if (!$id) {
            return null;
        }
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM users WHERE id = ? AND is_active = 1');
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        if (!$user) {
            return null;
        }
        $roles = $db->prepare('SELECT role FROM role_assignments WHERE user_id = ?');
        $roles->execute([$id]);
        $user['roles'] = array_column($roles->fetchAll(), 'role');
        $mem = $db->prepare('SELECT status FROM memberships WHERE user_id = ?');
        $mem->execute([$id]);
        $user['membership_status'] = $mem->fetchColumn() ?: null;
        return $user;
    }

    public static function login(string $email, string $password): bool
    {
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM users WHERE email = ? AND is_active = 1');
        $stmt->execute([strtolower(trim($email))]);
        $user = $stmt->fetch();
        if (!$user || empty($user['password_hash']) || !password_verify($password, $user['password_hash'])) {
            return false;
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        audit($db, $user['id'], 'auth.login', 'user', $user['id']);
        return true;
    }

    public static function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    public static function requireLogin(): array
    {
        $user = self::user();
        if (!$user) {
            flash('error', 'Bitte einloggen.');
            redirect('/login');
        }
        return $user;
    }

    public static function requireMember(): array
    {
        $user = self::requireLogin();
        if (Rbac::can($user['roles'], '*')) {
            return $user;
        }
        if (($user['membership_status'] ?? '') !== 'active') {
            http_response_code(403);
            echo 'Aktive Mitgliedschaft erforderlich.';
            exit;
        }
        return $user;
    }

    public static function requireAdmin(): array
    {
        $user = self::requireLogin();
        if (!Rbac::can($user['roles'], 'admin.access')) {
            http_response_code(403);
            echo 'Kein Admin-Zugang.';
            exit;
        }
        return $user;
    }

    public static function requireTeam(): array
    {
        $user = self::requireMember();
        if (!Rbac::can($user['roles'], 'team.access')) {
            http_response_code(403);
            echo 'Kein Team-Zugang. Rolle „team“ erforderlich.';
            exit;
        }
        return $user;
    }

    public static function requirePerm(string $permission): array
    {
        $user = self::requireLogin();
        if (!Rbac::can($user['roles'], $permission)) {
            http_response_code(403);
            echo 'Fehlende Berechtigung: ' . e($permission);
            exit;
        }
        return $user;
    }
}
