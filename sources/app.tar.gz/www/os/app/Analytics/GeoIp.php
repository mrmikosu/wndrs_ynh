<?php
declare(strict_types=1);

namespace Analytics;

final class GeoIp
{
    public static function countryCode(string $ip, string $mmdbPath): ?string
    {
        if ($ip === '' || !is_file($mmdbPath)) {
            return null;
        }
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)
            && !filter_var($ip, FILTER_VALIDATE_IP)) {
            return null;
        }

        try {
            require_once __DIR__ . '/vendor/MaxMind/Db/Reader/InvalidDatabaseException.php';
            require_once __DIR__ . '/vendor/MaxMind/Db/Reader/Util.php';
            require_once __DIR__ . '/vendor/MaxMind/Db/Reader/Metadata.php';
            require_once __DIR__ . '/vendor/MaxMind/Db/Reader/Decoder.php';
            require_once __DIR__ . '/vendor/MaxMind/Db/Reader.php';

            $reader = new \MaxMind\Db\Reader($mmdbPath);
            try {
                $rec = $reader->get($ip);
            } finally {
                $reader->close();
            }
            $code = is_array($rec) ? ($rec['country']['iso_code'] ?? null) : null;
            return is_string($code) && preg_match('/^[A-Z]{2}$/', $code) ? $code : null;
        } catch (\Throwable) {
            return null;
        }
    }
}
