<?php
declare(strict_types=1);

namespace Analytics;

use DateTimeImmutable;
use DateTimeZone;
use PDO;

final class Campaigns
{
    /** Same charset/length as collector tag() in public/a/c.php */
    public static function sanitizeTag(mixed $v): string
    {
        if (!is_string($v)) {
            return '';
        }
        $v = trim($v);
        if ($v === '' || strlen($v) > 40) {
            return '';
        }
        return preg_match('#^[A-Za-z0-9 ._~%!$&()*+,;=:@/-]{1,40}$#', $v) ? $v : '';
    }

    public static function sanitizeLanding(mixed $v): string
    {
        if (!is_string($v)) {
            return '';
        }
        $v = trim($v);
        if ($v === '') {
            return '/';
        }
        if (preg_match('#^https?://#i', $v)) {
            return '';
        }
        if ($v[0] !== '/') {
            $v = '/' . $v;
        }
        // path + optional hash; keep URL-safe-ish characters
        if (!preg_match('/^\\/[A-Za-z0-9._~%!$&()*+,;=:@\\/?#-]*$/', $v) || strlen($v) > 200) {
            return '';
        }
        return $v;
    }

    public static function matchKey(string $source, string $medium, string $campaign): string
    {
        return $source . "\0" . $medium . '/' . $campaign;
    }

    public static function utmPair(string $medium, string $campaign): string
    {
        return $medium . '/' . $campaign;
    }

    /**
     * Build tracking URL. Hash fragments are kept after the path; query is appended
     * before the hash when a fragment is present (browser-correct).
     */
    public static function buildUrl(
        string $origin,
        string $landingPath,
        string $source,
        string $medium,
        string $campaign
    ): string {
        $origin = rtrim($origin, '/');
        $path = $landingPath !== '' ? $landingPath : '/';
        $fragment = '';
        if (str_contains($path, '#')) {
            [$path, $fragment] = explode('#', $path, 2);
            if ($path === '') {
                $path = '/';
            }
        }
        $query = http_build_query([
            'utm_source' => $source,
            'utm_medium' => $medium,
            'utm_campaign' => $campaign,
        ], '', '&', PHP_QUERY_RFC3986);
        $url = $origin . ($path === '' ? '/' : $path) . '?' . $query;
        if ($fragment !== '') {
            $url .= '#' . $fragment;
        }
        return $url;
    }

    public static function publicOrigin(?array $site): string
    {
        $domain = trim((string) ($site['domain'] ?? ''));
        if ($domain === '') {
            $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
            $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                || ((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
            return ($https ? 'https://' : 'http://') . $host;
        }
        if (preg_match('#^https?://#i', $domain)) {
            return rtrim($domain, '/');
        }
        return 'https://' . ltrim($domain, '/');
    }

    /**
     * Sum entry hits for a UTM triple between inclusive hour bounds (unix hour starts).
     */
    public static function countVisits(
        PDO $collector,
        string $siteId,
        string $source,
        string $medium,
        string $campaign,
        int $h0,
        int $h1
    ): int {
        $st = $collector->prepare(
            "SELECT COALESCE(SUM(n), 0) FROM c
             WHERE site = ? AND m = 'utm' AND a = ? AND b = ? AND h >= ? AND h <= ?"
        );
        $st->execute([$siteId, $source, self::utmPair($medium, $campaign), $h0, $h1]);
        return (int) $st->fetchColumn();
    }

    /** @return array{0:int,1:int} hour bounds covering [d0 00:00, d1 23:59:59] in tz */
    public static function hourBounds(DateTimeImmutable $d0, DateTimeImmutable $d1, DateTimeZone $tz): array
    {
        $start = $d0->setTimezone($tz)->setTime(0, 0, 0);
        $end = $d1->setTimezone($tz)->setTime(23, 59, 59);
        $h0 = intdiv($start->getTimestamp(), 3600) * 3600;
        $h1 = intdiv($end->getTimestamp(), 3600) * 3600;
        return [$h0, $h1];
    }
}
