<?php
declare(strict_types=1);

namespace Analytics;

use DateTimeImmutable;

final class Charts
{
    /** @param DateTimeImmutable[] $days */
    public static function daily(array $days, array $vis, array $pv, int $w = 760, int $h = 250): string
    {
        [$ml, $mr, $mt, $mb] = [44, 14, 14, 28];
        [$pw, $ph] = [$w - $ml - $mr, $h - $mt - $mb];
        [$top, $ticks] = self::ticks(max(array_merge($vis, $pv, [0])));
        $y = static fn(float|int $v): float => $mt + $ph - $v / $top * $ph;
        $count = count($days);
        $band = $pw / max(1, $count);
        $bw = max(1.0, min(24.0, $band - 2));
        $out = ['<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Tagesbesucher und Seitenaufrufe pro Tag">'];

        foreach ($ticks as $tick) {
            $yy = $y($tick);
            $out[] = '<line class="grid" x1="' . $ml . '" x2="' . ($w - $mr) . '" y1="' . self::f1($yy) . '" y2="' . self::f1($yy) . '"/>'
                . '<text class="tick" x="' . ($ml - 6) . '" y="' . self::f1($yy + 4) . '" text-anchor="end">' . self::compact($tick) . '</text>';
        }

        $points = [];
        foreach ($days as $i => $day) {
            $cx = $ml + $band * $i + $band / 2;
            $out[] = '<path class="s1" d="' . self::bar($cx - $bw / 2, $y((int) ($vis[$i] ?? 0)), $bw, $y(0)) . '"/>';
            $points[] = [$cx, $y((int) ($pv[$i] ?? 0))];
        }

        $step = max(1, (int) ceil(max(1, $count) / 8));
        for ($i = 0; $i < $count; $i += $step) {
            $cx = $ml + $band * $i + $band / 2;
            $out[] = '<text class="tick" x="' . self::f1($cx) . '" y="' . ($h - 8) . '" text-anchor="middle">' . self::e($days[$i]->format('d.m.')) . '</text>';
        }

        if (count($points) > 1) {
            $out[] = '<polyline class="l2" points="' . implode(' ', array_map(static fn(array $p): string => self::f1($p[0]) . ',' . self::f1($p[1]), $points)) . '"/>';
        }
        if ($points !== []) {
            $last = $points[array_key_last($points)];
            $out[] = '<circle class="dot2" cx="' . self::f1($last[0]) . '" cy="' . self::f1($last[1]) . '" r="4"/>';
        }

        foreach ($days as $i => $day) {
            $title = $day->format('d.m.Y') . ': ' . self::num((int) ($vis[$i] ?? 0)) . ' Besucher, ' . self::num((int) ($pv[$i] ?? 0)) . ' Aufrufe';
            $out[] = '<rect class="hit" x="' . self::f1($ml + $band * $i) . '" y="' . $mt . '" width="' . self::f1($band) . '" height="' . $ph . '">'
                . '<title>' . self::e($title) . '</title></rect>';
        }

        $out[] = '</svg>';
        return implode('', $out);
    }

    public static function bars(array $labels, array $values, string $unit = 'Aufrufe', int $w = 760, int $h = 170): string
    {
        if ($values === []) {
            return '<p class="sub">Keine Daten.</p>';
        }

        [$ml, $mr, $mt, $mb] = [44, 14, 10, 24];
        [$pw, $ph] = [$w - $ml - $mr, $h - $mt - $mb];
        [$top, $ticks] = self::ticks(max(array_merge($values, [0])));
        $y = static fn(float|int $v): float => $mt + $ph - $v / $top * $ph;
        $band = $pw / count($values);
        $bw = min(24.0, $band - 2);
        $out = ['<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . self::e($unit . ' nach Tageszeit') . '">'];

        foreach ($ticks as $tick) {
            $yy = $y($tick);
            $out[] = '<line class="grid" x1="' . $ml . '" x2="' . ($w - $mr) . '" y1="' . self::f1($yy) . '" y2="' . self::f1($yy) . '"/>'
                . '<text class="tick" x="' . ($ml - 6) . '" y="' . self::f1($yy + 4) . '" text-anchor="end">' . self::compact($tick) . '</text>';
        }

        foreach ($values as $i => $value) {
            $label = (string) ($labels[$i] ?? '');
            $cx = $ml + $band * $i + $band / 2;
            $out[] = '<path class="s1" d="' . self::bar($cx - $bw / 2, $y((int) $value), $bw, $y(0)) . '"/>';
            if ($i % 3 === 0) {
                $out[] = '<text class="tick" x="' . self::f1($cx) . '" y="' . ($h - 6) . '" text-anchor="middle">' . self::e($label) . '</text>';
            }
            $out[] = '<rect class="hit" x="' . self::f1($ml + $band * $i) . '" y="' . $mt . '" width="' . self::f1($band) . '" height="' . $ph . '">'
                . '<title>' . self::e($label . ': ' . self::num((int) $value) . ' ' . $unit) . '</title></rect>';
        }

        $out[] = '</svg>';
        return implode('', $out);
    }

    /** @param list<array{0:mixed,1:mixed}> $items */
    public static function shareBars(array $items, int $w = 380): string
    {
        $total = array_sum(array_map(static fn(array $item): int => (int) $item[1], $items));
        if ($total === 0) {
            return '<p class="sub">Keine Daten.</p>';
        }

        [$row, $lw, $rw] = [28, 120, 92];
        $top = max(array_map(static fn(array $item): int => (int) $item[1], $items));
        $pw = $w - $lw - $rw;
        $h = $row * count($items) + 4;
        $out = ['<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Anteile">'];

        foreach ($items as $i => $item) {
            [$name, $value] = [(string) $item[0], (int) $item[1]];
            $y = 2 + $row * $i;
            $bw = max(2.0, $value / $top * $pw);
            [$by, $bh, $r, $x0] = [$y + 5, 16, 4, $lw];
            $out[] = '<text class="lbl" x="' . ($lw - 8) . '" y="' . ($y + 18) . '" text-anchor="end">' . self::e(self::short($name, 16)) . '</text>';
            $out[] = '<path class="s1" d="M' . $x0 . ',' . $by . 'H' . self::f1($x0 + $bw - $r) . 'Q' . self::f1($x0 + $bw) . ',' . $by . ' ' . self::f1($x0 + $bw) . ',' . ($by + $r)
                . 'V' . ($by + $bh - $r) . 'Q' . self::f1($x0 + $bw) . ',' . ($by + $bh) . ' ' . self::f1($x0 + $bw - $r) . ',' . ($by + $bh) . 'H' . $x0 . 'Z"/>';
            $out[] = '<text class="val" x="' . self::f1($x0 + $bw + 8) . '" y="' . ($y + 18) . '">' . self::num($value) . ' · ' . self::f0($value / $total * 100) . ' %</text>';
            $out[] = '<rect class="hit" x="0" y="' . $y . '" width="' . $w . '" height="' . $row . '"><title>' . self::e($name . ': ' . self::num($value) . ' (' . self::f1($value / $total * 100) . ' %)') . '</title></rect>';
        }

        $out[] = '</svg>';
        return implode('', $out);
    }

    /** @param list<array{0:mixed,1:mixed,2:mixed}> $links */
    public static function flow(array $links, int $w = 760): string
    {
        if ($links === []) {
            return '<p class="sub">Keine Übergänge erfasst.</p>';
        }

        [$lw, $nw, $gap, $minh] = [190, 10, 8, 16];
        $left = [];
        $right = [];
        foreach ($links as $link) {
            [$a, $b, $n] = [(string) $link[0], (string) $link[1], (int) $link[2]];
            $left[$a] = ($left[$a] ?? 0) + $n;
            $right[$b] = ($right[$b] ?? 0) + $n;
        }

        $lnodes = array_keys($left);
        $rnodes = array_keys($right);
        usort($lnodes, static fn(string $a, string $b): int => $left[$b] <=> $left[$a]);
        usort($rnodes, static fn(string $a, string $b): int => $right[$b] <=> $right[$a]);

        $total = array_sum(array_map(static fn(array $link): int => (int) $link[2], $links));
        if ($total <= 0) {
            return '<p class="sub">Keine Übergänge erfasst.</p>';
        }
        $avail = max(220, 34 * max(count($lnodes), count($rnodes)));
        $scale = $avail / $total;
        [$lp, $ly] = self::flowLayout($lnodes, $left, $scale, $minh, $gap);
        [$rp, $ry] = self::flowLayout($rnodes, $right, $scale, $minh, $gap);
        $h = (int) (max($ly, $ry) + 6);
        [$xl, $xr] = [$lw, $w - $lw - $nw];
        $out = ['<svg class="chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Wege von Seite zu Seite">'];
        $lorder = array_flip($lnodes);
        $rorder = array_flip($rnodes);

        usort($links, static fn(array $x, array $y): int => ($lorder[(string) $x[0]] <=> $lorder[(string) $y[0]]) ?: ($rorder[(string) $x[1]] <=> $rorder[(string) $y[1]]));
        foreach ($links as $link) {
            [$a, $b, $n] = [(string) $link[0], (string) $link[1], (int) $link[2]];
            $t = $n * $scale;
            $y1 = $lp[$a][2];
            $lp[$a][2] += $t;
            $y2 = $rp[$b][2];
            $rp[$b][2] += $t;
            $xm = ($xl + $nw + $xr) / 2;
            $d = 'M' . ($xl + $nw) . ',' . self::f1($y1) . 'C' . self::f1($xm) . ',' . self::f1($y1) . ' ' . self::f1($xm) . ',' . self::f1($y2) . ' ' . $xr . ',' . self::f1($y2)
                . 'V' . self::f1($y2 + $t) . 'C' . self::f1($xm) . ',' . self::f1($y2 + $t) . ' ' . self::f1($xm) . ',' . self::f1($y1 + $t) . ' ' . ($xl + $nw) . ',' . self::f1($y1 + $t) . 'Z';
            $out[] = '<path class="flowlink" d="' . $d . '"><title>' . self::e($a . ' → ' . $b . ': ' . self::num($n)) . '</title></path>';
        }

        foreach ($lp as $name => $node) {
            [$y, $hh] = $node;
            $out[] = '<rect class="s1" x="' . $xl . '" y="' . self::f1($y) . '" width="' . $nw . '" height="' . self::f1($hh) . '"/>'
                . '<text class="lbl" x="' . ($xl - 8) . '" y="' . self::f1($y + $hh / 2 + 4) . '" text-anchor="end">' . self::e(self::short((string) $name, 28)) . '</text>';
        }
        foreach ($rp as $name => $node) {
            [$y, $hh] = $node;
            $out[] = '<rect class="s1" x="' . $xr . '" y="' . self::f1($y) . '" width="' . $nw . '" height="' . self::f1($hh) . '"/>'
                . '<text class="lbl" x="' . ($xr + $nw + 8) . '" y="' . self::f1($y + $hh / 2 + 4) . '">' . self::e(self::short((string) $name, 28)) . '</text>';
        }

        $out[] = '</svg>';
        return implode('', $out);
    }

    public static function spark(array $values, int $w = 150, int $h = 38): string
    {
        if ($values === []) {
            return '';
        }

        $top = max(max($values), 1);
        $n = count($values);
        $px = static fn(int $i): float => 4 + ($w - 8) * ($i / max(1, $n - 1));
        $py = static fn(float|int $v): float => $h - 6 - ($h - 12) * $v / $top;
        $points = [];
        foreach ($values as $i => $value) {
            $points[] = self::f1($px($i)) . ',' . self::f1($py((int) $value));
        }
        $pts = implode(' ', $points);
        $area = self::f1($px(0)) . ',' . ($h - 6) . ' ' . $pts . ' ' . self::f1($px($n - 1)) . ',' . ($h - 6);

        return '<svg class="spark" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Besucher der letzten ' . $n . ' Tage">'
            . '<polygon class="wash1" points="' . $area . '"/><polyline class="l1" points="' . $pts . '"/>'
            . '<circle class="dot1" cx="' . self::f1($px($n - 1)) . '" cy="' . self::f1($py((int) $values[array_key_last($values)])) . '" r="4"/></svg>';
    }

    private static function num(int $n): string
    {
        return number_format($n, 0, '', '.');
    }

    private static function compact(float|int $n): string
    {
        if ($n >= 1_000_000) {
            return sprintf('%g', $n / 1_000_000) . 'M';
        }
        if ($n >= 1000) {
            return sprintf('%g', $n / 1000) . 'K';
        }
        return sprintf('%g', $n);
    }

    /** @return array{0:int,1:list<int>} */
    private static function ticks(float|int $vmax): array
    {
        if ($vmax <= 0) {
            return [1, [0, 1]];
        }

        $base = 1;
        while (true) {
            foreach ([1, 2, 5] as $k) {
                $step = $k * $base;
                if ($vmax / $step <= 5) {
                    $top = (int) ceil($vmax / $step) * $step;
                    $ticks = [];
                    for ($i = 0; $i <= (int) ($top / $step); $i++) {
                        $ticks[] = $i * $step;
                    }
                    return [$top, $ticks];
                }
            }
            $base *= 10;
        }
    }

    private static function bar(float $x, float $y, float $w, float $y0, float $r = 4): string
    {
        $height = $y0 - $y;
        if ($height <= 0) {
            return '';
        }

        $r = $w >= 8 ? min($r, $w / 2, $height) : 0;
        if ($r <= 0) {
            return 'M' . self::f1($x) . ',' . self::f1($y0) . 'V' . self::f1($y) . 'H' . self::f1($x + $w) . 'V' . self::f1($y0) . 'Z';
        }

        return 'M' . self::f1($x) . ',' . self::f1($y0) . 'V' . self::f1($y + $r) . 'Q' . self::f1($x) . ',' . self::f1($y) . ' ' . self::f1($x + $r) . ',' . self::f1($y)
            . 'H' . self::f1($x + $w - $r) . 'Q' . self::f1($x + $w) . ',' . self::f1($y) . ' ' . self::f1($x + $w) . ',' . self::f1($y + $r) . 'V' . self::f1($y0) . 'Z';
    }

    private static function short(string $text, int $n): string
    {
        if (mb_strlen($text, 'UTF-8') <= $n) {
            return $text;
        }

        return mb_substr($text, 0, $n - 1, 'UTF-8') . '…';
    }

    /** @return array{0:array<string,array{0:float,1:float,2:float}>,1:float} */
    private static function flowLayout(array $nodes, array $totals, float $scale, int $minh, int $gap): array
    {
        $pos = [];
        $y = 10.0;
        foreach ($nodes as $node) {
            $height = max($minh, $totals[$node] * $scale);
            $pos[$node] = [$y, $height, $y];
            $y += $height + $gap;
        }

        return [$pos, $y];
    }

    private static function e(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }

    private static function f0(float $value): string
    {
        return sprintf('%.0f', $value);
    }

    private static function f1(float $value): string
    {
        return sprintf('%.1f', $value);
    }
}
