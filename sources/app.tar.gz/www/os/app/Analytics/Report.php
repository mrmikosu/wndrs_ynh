<?php
declare(strict_types=1);

namespace Analytics;

use DateInterval;
use DateTimeImmutable;
use DateTimeZone;
use PDO;

final class Report
{
    private const SEARCH = [
        'google' => true,
        'bing' => true,
        'duckduckgo' => true,
        'ecosia' => true,
        'startpage' => true,
        'qwant' => true,
        'yahoo' => true,
        'yandex' => true,
        'baidu' => true,
        'brave' => true,
    ];

    private const SOCIAL = [
        'facebook' => true,
        'instagram' => true,
        'linkedin' => true,
        'lnkd' => true,
        'youtube' => true,
        'youtu' => true,
        'reddit' => true,
        'pinterest' => true,
        'tiktok' => true,
        'whatsapp' => true,
        'telegram' => true,
        'threads' => true,
        'mastodon' => true,
        'bsky' => true,
        't.co' => true,
        'x.com' => true,
        'twitter' => true,
    ];

    private const LANG = [
        'de' => 'Deutsch',
        'en' => 'Englisch',
        'fr' => 'Französisch',
        'es' => 'Spanisch',
        'it' => 'Italienisch',
        'tr' => 'Türkisch',
        'pl' => 'Polnisch',
        'ru' => 'Russisch',
        'uk' => 'Ukrainisch',
        'nl' => 'Niederländisch',
        'ar' => 'Arabisch',
        'zh' => 'Chinesisch',
        'pt' => 'Portugiesisch',
        'ja' => 'Japanisch',
        '??' => 'Unbekannt',
    ];

    public static function channel(string $ref): string
    {
        if ($ref === '(direkt)' || $ref === '') {
            return 'Direkt';
        }

        foreach (explode('.', $ref) as $label) {
            if (isset(self::SEARCH[$label])) {
                return 'Suche';
            }
            if (isset(self::SOCIAL[$label])) {
                return 'Social';
            }
        }

        if ($ref === 't.co' || $ref === 'x.com') {
            return 'Social';
        }

        return 'Verweis';
    }

    public static function build(
        PDO $conn,
        string $siteId,
        DateTimeZone $tz,
        DateTimeImmutable $d0,
        DateTimeImmutable $d1,
        bool $detail = true
    ): array {
        $days = self::days($d0, $d1, $tz);
        $per = [];
        foreach ($days as $day) {
            $per[$day->format('Y-m-d')] = ['vis' => 0, 'pv' => 0, 'ent' => 0, 'dws' => 0, 'dwn' => 0];
        }

        $pages = [];
        $trans = [];
        $src = [];
        $utm = [];
        $clk = [];
        $dev = ['dev' => [], 'br' => [], 'os' => [], 'lang' => []];
        $countries = [];
        $bots = 0;
        $hours = array_fill(0, 24, 0);
        [$start, $end] = self::bounds($d0, $d1, $tz);
        $cache = [];

        $st = $conn->prepare('SELECT h,m,a,b,n FROM c WHERE site=? AND h>=? AND h<?');
        $st->execute([$siteId, $start, $end]);
        while (($row = $st->fetch(PDO::FETCH_NUM)) !== false) {
            [$h, $m, $a, $b, $n] = $row;
            $h = (int) $h;
            $m = (string) $m;
            $a = (string) $a;
            $b = (string) $b;
            $n = (int) $n;

            if (!isset($cache[$h])) {
                $local = (new DateTimeImmutable('@' . $h))->setTimezone($tz);
                $cache[$h] = [$local->format('Y-m-d'), (int) $local->format('G')];
            }
            [$d, $hr] = $cache[$h];
            if (!isset($per[$d])) {
                continue;
            }

            if ($m === 'vis') {
                $per[$d]['vis'] += $n;
            } elseif ($m === 'pv') {
                $per[$d]['pv'] += $n;
                self::page($pages, $a)['pv'] += $n;
                $hours[$hr] += $n;
            } elseif ($m === 'ent') {
                $per[$d]['ent'] += $n;
                self::page($pages, $a)['ent'] += $n;
                $src[$b] = ($src[$b] ?? 0) + $n;
            } elseif ($m === 'tr') {
                self::page($pages, $a)['out'] += $n;
                $trans[$a . "\0" . $b] = ($trans[$a . "\0" . $b] ?? 0) + $n;
            } elseif ($m === 'dws') {
                $per[$d]['dws'] += $n;
                self::page($pages, $a)['dws'] += $n;
            } elseif ($m === 'dwn') {
                $per[$d]['dwn'] += $n;
                self::page($pages, $a)['dwn'] += $n;
            } elseif ($m === 'utm') {
                $utm[$a . "\0" . $b] = ($utm[$a . "\0" . $b] ?? 0) + $n;
            } elseif ($m === 'clk') {
                $clk[$a . "\0" . $b] = ($clk[$a . "\0" . $b] ?? 0) + $n;
            } elseif (isset($dev[$m])) {
                $dev[$m][$a] = ($dev[$m][$a] ?? 0) + $n;
            } elseif ($m === 'bot') {
                $bots += $n;
            } elseif ($m === 'cc') {
                $countries[$a] = ($countries[$a] ?? 0) + $n;
            }
        }

        $tot = ['vis' => 0, 'pv' => 0, 'ent' => 0, 'dws' => 0, 'dwn' => 0];
        foreach ($per as $p) {
            foreach ($tot as $k => $_) {
                $tot[$k] += $p[$k];
            }
        }
        $tot['avg'] = $tot['dwn'] ? $tot['dws'] / $tot['dwn'] : null;
        $report = ['days' => $days, 'per' => $per, 'tot' => $tot];

        if (!$detail) {
            return $report;
        }

        $plist = [];
        foreach ($pages as $path => $v) {
            $exits = max(0, $v['pv'] - $v['out']);
            $plist[] = [
                'path' => $path,
                'pv' => $v['pv'],
                'ent' => $v['ent'],
                'exits' => $exits,
                'exit_rate' => $v['pv'] ? $exits / $v['pv'] : null,
                'avg' => $v['dwn'] ? $v['dws'] / $v['dwn'] : null,
            ];
        }
        usort($plist, static fn(array $x, array $y): int => $y['pv'] <=> $x['pv']);

        $chan = [];
        foreach ($src as $ref => $n) {
            $label = self::channel((string) $ref);
            $chan[$label] = ($chan[$label] ?? 0) + $n;
        }

        $clicks = [];
        foreach ($clk as $key => $n) {
            [, $target] = self::splitPair($key);
            $clicks[$target] = ($clicks[$target] ?? 0) + $n;
        }

        $langs = [];
        foreach ($dev['lang'] as $k => $v) {
            $langs[self::LANG[$k] ?? strtoupper((string) $k)] = $v;
        }

        self::sortDesc($trans);
        $flow = [];
        foreach (array_slice($trans, 0, 12, true) as $key => $n) {
            [$a, $b] = self::splitPair($key);
            $flow[] = [$a, $b, $n];
        }

        self::sortDesc($src);
        $sources = [];
        foreach (array_slice($src, 0, 25, true) as $ref => $n) {
            $sources[] = ['ref' => $ref, 'n' => $n, 'channel' => self::channel((string) $ref)];
        }

        self::sortDesc($utm);
        $utmRows = [];
        foreach (array_slice($utm, 0, 20, true) as $key => $n) {
            [$a, $b] = self::splitPair($key);
            $utmRows[] = ['source' => $a, 'medium' => $b, 'n' => $n];
        }

        $kind = ['out' => 'Externer Link', 'dl' => 'Download', 'ev' => 'Ereignis'];
        self::sortDesc($clicks);
        $clickRows = [];
        foreach (array_slice($clicks, 0, 25, true) as $target => $n) {
            [$prefix, $rest] = array_pad(explode(':', (string) $target, 2), 2, (string) $target);
            $clickRows[] = ['kind' => $kind[$prefix] ?? '?', 'target' => $rest, 'n' => $n];
        }

        $transRows = [];
        foreach (array_slice($trans, 0, 15, true) as $key => $n) {
            [$a, $b] = self::splitPair($key);
            $transRows[] = ['a' => $a, 'b' => $b, 'n' => $n];
        }

        $report += [
            'pages' => array_slice($plist, 0, 30),
            'devices' => self::share($dev['dev']),
            'browsers' => self::share($dev['br']),
            'systems' => self::share($dev['os']),
            'langs' => self::share($langs),
            'dev_total' => array_sum($dev['dev']),
            'bots' => $bots,
            'bot_share' => ($bots + $tot['pv']) ? $bots / ($bots + $tot['pv']) : null,
            'flow' => $flow,
            'sources' => $sources,
            'channels' => self::pairs($chan),
            'utm' => $utmRows,
            'clicks' => $clickRows,
            'trans' => $transRows,
            'hours' => $hours,
            'countries' => array_slice(self::pairs($countries), 0, 30),
        ];

        return $report;
    }

    public static function delta(mixed $cur, mixed $prev): ?float
    {
        if ($cur === null || $prev === null || $prev < 10) {
            return null;
        }

        return ($cur - $prev) / $prev * 100.0;
    }

    /** @return array{0:int,1:int} */
    private static function bounds(DateTimeImmutable $d0, DateTimeImmutable $d1, DateTimeZone $tz): array
    {
        $start = new DateTimeImmutable($d0->setTimezone($tz)->format('Y-m-d 00:00:00'), $tz);
        $end = new DateTimeImmutable($d1->setTimezone($tz)->modify('+1 day')->format('Y-m-d 00:00:00'), $tz);

        return [$start->getTimestamp(), $end->getTimestamp()];
    }

    /** @return list<DateTimeImmutable> */
    private static function days(DateTimeImmutable $d0, DateTimeImmutable $d1, DateTimeZone $tz): array
    {
        $days = [];
        $cur = new DateTimeImmutable($d0->setTimezone($tz)->format('Y-m-d 00:00:00'), $tz);
        $end = new DateTimeImmutable($d1->setTimezone($tz)->format('Y-m-d 00:00:00'), $tz);
        while ($cur <= $end) {
            $days[] = $cur;
            $cur = $cur->add(new DateInterval('P1D'));
        }

        return $days;
    }

    private static function &page(array &$pages, string $path): array
    {
        if (!isset($pages[$path])) {
            $pages[$path] = ['pv' => 0, 'ent' => 0, 'out' => 0, 'dws' => 0, 'dwn' => 0];
        }

        return $pages[$path];
    }

    /** @return list<array{0:string,1:int}> */
    private static function share(array $data, int $top = 8): array
    {
        $items = self::pairs($data);
        if (count($items) > $top) {
            $head = array_slice($items, 0, $top - 1);
            $tail = array_slice($items, $top - 1);
            $head[] = ['Andere', array_sum(array_column($tail, 1))];
            return $head;
        }

        return $items;
    }

    /** @return list<array{0:string,1:int}> */
    private static function pairs(array $data): array
    {
        self::sortDesc($data);
        $out = [];
        foreach ($data as $k => $v) {
            $out[] = [(string) $k, (int) $v];
        }

        return $out;
    }

    private static function sortDesc(array &$data): void
    {
        arsort($data, SORT_NUMERIC);
    }

    /** @return array{0:string,1:string} */
    private static function splitPair(string $key): array
    {
        $parts = explode("\0", $key, 2);
        return [$parts[0], $parts[1] ?? ''];
    }
}
