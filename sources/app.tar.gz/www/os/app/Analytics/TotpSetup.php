<?php
declare(strict_types=1);

namespace Analytics;

/**
 * Dashboard 2FA setup for PHP admin: admin-totp.txt and/or dashboard.db.
 */
final class TotpSetup
{
    /** @var string|null */
    private static $siteRootForTesting = null;

    public static function setSiteRootForTesting(?string $root): void
    {
        self::$siteRootForTesting = $root;
    }

    /**
     * @return array{user:string,secret:string,uri:string,path:string,source:string}|null
     */
    public static function load(?string $siteRoot = null): ?array
    {
        $root = $siteRoot ?? self::$siteRootForTesting ?? dirname(__DIR__, 2);

        $fromFile = self::loadFromFile($root);
        if ($fromFile !== null) {
            return $fromFile;
        }

        return self::loadFromDb($root);
    }

    /**
     * Candidate roots for install_dir / monorepo layouts.
     *
     * @return list<string>
     */
    public static function installRoots(string $siteRoot): array
    {
        $roots = [];
        foreach ([
            dirname($siteRoot, 2), // /var/www/wndrs from …/www/os
            dirname($siteRoot),    // …/www
            $siteRoot . '/../..',
            $siteRoot . '/..',
        ] as $r) {
            $real = realpath($r);
            if ($real !== false) {
                $roots[] = $real;
            }
        }

        return array_values(array_unique($roots));
    }

    /**
     * @return array{user:string,secret:string,uri:string,path:string,source:string}|null
     */
    private static function loadFromFile(string $siteRoot): ?array
    {
        $path = self::resolveFile($siteRoot);
        if ($path === null) {
            return null;
        }
        $raw = @file_get_contents($path);
        if ($raw === false || $raw === '') {
            return null;
        }
        $parsed = self::parse($raw, $path);
        if ($parsed === null) {
            return null;
        }
        $parsed['source'] = 'file';

        return $parsed;
    }

    /**
     * @return array{user:string,secret:string,uri:string,path:string,source:string}|null
     */
    private static function loadFromDb(string $siteRoot): ?array
    {
        $dbFiles = [];
        foreach (self::installRoots($siteRoot) as $installRoot) {
            $dbFiles[] = $installRoot . '/dashboard/data/dashboard.db';
        }
        $dbFiles[] = '/var/www/wndrs/dashboard/data/dashboard.db';

        foreach (array_values(array_unique($dbFiles)) as $dbFile) {
            if (!is_file($dbFile) || !is_readable($dbFile)) {
                continue;
            }
            try {
                $pdo = new \PDO('sqlite:' . $dbFile, null, null, [
                    \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                ]);
                $row = $pdo->query('SELECT name, totp FROM users WHERE admin = 1 ORDER BY id ASC LIMIT 1')->fetch(\PDO::FETCH_ASSOC);
                if (!$row) {
                    $row = $pdo->query('SELECT name, totp FROM users ORDER BY id ASC LIMIT 1')->fetch(\PDO::FETCH_ASSOC);
                }
            } catch (\Throwable $e) {
                continue;
            }
            if (!$row || empty($row['totp'])) {
                continue;
            }
            $user = (string) ($row['name'] ?? '');
            $secret = strtoupper((string) preg_replace('/\s+/', '', (string) $row['totp']));
            if ($secret === '' || !preg_match('/^[A-Z2-7]+$/', $secret)) {
                continue;
            }
            $uri = 'otpauth://totp/' . rawurlencode('Besucher-Analyse') . ':' . rawurlencode($user !== '' ? $user : 'admin')
                . '?secret=' . rawurlencode($secret)
                . '&issuer=' . rawurlencode('Besucher-Analyse');

            $payload = "TOTP_USER={$user}\nTOTP_SECRET={$secret}\nTOTP_URI={$uri}\n";
            // Prefer writing beside collector config (readable by PHP OS / open_basedir)
            $totpPath = $siteRoot . '/data/analytics/admin-totp.txt';
            if (@file_put_contents($totpPath, $payload) === false) {
                $totpPath = dirname($dbFile) . '/admin-totp.txt';
                @file_put_contents($totpPath, $payload);
            }

            return [
                'user' => $user,
                'secret' => $secret,
                'uri' => $uri,
                'path' => is_file($totpPath) ? $totpPath : $dbFile,
                'source' => 'db',
            ];
        }

        return null;
    }

    /**
     * @return array{user:string,secret:string,uri:string,path:string}|null
     */
    public static function parse(string $raw, string $path = ''): ?array
    {
        $user = self::matchLine($raw, 'TOTP_USER');
        $secret = self::matchLine($raw, 'TOTP_SECRET');
        $uri = self::matchLine($raw, 'TOTP_URI');

        if ($secret === null) {
            if (preg_match('/(?:TOTP_SECRET=|2FA-Schlüssel:\s*|Schlüssel:\s*|^\s*)([A-Z2-7]{16,})\b/mi', $raw, $m)) {
                $secret = strtoupper($m[1]);
            }
        }
        if ($uri === null && preg_match('#otpauth://[^\s]+#', $raw, $m)) {
            $uri = $m[0];
        }
        if ($secret === null || $secret === '') {
            return null;
        }
        $secret = strtoupper((string) preg_replace('/\s+/', '', $secret));
        if ($uri === null || $uri === '') {
            $uri = 'otpauth://totp/Besucher-Analyse:' . rawurlencode($user ?: 'admin')
                . '?secret=' . rawurlencode($secret)
                . '&issuer=' . rawurlencode('Besucher-Analyse');
        }
        if ($user === null) {
            $user = '';
            if (preg_match('#otpauth://totp/[^:]+:([^?]+)#', $uri, $m)) {
                $user = rawurldecode($m[1]);
            }
        }

        return [
            'user' => $user,
            'secret' => $secret,
            'uri' => $uri,
            'path' => $path,
        ];
    }

    public static function resolveFile(?string $siteRoot = null): ?string
    {
        $root = $siteRoot ?? self::$siteRootForTesting ?? dirname(__DIR__, 2);
        $candidates = [];
        // Preferred: copy next to collector config (same open_basedir as PHP OS)
        $candidates[] = $root . '/data/analytics/admin-totp.txt';
        foreach (self::installRoots($root) as $installRoot) {
            $candidates[] = $installRoot . '/dashboard/data/admin-totp.txt';
            $candidates[] = $installRoot . '/besucher-analyse/dashboard/data/admin-totp.txt';
        }
        $candidates[] = $root . '/../dashboard/data/admin-totp.txt';
        // Yunohost wndrs app even when PHP OS still runs under my_webapp
        $candidates[] = '/var/www/wndrs/dashboard/data/admin-totp.txt';

        foreach ($candidates as $candidate) {
            $real = realpath($candidate);
            if ($real !== false && is_readable($real) && is_file($real)) {
                return $real;
            }
            if (is_file($candidate) && is_readable($candidate)) {
                return $candidate;
            }
        }

        return null;
    }

    private static function matchLine(string $raw, string $key): ?string
    {
        if (preg_match('/^' . preg_quote($key, '/') . '=(.+)$/m', $raw, $m)) {
            return trim($m[1]);
        }

        return null;
    }
}
