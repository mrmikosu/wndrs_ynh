<?php
declare(strict_types=1);
namespace Analytics;

use PDO;

final class Store
{
    private const COLLECTOR_CONFIG_DEFAULT = 'data/analytics/config.php';
    private const COLLECTOR_CONFIG_PATTERN = '#\Adata/analytics/[A-Za-z0-9._-]+\.php\z#';
    private const OVERRIDE_KEYS = [
        'visitor_mode' => true,
        'geo_enabled' => true,
        'origins' => true,
        'device_stats' => true,
        'geo_db' => true,
    ];
    private static ?string $siteRootForTesting = null;

    public const SETTINGS_DEFAULTS = [
        'analytics.enabled' => '0',
        'analytics.python_url' => '',
        'analytics.active_site_id' => '1',
    ];

    public static function settings(PDO $db): array
    {
        $stored = [];
        foreach ($db->query("SELECT key, value FROM app_settings WHERE key LIKE 'analytics.%'") as $row) {
            $stored[$row['key']] = $row['value'];
        }
        return array_merge(self::SETTINGS_DEFAULTS, $stored);
    }

    public static function activeSite(PDO $db): ?array
    {
        $settings = self::settings($db);
        $id = (int) $settings['analytics.active_site_id'];
        $st = $db->prepare('SELECT * FROM analytics_sites WHERE id = ?');
        $st->execute([$id]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /** @return PDO|null collector connection or null if config/db missing */
    public static function collectorPdo(?array $site = null): ?PDO
    {
        $path = self::collectorConfigPath($site);
        if ($path === null) {
            return null;
        }
        $dir = dirname($path);
        if (!is_file($path) || !is_file($dir . '/s.sqlite')) {
            return null;
        }
        $pdo = new PDO('sqlite:' . $dir . '/s.sqlite', null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_NUM,
        ]);
        return $pdo;
    }

    public static function loadCollectorConfig(?array $site = null): ?array
    {
        $path = self::collectorConfigPath($site);
        if ($path === null) {
            return null;
        }
        if (!is_file($path)) {
            return null;
        }
        $cfg = require $path;
        if (!is_array($cfg)) {
            return null;
        }
        $overridesPath = self::collectorOverridesPath($path);
        if (is_file($overridesPath)) {
            $overrides = require $overridesPath;
            if (is_array($overrides)) {
                $cfg = array_merge($cfg, array_intersect_key($overrides, self::OVERRIDE_KEYS));
            }
        }
        return $cfg;
    }

    public static function writeCollectorConfigOverrides(?array $site, array $subset): bool
    {
        $path = self::collectorConfigPath($site);
        if ($path === null) {
            return false;
        }

        $overrides = [];
        foreach ($subset as $key => $value) {
            if (isset(self::OVERRIDE_KEYS[$key])) {
                $overrides[$key] = $value;
            }
        }

        $body = "<?php\nreturn " . var_export($overrides, true) . ";\n";
        $target = self::collectorOverridesPath($path);
        $dir = dirname($target);
        $tmp = tempnam($dir, '.overrides.');
        if ($tmp === false) {
            return false;
        }

        if (file_put_contents($tmp, $body, LOCK_EX) === false) {
            @unlink($tmp);
            return false;
        }
        @chmod($tmp, 0644);
        if (!rename($tmp, $target)) {
            @unlink($tmp);
            return false;
        }
        return true;
    }

    public static function writeCollectorConfigSubset(?array $site, array $subset): bool
    {
        return self::writeCollectorConfigOverrides($site, $subset);
    }

    public static function publicScriptTag(PDO $db): string
    {
        try {
            $settings = self::settings($db);
            $site = self::activeSite($db);
            $cfg = self::loadCollectorConfig($site);

            return self::scriptTagFrom($settings, $cfg);
        } catch (\Throwable) {
            return '';
        }
    }

    public static function scriptTagFrom(array $settings, ?array $cfg): string
    {
        if (($settings['analytics.enabled'] ?? '0') !== '1') {
            return '';
        }
        if (!$cfg || empty($cfg['site_key']) || str_starts_with((string) $cfg['site_key'], 'CHANGE_ME')) {
            return '';
        }
        $key = htmlspecialchars((string) $cfg['site_key'], ENT_QUOTES, 'UTF-8');
        $src = '/a/t.js';
        if (\function_exists('base_path')) {
            $base = \base_path();
            if ($base !== '') {
                $src = rtrim($base, '/') . '/a/t.js';
            }
        }
        $src = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');

        return '<script defer src="' . $src . '" data-k="' . $key . '"></script>';
    }

    public static function normalizeCollectorConfigPath(string $path): ?string
    {
        $path = str_replace('\\', '/', trim($path));
        if ($path === '') {
            return self::COLLECTOR_CONFIG_DEFAULT;
        }
        if (str_contains($path, "\0") || str_contains($path, '..')) {
            return null;
        }
        if (preg_match(self::COLLECTOR_CONFIG_PATTERN, $path)) {
            return $path;
        }
        if (!str_starts_with($path, '/')) {
            return null;
        }

        $real = realpath($path);
        $base = realpath(self::collectorBaseDir());
        if ($real === false || $base === false || !str_starts_with($real, $base . DIRECTORY_SEPARATOR)) {
            return null;
        }
        $file = basename($real);
        if (!preg_match('#\A[A-Za-z0-9._-]+\.php\z#', $file)) {
            return null;
        }
        return 'data/analytics/' . $file;
    }

    public static function collectorConfigDir(?array $site = null): ?string
    {
        $path = self::collectorConfigPath($site);
        return $path === null ? null : dirname($path);
    }

    public static function setSiteRootForTesting(?string $siteRoot): void
    {
        self::$siteRootForTesting = $siteRoot;
    }

    private static function collectorConfigPath(?array $site = null): ?string
    {
        $rel = self::normalizeCollectorConfigPath((string) ($site['config_path'] ?? self::COLLECTOR_CONFIG_DEFAULT));
        if ($rel === null) {
            return null;
        }
        $path = self::siteRoot() . '/' . $rel;
        $real = realpath($path);
        if ($real === false) {
            return $path;
        }
        $base = realpath(self::collectorBaseDir());
        if ($base === false || !str_starts_with($real, $base . DIRECTORY_SEPARATOR)) {
            return null;
        }
        return $real;
    }

    private static function collectorOverridesPath(string $configPath): string
    {
        return dirname($configPath) . '/overrides.php';
    }

    private static function siteRoot(): string
    {
        if (self::$siteRootForTesting !== null) {
            return self::$siteRootForTesting;
        }
        return dirname(__DIR__, 2);
    }

    private static function collectorBaseDir(): string
    {
        return self::siteRoot() . '/data/analytics';
    }
}
