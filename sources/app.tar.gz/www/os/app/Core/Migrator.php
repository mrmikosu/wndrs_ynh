<?php
declare(strict_types=1);

final class Migrator
{
    public static function run(): void
    {
        $pdo = Db::pdo();
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS schema_migrations (
                id TEXT PRIMARY KEY,
                applied_at TEXT NOT NULL DEFAULT (datetime(\'now\'))
            )'
        );
        $dir = dirname(__DIR__) . '/migrations';
        if (!is_dir($dir)) {
            return;
        }
        $files = glob($dir . '/*.sql') ?: [];
        sort($files);
        foreach ($files as $file) {
            $id = basename($file);
            $check = $pdo->prepare('SELECT 1 FROM schema_migrations WHERE id = ?');
            $check->execute([$id]);
            if ($check->fetchColumn()) {
                continue;
            }
            $sql = file_get_contents($file);
            if ($sql === false || trim($sql) === '') {
                continue;
            }
            // Strip line comments
            $sql = preg_replace('/^\s*--.*$/m', '', $sql) ?? $sql;
            $statements = preg_split('/;\s*/', $sql) ?: [];
            foreach ($statements as $statement) {
                $statement = trim($statement);
                if ($statement === '') {
                    continue;
                }
                try {
                    $pdo->exec($statement);
                } catch (Throwable $e) {
                    $msg = strtolower($e->getMessage());
                    if (str_contains($msg, 'duplicate column') || str_contains($msg, 'already exists')) {
                        continue;
                    }
                    throw $e;
                }
            }
            $pdo->prepare('INSERT INTO schema_migrations (id) VALUES (?)')->execute([$id]);
        }
    }

    public static function forceRerun(string $id): void
    {
        Db::pdo()->prepare('DELETE FROM schema_migrations WHERE id = ?')->execute([$id]);
        self::run();
    }
}
