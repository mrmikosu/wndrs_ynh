<?php
declare(strict_types=1);

final class RateLimit
{
    public static function hit(string $bucket, int $limit, int $windowSeconds): bool
    {
        $pdo = Db::pdo();
        $key = hash('sha256', $bucket . '|' . Security::clientIp());
        $now = time();
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS rate_limits (
                key_hash TEXT PRIMARY KEY,
                hits INTEGER NOT NULL DEFAULT 0,
                window_start INTEGER NOT NULL
            )'
        );
        $stmt = $pdo->prepare('SELECT hits, window_start FROM rate_limits WHERE key_hash = ?');
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        if (!$row || ($now - (int) $row['window_start']) >= $windowSeconds) {
            $pdo->prepare('DELETE FROM rate_limits WHERE key_hash = ?')->execute([$key]);
            $pdo->prepare('INSERT INTO rate_limits (key_hash, hits, window_start) VALUES (?,?,?)')
                ->execute([$key, 1, $now]);
            return true;
        }
        if ((int) $row['hits'] >= $limit) {
            return false;
        }
        $pdo->prepare('UPDATE rate_limits SET hits = hits + 1 WHERE key_hash = ?')->execute([$key]);
        return true;
    }

    public static function enforce(string $bucket, int $limit, int $windowSeconds): void
    {
        if (!self::hit($bucket, $limit, $windowSeconds)) {
            http_response_code(429);
            header('Retry-After: ' . (string) $windowSeconds);
            echo 'Zu viele Anfragen. Bitte kurz warten.';
            exit;
        }
    }
}
