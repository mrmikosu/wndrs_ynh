<?php
declare(strict_types=1);

final class Mailer
{
    public static function send(string $to, string $subject, string $body, array $headers = []): bool
    {
        $to = trim($to);
        if ($to === '' || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return false;
        }
        $from = (string) Config::get('mail_from', 'noreply@wndrs.de');
        $fromName = (string) Config::get('mail_from_name', 'WNDRS KLLKTV');
        $lines = [
            'From: ' . self::encodeAddress($fromName, $from),
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'X-Mailer: WNDRS-OS',
        ];
        foreach ($headers as $k => $v) {
            $lines[] = $k . ': ' . $v;
        }
        $ok = @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, implode("\r\n", $lines));
        self::log($to, $subject, $ok ? 'sent' : 'failed');
        return $ok;
    }

    public static function queue(string $to, string $subject, string $body, ?string $sendAt = null): string
    {
        $id = uuid();
        Db::pdo()->prepare(
            'INSERT INTO mail_queue (id, to_email, subject, body, send_at, status) VALUES (?,?,?,?,?,?)'
        )->execute([
            $id,
            $to,
            $subject,
            $body,
            $sendAt ?? gmdate('Y-m-d H:i:s'),
            'pending',
        ]);
        return $id;
    }

    public static function processQueue(int $limit = 20): int
    {
        $pdo = Db::pdo();
        $stmt = $pdo->prepare(
            "SELECT * FROM mail_queue WHERE status = 'pending' AND send_at <= datetime('now') ORDER BY send_at LIMIT ?"
        );
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->execute();
        $n = 0;
        foreach ($stmt->fetchAll() as $row) {
            $ok = self::send($row['to_email'], $row['subject'], $row['body']);
            $pdo->prepare('UPDATE mail_queue SET status = ?, attempts = attempts + 1, last_error = ?, sent_at = datetime(\'now\') WHERE id = ?')
                ->execute([$ok ? 'sent' : 'failed', $ok ? null : 'mail() returned false', $row['id']]);
            $n++;
        }
        return $n;
    }

    private static function encodeAddress(string $name, string $email): string
    {
        return '=?UTF-8?B?' . base64_encode($name) . '?= <' . $email . '>';
    }

    private static function log(string $to, string $subject, string $status): void
    {
        try {
            Db::pdo()->prepare(
                'INSERT INTO mail_log (id, to_email, subject, status, created_at) VALUES (?,?,?,?,datetime(\'now\'))'
            )->execute([uuid(), $to, $subject, $status]);
        } catch (Throwable) {
            // logging must not break send path
        }
    }
}
