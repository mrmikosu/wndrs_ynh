<?php
declare(strict_types=1);

final class Time
{
    public static function nowUtc(): string
    {
        return gmdate('Y-m-d H:i:s');
    }

    public static function toUtc(?string $local, ?string $tz = null): ?string
    {
        if ($local === null || trim($local) === '') {
            return null;
        }
        $tz = $tz ?: (string) Config::get('timezone', 'Europe/Berlin');
        $dt = new DateTimeImmutable(str_replace('T', ' ', $local), new DateTimeZone($tz));
        return $dt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
    }

    public static function toLocal(?string $utc, string $format = 'Y-m-d H:i'): string
    {
        if ($utc === null || trim($utc) === '') {
            return '';
        }
        $tz = (string) Config::get('timezone', 'Europe/Berlin');
        $dt = new DateTimeImmutable($utc, new DateTimeZone('UTC'));
        return $dt->setTimezone(new DateTimeZone($tz))->format($format);
    }

    /**
     * Calculate billable minutes with optional unpaid break and overnight support.
     * ANNAHME: Pause wird pauschal abgezogen, wenn minutes > pauseAfter.
     */
    public static function billableMinutes(int $rawMinutes, int $unpaidBreak = 0, int $pauseAfter = 360): int
    {
        $mins = max(0, $rawMinutes);
        if ($unpaidBreak > 0 && $mins > $pauseAfter) {
            $mins = max(0, $mins - $unpaidBreak);
        }
        return $mins;
    }

    public static function minutesBetween(string $start, string $end): int
    {
        $a = new DateTimeImmutable($start);
        $b = new DateTimeImmutable($end);
        if ($b < $a) {
            $b = $b->modify('+1 day');
        }
        return (int) max(0, ($b->getTimestamp() - $a->getTimestamp()) / 60);
    }

    public static function isNight(string $localStart, int $nightStartHour = 22, int $nightEndHour = 6): bool
    {
        $h = (int) (new DateTimeImmutable($localStart))->format('G');
        return $h >= $nightStartHour || $h < $nightEndHour;
    }

    public static function isWeekend(string $localDate): bool
    {
        $n = (int) (new DateTimeImmutable($localDate))->format('N');
        return $n >= 6;
    }
}
