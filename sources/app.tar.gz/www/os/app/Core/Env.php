<?php
declare(strict_types=1);

final class Env
{
    public static function loadDotEnv(string $path): void
    {
        if (!is_file($path)) {
            return;
        }
        $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
                continue;
            }
            [$k, $v] = explode('=', $line, 2);
            $k = trim($k);
            $v = trim($v, " \t\"'");
            if ($k !== '' && getenv($k) === false) {
                putenv($k . '=' . $v);
                $_ENV[$k] = $v;
            }
        }
    }

    public static function requireKeys(array $keys): void
    {
        $missing = [];
        foreach ($keys as $key) {
            $val = Config::get($key);
            if ($val === null || $val === '') {
                $missing[] = $key;
            }
        }
        if ($missing && (string) Config::get('env', 'local') === 'production') {
            throw new RuntimeException('Fehlende Config-Keys: ' . implode(', ', $missing));
        }
    }
}
