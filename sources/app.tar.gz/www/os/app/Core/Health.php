<?php
declare(strict_types=1);

final class Health
{
    /** @return array{ok:bool,checks:array<string,mixed>} */
    public static function report(): array
    {
        $checks = [];
        $checks['php_version'] = PHP_VERSION;
        $checks['https'] = Security::isHttps();
        try {
            Db::pdo()->query('SELECT 1')->fetchColumn();
            $checks['database'] = 'ok';
        } catch (Throwable $e) {
            $checks['database'] = 'error: ' . $e->getMessage();
        }
        $upload = (string) Config::get('upload_dir');
        $checks['upload_writable'] = is_dir($upload) && is_writable($upload);
        $checks['session'] = session_status() === PHP_SESSION_ACTIVE;
        $checks['mail_from'] = (string) Config::get('mail_from', '');
        $checks['vapid_configured'] = (string) Config::get('vapid_public', '') !== '';
        $checks['cron_token_set'] = (string) Config::get('cron_token', '') !== '';
        $ok = ($checks['database'] === 'ok') && $checks['upload_writable'];
        return ['ok' => $ok, 'checks' => $checks];
    }
}
