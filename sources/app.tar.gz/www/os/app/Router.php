<?php
declare(strict_types=1);

final class Router
{
    public static function dispatch(): void
    {
        $path = request_path();
        $routes = [
            'GET /' => [self::class, 'home'],
            'GET /artists' => [self::class, 'artists'],
            'GET /events' => [self::class, 'publicEvents'],
            'GET /news' => [self::class, 'publicNews'],
            'GET /apply' => [self::class, 'applyForm'],
            'POST /apply' => [self::class, 'applySubmit'],
            'GET /login' => [self::class, 'loginForm'],
            'POST /login' => [self::class, 'loginSubmit'],
            'GET /logout' => [self::class, 'logout'],
            'GET /invite' => [self::class, 'inviteForm'],
            'POST /invite' => [self::class, 'inviteAccept'],
            'GET /health' => [self::class, 'health'],
            'GET /cron' => [self::class, 'cronHttp'],
            'GET /styleguide' => [self::class, 'styleguide'],
            'GET /manifest.webmanifest' => [self::class, 'manifest'],

            'GET /members' => [self::class, 'membersDashboard'],
            'GET /members/mitglieder' => [self::class, 'membersDirectory'],
            'GET /members/nachrichten' => [self::class, 'membersChat'],
            'POST /members/nachrichten' => [self::class, 'membersChatPost'],
            'GET /members/board' => [self::class, 'membersBoard'],
            'POST /members/board' => [self::class, 'membersBoardPost'],
            'GET /members/jobs' => [self::class, 'membersJobs'],
            'POST /members/jobs' => [self::class, 'membersJobSave'],
            'POST /members/jobs/status' => [self::class, 'membersJobStatus'],
            'POST /members/jobs/delete' => [self::class, 'membersJobDelete'],
            'POST /members/jobs/apply' => [Ops::class, 'membersJobApply'],
            'GET /members/wiki' => [self::class, 'membersWiki'],
            'GET /members/wiki/view' => [self::class, 'membersWikiView'],
            'POST /members/wiki' => [self::class, 'membersWikiSave'],
            'GET /members/projekte' => [self::class, 'membersProjects'],
            'GET /members/projekte/view' => [self::class, 'membersProjectView'],
            'GET /members/kanban' => [self::class, 'membersKanban'],
            'POST /members/tasks/status' => [self::class, 'membersTaskStatus'],
            'POST /members/tasks' => [self::class, 'membersTaskCreate'],
            'POST /members/tasks/update' => [self::class, 'membersTaskUpdate'],
            'POST /members/tasks/delete' => [self::class, 'membersTaskDelete'],
            'POST /members/projekte' => [self::class, 'membersProjectCreate'],
            'POST /members/projekte/update' => [self::class, 'membersProjectUpdate'],
            'POST /members/projekte/template' => [Projects::class, 'membersProjectFromTemplate'],
            'POST /members/tasks/comment' => [Projects::class, 'membersTaskComment'],
            'POST /members/tasks/checklist' => [Projects::class, 'membersTaskChecklist'],
            'POST /members/zertifikate' => [Ops::class, 'membersCertificatesSave'],
            'GET /members/datenexport' => [Ops::class, 'membersDataExport'],
            'POST /members/konto-loeschen' => [Ops::class, 'membersAccountDelete'],
            'POST /api/v1/push/subscribe' => [Ops::class, 'apiPushSubscribe'],
            'POST /api/v1/push/unsubscribe' => [Ops::class, 'apiPushUnsubscribe'],
            'GET /api/v1/notifications' => [Ops::class, 'apiNotificationsUnread'],
            'GET /members/events' => [self::class, 'membersEvents'],
            'POST /members/events' => [self::class, 'membersEventCreate'],
            'GET /members/kalender' => [self::class, 'membersCalendar'],
            'POST /members/kalender' => [self::class, 'membersEventCreate'],
            'GET /members/abstimmungen' => [self::class, 'membersPolls'],
            'POST /members/abstimmungen/vote' => [self::class, 'membersPollVote'],
            'GET /members/mediathek' => [self::class, 'membersMedia'],
            'POST /members/mediathek' => [self::class, 'membersMediaUpload'],
            'GET /members/equipment' => [self::class, 'membersEquipment'],
            'POST /members/equipment' => [self::class, 'membersEquipmentReserve'],
            'GET /members/buchungen' => [self::class, 'membersBookings'],
            'POST /members/buchungen' => [self::class, 'membersBookingCreate'],
            'GET /members/finanzen' => [self::class, 'membersFinance'],
            'POST /members/finanzen' => [self::class, 'membersExpenseCreate'],
            'GET /members/profil' => [self::class, 'membersProfile'],
            'POST /members/profil' => [self::class, 'membersProfileSave'],

            'GET /team' => [self::class, 'teamDashboard'],
            'GET /team/zeit' => [self::class, 'teamTime'],
            'POST /team/zeit' => [self::class, 'teamTimeSave'],
            'POST /team/zeit/clock' => [self::class, 'teamTimeClock'],
            'POST /team/zeit/delete' => [self::class, 'teamTimeDelete'],
            'POST /team/zeit/submit' => [self::class, 'teamTimeSubmit'],

            'GET /admin' => [self::class, 'adminDashboard'],
            'GET /admin/mitglieder' => [self::class, 'adminMembers'],
            'POST /admin/mitglieder' => [self::class, 'adminMemberSave'],
            'POST /admin/mitglieder/create' => [self::class, 'adminMemberCreate'],
            'POST /admin/mitglieder/password' => [self::class, 'adminMemberPassword'],
            'GET /admin/invites' => [self::class, 'adminInvites'],
            'POST /admin/invites' => [self::class, 'adminInviteCreate'],
            'GET /admin/bewerbungen' => [self::class, 'adminApplications'],
            'POST /admin/bewerbungen' => [self::class, 'adminApplicationDecide'],
            'GET /admin/inhalte' => [self::class, 'adminContentHub'],
            'GET /admin/cms' => [self::class, 'adminCms'],
            'POST /admin/cms' => [self::class, 'adminCmsSave'],
            'POST /admin/cms/delete' => [self::class, 'adminCmsDelete'],
            'GET /admin/news' => [self::class, 'adminNews'],
            'POST /admin/news' => [self::class, 'adminNewsSave'],
            'POST /admin/news/delete' => [self::class, 'adminNewsDelete'],
            'GET /admin/events' => [self::class, 'adminEvents'],
            'POST /admin/events' => [self::class, 'adminEventsSave'],
            'POST /admin/events/delete' => [self::class, 'adminEventsDelete'],
            'GET /admin/kuenstler' => [self::class, 'adminArtists'],
            'POST /admin/kuenstler' => [self::class, 'adminArtistsSave'],
            'GET /admin/jobs' => [self::class, 'adminJobs'],
            'POST /admin/jobs' => [self::class, 'adminJobsStatus'],
            'POST /admin/jobs/delete' => [self::class, 'adminJobsDelete'],
            'GET /admin/medien' => [self::class, 'adminMedia'],
            'POST /admin/medien' => [self::class, 'adminMediaUpload'],
            'POST /admin/medien/delete' => [self::class, 'adminMediaDelete'],
            'GET /admin/automationen' => [self::class, 'adminAutomations'],
            'GET /admin/audit' => [self::class, 'adminAudit'],
            'GET /admin/zeit' => [self::class, 'adminTime'],
            'POST /admin/zeit' => [self::class, 'adminTimeDecide'],
            'POST /admin/equipment/approve' => [self::class, 'adminEquipmentApprove'],
            'POST /admin/equipment/checkout' => [self::class, 'adminEquipmentCheckout'],
            'POST /admin/equipment/return' => [self::class, 'adminEquipmentReturn'],
            'POST /admin/expenses/decide' => [self::class, 'adminExpenseDecide'],

            'GET /members/schichten' => [Ops::class, 'membersShifts'],
            'POST /members/schichten' => [Ops::class, 'membersShiftRespond'],
            'GET /members/verfuegbarkeit' => [Ops::class, 'membersAvailability'],
            'POST /members/verfuegbarkeit' => [Ops::class, 'membersAvailabilitySave'],
            'GET /members/benachrichtigungen' => [Ops::class, 'membersNotifications'],
            'POST /members/benachrichtigungen' => [Ops::class, 'membersNotificationRead'],
            'GET /members/projekte/cockpit' => [Ops::class, 'membersProjectCockpit'],
            'GET /members/ical' => [Ops::class, 'membersIcal'],

            'GET /admin/inbox' => [Ops::class, 'adminInbox'],
            'POST /admin/inbox/job-apps' => [Ops::class, 'adminInboxJobAppDecide'],
            'GET /admin/seo' => [Ops::class, 'adminSeo'],
            'POST /admin/seo' => [Ops::class, 'adminSeoSave'],
            'GET /admin/analytics' => [Analytics::class, 'adminIndex'],
            'POST /admin/analytics/settings' => [Analytics::class, 'adminSettingsSave'],
            'POST /admin/analytics/totp-setup' => [Analytics::class, 'adminTotpSetup'],
            'GET /admin/analytics/sites' => [Analytics::class, 'adminSites'],
            'POST /admin/analytics/sites' => [Analytics::class, 'adminSitesSave'],
            'GET /admin/analytics/campaigns' => [Analytics::class, 'adminCampaigns'],
            'GET /admin/analytics/campaigns/form' => [Analytics::class, 'adminCampaignForm'],
            'POST /admin/analytics/campaigns' => [Analytics::class, 'adminCampaignSave'],
            'GET /admin/analytics/campaigns/view' => [Analytics::class, 'adminCampaignView'],
            'POST /admin/analytics/campaigns/archive' => [Analytics::class, 'adminCampaignArchive'],
            'POST /admin/analytics/campaigns/restore' => [Analytics::class, 'adminCampaignRestore'],
            'GET /admin/analytics/export.csv' => [Analytics::class, 'adminExportCsv'],
            'GET /admin/einstellungen' => [Ops::class, 'adminSettings'],
            'POST /admin/einstellungen' => [Ops::class, 'adminSettingsSave'],
            'GET /admin/budget' => [Ops::class, 'adminBudget'],
            'POST /admin/budget' => [Ops::class, 'adminBudgetSave'],
            'GET /admin/schichten' => [Ops::class, 'adminShifts'],
            'POST /admin/schichten' => [Ops::class, 'adminShiftsSave'],
            'GET /admin/foerderung' => [ProjectExtras::class, 'adminFunding'],
            'POST /admin/foerderung' => [ProjectExtras::class, 'adminFundingSave'],
            'GET /admin/risiken' => [ProjectExtras::class, 'adminRisks'],
            'POST /admin/risiken' => [ProjectExtras::class, 'adminRisksSave'],
            'GET /admin/crm' => [ProjectExtras::class, 'adminCrm'],
            'POST /admin/crm' => [ProjectExtras::class, 'adminCrmSave'],
        ];

        $key = method() . ' ' . $path;
        if (!isset($routes[$key])) {
            http_response_code(404);
            echo '404 Not Found';
            return;
        }
        ($routes[$key])();
    }

    /* ---------- Public ---------- */

    public static function home(): void
    {
        $db = Db::pdo();
        $page = $db->query("SELECT * FROM pages WHERE slug = 'home' AND status = 'published'")->fetch() ?: null;
        $blocks = $page ? json_decode_db($page['blocks']) : [
            ['type' => 'hero', 'eyebrow' => 'WNDRS', 'headline' => 'Kollektiv'],
        ];
        $events = $db->query("SELECT * FROM events WHERE public = 1 AND status = 'published' ORDER BY starts_at LIMIT 5")->fetchAll();
        $news = $db->query("SELECT * FROM news_posts WHERE public = 1 AND status = 'published' ORDER BY created_at DESC LIMIT 3")->fetchAll();
        layout('www', 'www/home', compact('blocks', 'events', 'news'));
    }

    public static function artists(): void
    {
        $db = Db::pdo();
        $rows = $db->query("SELECT p.*, u.display_name FROM profiles p JOIN users u ON u.id = p.user_id WHERE p.public_visible = 1 ORDER BY p.artist_name")->fetchAll();
        layout('www', 'www/artists', ['artists' => $rows]);
    }

    public static function publicEvents(): void
    {
        $db = Db::pdo();
        $rows = $db->query("SELECT * FROM events WHERE public = 1 AND status = 'published' ORDER BY starts_at")->fetchAll();
        layout('www', 'www/events', ['events' => $rows]);
    }

    public static function publicNews(): void
    {
        $db = Db::pdo();
        $rows = $db->query("SELECT * FROM news_posts WHERE public = 1 AND status = 'published' ORDER BY created_at DESC")->fetchAll();
        layout('www', 'www/news', ['news' => $rows]);
    }

    public static function applyForm(): void
    {
        layout('www', 'www/apply', []);
    }

    public static function applySubmit(): void
    {
        require_csrf();
        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $message = trim($_POST['message'] ?? '');
        $disciplines = array_values(array_filter(array_map('trim', explode(',', $_POST['disciplines'] ?? ''))));
        if ($name === '' || $email === '') {
            flash('error', 'Name und E-Mail sind Pflicht.');
            redirect('/apply');
        }
        $db = Db::pdo();
        $id = uuid();
        $db->prepare('INSERT INTO applications (id, name, email, message, disciplines) VALUES (?,?,?,?,?)')
            ->execute([$id, $name, $email, $message, json_encode_db($disciplines)]);
        audit($db, null, 'application.create', 'application', $id);
        flash('success', 'Bewerbung eingegangen. Danke!');
        redirect('/apply');
    }

    public static function loginForm(): void
    {
        if (Auth::user()) {
            self::postLoginRedirect(Auth::user());
        }
        layout('auth', 'auth/login', []);
    }

    public static function loginSubmit(): void
    {
        RateLimit::enforce('login', 10, 300);
        require_csrf();
        $ok = Auth::login($_POST['email'] ?? '', $_POST['password'] ?? '');
        if (!$ok) {
            flash('error', 'Login fehlgeschlagen.');
            redirect('/login');
        }
        self::postLoginRedirect(Auth::user());
    }

    public static function health(): void
    {
        $report = Health::report();
        http_response_code($report['ok'] ? 200 : 503);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($report, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }

    public static function cronHttp(): void
    {
        require dirname(__DIR__) . '/cron/worker.php';
        exit;
    }

    public static function styleguide(): void
    {
        $user = Auth::requireLogin();
        layout('members', 'system/styleguide', compact('user'));
    }

    public static function manifest(): void
    {
        header('Content-Type: application/manifest+json; charset=utf-8');
        $name = (string) Config::get('app_name', 'WNDRS');
        $scope = base_path() !== '' ? base_path() . '/' : '/';
        echo json_encode([
            'name' => $name,
            'short_name' => 'WNDRS',
            'description' => 'Team-Plattform für WNDRS KLLKTV',
            'start_url' => u('/members'),
            'scope' => $scope,
            'display' => 'standalone',
            'background_color' => '#0c0b0a',
            'theme_color' => '#0c0b0a',
            'lang' => 'de',
            'icons' => [
                ['src' => u('/assets/icons/icon-192.png'), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => u('/assets/icons/icon-512.png'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any'],
                ['src' => u('/assets/icons/icon-192-maskable.png'), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'maskable'],
                ['src' => u('/assets/icons/icon-512-maskable.png'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable'],
            ],
            'shortcuts' => [
                ['name' => 'Zeit starten', 'url' => u('/team/zeit'), 'description' => 'Arbeitszeit erfassen'],
                ['name' => 'Mein Einsatzplan', 'url' => u('/members/kalender'), 'description' => 'Kalender öffnen'],
                ['name' => 'Jobbörse', 'url' => u('/members/jobs'), 'description' => 'Jobs ansehen'],
            ],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }

    private static function postLoginRedirect(?array $user): never
    {
        if ($user && Rbac::can($user['roles'], 'admin.access')) {
            redirect('/admin');
        }
        if ($user && Rbac::can($user['roles'], 'team.access')) {
            redirect('/team');
        }
        redirect('/members');
    }

    private static function minutesFromRange(?string $start, ?string $end): int
    {
        if (!$start || !$end) {
            return 0;
        }
        $a = strtotime($start);
        $b = strtotime($end);
        if ($a === false || $b === false || $b <= $a) {
            return 0;
        }
        return (int) round(($b - $a) / 60);
    }

    public static function logout(): void
    {
        Auth::logout();
        header('Location: ' . public_home_url());
        exit;
    }

    public static function inviteForm(): void
    {
        $token = $_GET['token'] ?? '';
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM invites WHERE token = ? AND accepted_at IS NULL');
        $stmt->execute([$token]);
        $invite = $stmt->fetch();
        layout('auth', 'auth/invite', compact('invite', 'token'));
    }

    public static function inviteAccept(): void
    {
        require_csrf();
        $token = $_POST['token'] ?? '';
        $password = $_POST['password'] ?? '';
        $name = trim($_POST['display_name'] ?? '');
        if (strlen($password) < 8) {
            flash('error', 'Passwort mind. 8 Zeichen.');
            redirect('/invite?token=' . urlencode($token));
        }
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM invites WHERE token = ? AND accepted_at IS NULL');
        $stmt->execute([$token]);
        $invite = $stmt->fetch();
        if (!$invite) {
            flash('error', 'Invite ungültig.');
            redirect('/login');
        }
        $email = strtolower($invite['email']);
        $roles = json_decode_db($invite['roles'], ['member']);
        $existing = $db->prepare('SELECT id FROM users WHERE email = ?');
        $existing->execute([$email]);
        $uid = $existing->fetchColumn();
        if (!$uid) {
            $uid = uuid();
            $db->prepare('INSERT INTO users (id, email, display_name, password_hash) VALUES (?,?,?,?)')
                ->execute([$uid, $email, $name ?: $email, password_hash($password, PASSWORD_DEFAULT)]);
            $db->prepare('INSERT INTO memberships (id, user_id, status, joined_at) VALUES (?,?,?,datetime("now"))')
                ->execute([uuid(), $uid, 'active']);
            $db->prepare('INSERT INTO profiles (id, user_id, artist_name) VALUES (?,?,?)')
                ->execute([uuid(), $uid, $name ?: $email]);
        } else {
            $db->prepare('UPDATE users SET password_hash = ?, display_name = ? WHERE id = ?')
                ->execute([password_hash($password, PASSWORD_DEFAULT), $name ?: $email, $uid]);
            $db->prepare('UPDATE memberships SET status = ?, joined_at = datetime("now") WHERE user_id = ?')
                ->execute(['active', $uid]);
        }
        $db->prepare('DELETE FROM role_assignments WHERE user_id = ?')->execute([$uid]);
        foreach ($roles as $role) {
            $db->prepare('INSERT INTO role_assignments (id, user_id, role) VALUES (?,?,?)')->execute([uuid(), $uid, $role]);
        }
        $db->prepare('UPDATE invites SET accepted_at = datetime("now") WHERE id = ?')->execute([$invite['id']]);
        audit($db, $uid, 'invite.accept', 'invite', $invite['id']);
        Auth::login($email, $password);
        redirect('/members');
    }

    /* ---------- Members ---------- */

    public static function membersDashboard(): void
    {
        $user = Auth::requireMember();
        $actor = Actor::fromUser($user);
        // Alle Abschnitte aus dem berechtigten Datenbereich (DashboardQuery, Phase 4).
        $dash = (new DashboardQuery(Db::pdo()))->forActor($actor);
        layout('members', 'members/dashboard', array_merge(['user' => $user], $dash));
    }

    public static function membersDirectory(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $rows = $db->query("SELECT u.display_name, u.email, p.*, m.status AS membership_status FROM users u LEFT JOIN profiles p ON p.user_id = u.id LEFT JOIN memberships m ON m.user_id = u.id ORDER BY u.display_name")->fetchAll();
        layout('members', 'members/directory', ['user' => $user, 'people' => $rows]);
    }

    public static function membersChat(): void
    {
        $user = Auth::requireMember();
        $actor = Actor::fromUser($user);
        $db = Db::pdo();
        // Nur sichtbare Kanäle auflisten (öffentlich + privat mit Mitgliedschaft).
        $channels = ChannelPolicy::visibleChannels($actor, $db);
        $channelId = $_GET['channel'] ?? ($channels[0]['id'] ?? '');
        $messages = [];
        if ($channelId) {
            $channel = self::findChannel($db, (string) $channelId);
            if ($channel === null || !ChannelPolicy::canRead($actor, $channel, $db)) {
                http_response_code(403);
                echo 'Kein Zugriff auf diesen Kanal.';
                exit;
            }
            $stmt = $db->prepare('SELECT m.*, u.display_name FROM messages m JOIN users u ON u.id = m.author_id WHERE m.channel_id = ? ORDER BY m.created_at ASC LIMIT 200');
            $stmt->execute([$channelId]);
            $messages = $stmt->fetchAll();
        }
        layout('members', 'members/chat', compact('user', 'channels', 'channelId', 'messages'));
    }

    public static function membersChatPost(): void
    {
        $user = Auth::requireMember();
        $actor = Actor::fromUser($user);
        require_csrf();
        $channelId = $_POST['channel_id'] ?? '';
        $body = trim($_POST['body'] ?? '');
        if ($channelId && $body !== '') {
            $db = Db::pdo();
            $channel = self::findChannel($db, (string) $channelId);
            // Kanal existiert + lesbar + Recht 'channels.write' (bei privaten Kanälen: Mitgliedschaft).
            if ($channel === null || !ChannelPolicy::canWrite($actor, $channel, $db)) {
                http_response_code(403);
                echo 'Keine Schreibberechtigung für diesen Kanal.';
                exit;
            }
            $db->prepare('INSERT INTO messages (id, channel_id, author_id, body) VALUES (?,?,?,?)')
                ->execute([uuid(), $channelId, $user['id'], $body]);
        }
        redirect('/members/nachrichten?channel=' . urlencode($channelId));
    }

    public static function membersBoard(): void
    {
        $user = Auth::requireMember();
        $posts = Db::pdo()->query('SELECT b.*, u.display_name FROM board_posts b JOIN users u ON u.id = b.author_id ORDER BY b.pinned DESC, b.created_at DESC')->fetchAll();
        layout('members', 'members/board', compact('user', 'posts'));
    }

    public static function membersBoardPost(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $title = trim($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');
        $category = trim($_POST['category'] ?? 'general');
        if ($title && $body) {
            Db::pdo()->prepare('INSERT INTO board_posts (id, author_id, title, body, category) VALUES (?,?,?,?,?)')
                ->execute([uuid(), $user['id'], $title, $body, $category]);
        }
        redirect('/members/board');
    }

    /** @return list<string> */
    private static function jobRoles(): array
    {
        return [
            'runner', 'barkeeper', 'fotograf', 'videograf', 'dj', 'techniker',
            'licht', 'ton', 'stagehand', 'security', 'warden', 'koch', 'service',
            'produktion', 'artist', 'other',
        ];
    }

    public static function membersJobs(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $kind = $_GET['kind'] ?? '';
        $role = $_GET['role'] ?? '';
        $status = $_GET['status'] ?? 'open';
        $sql = 'SELECT j.*, u.display_name FROM job_posts j JOIN users u ON u.id = j.author_id WHERE 1=1';
        $params = [];
        if (in_array($kind, ['angebot', 'gesuch'], true)) {
            $sql .= ' AND j.kind = ?';
            $params[] = $kind;
        }
        if ($role !== '' && in_array($role, self::jobRoles(), true)) {
            $sql .= ' AND j.role = ?';
            $params[] = $role;
        }
        if (in_array($status, ['open', 'filled', 'closed'], true)) {
            $sql .= ' AND j.status = ?';
            $params[] = $status;
        } elseif ($status === 'all') {
            // no status filter
        } else {
            $sql .= " AND j.status = 'open'";
        }
        $sql .= ' ORDER BY j.created_at DESC';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $jobs = $stmt->fetchAll();
        $appCounts = [];
        $stmtCounts = $db->query('SELECT job_id, COUNT(*) AS cnt FROM job_applications GROUP BY job_id');
        foreach ($stmtCounts->fetchAll() as $row) {
            $appCounts[$row['job_id']] = (int) $row['cnt'];
        }
        $myApps = [];
        $stmtMine = $db->prepare('SELECT job_id, status FROM job_applications WHERE user_id = ?');
        $stmtMine->execute([$user['id']]);
        foreach ($stmtMine->fetchAll() as $row) {
            $myApps[$row['job_id']] = $row['status'];
        }
        $roles = self::jobRoles();
        layout('members', 'members/jobs', compact('user', 'jobs', 'roles', 'kind', 'role', 'status', 'appCounts', 'myApps'));
    }

    public static function membersJobSave(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $title = trim($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');
        $kind = $_POST['kind'] ?? 'gesuch';
        $role = $_POST['role'] ?? 'other';
        if (!in_array($kind, ['angebot', 'gesuch'], true)) {
            $kind = 'gesuch';
        }
        if (!in_array($role, self::jobRoles(), true)) {
            $role = 'other';
        }
        if ($title === '' || $body === '') {
            flash('error', 'Titel und Beschreibung sind Pflicht.');
            redirect('/members/jobs');
        }
        $id = $_POST['id'] ?? '';
        $db = Db::pdo();
        $payload = [
            $kind,
            $role,
            $title,
            $body,
            trim($_POST['location'] ?? ''),
            ($_POST['event_date'] ?? '') !== '' ? $_POST['event_date'] : null,
            trim($_POST['pay_note'] ?? ''),
            trim($_POST['contact'] ?? ($user['email'] ?? '')),
        ];
        if ($id) {
            $own = $db->prepare('SELECT id FROM job_posts WHERE id = ? AND author_id = ?');
            $own->execute([$id, $user['id']]);
            if ($own->fetchColumn() || Rbac::can($user['roles'], 'admin.access')) {
                $db->prepare('UPDATE job_posts SET kind=?, role=?, title=?, body=?, location=?, event_date=?, pay_note=?, contact=?, updated_at=datetime("now") WHERE id=?')
                    ->execute([...$payload, $id]);
            }
        } else {
            $db->prepare('INSERT INTO job_posts (id, author_id, kind, role, title, body, location, event_date, pay_note, contact, status) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
                ->execute([uuid(), $user['id'], ...$payload, 'open']);
        }
        flash('success', 'Jobpost gespeichert.');
        redirect('/members/jobs');
    }

    public static function membersJobStatus(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $id = $_POST['id'] ?? '';
        $status = $_POST['status'] ?? 'open';
        if (!in_array($status, ['open', 'filled', 'closed'], true)) {
            $status = 'closed';
        }
        $db = Db::pdo();
        if (Rbac::can($user['roles'], 'admin.access')) {
            $db->prepare('UPDATE job_posts SET status = ?, updated_at = datetime("now") WHERE id = ?')->execute([$status, $id]);
        } else {
            $db->prepare('UPDATE job_posts SET status = ?, updated_at = datetime("now") WHERE id = ? AND author_id = ?')
                ->execute([$status, $id, $user['id']]);
        }
        redirect('/members/jobs?status=all');
    }

    public static function membersJobDelete(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $id = $_POST['id'] ?? '';
        $db = Db::pdo();
        if (Rbac::can($user['roles'], 'admin.access')) {
            $db->prepare('DELETE FROM job_posts WHERE id = ?')->execute([$id]);
        } else {
            $db->prepare('DELETE FROM job_posts WHERE id = ? AND author_id = ?')->execute([$id, $user['id']]);
        }
        redirect('/members/jobs');
    }

    public static function membersWiki(): void
    {
        $user = Auth::requireMember();
        $pages = Db::pdo()->query('SELECT slug, title, updated_at FROM wiki_pages ORDER BY title')->fetchAll();
        layout('members', 'members/wiki', compact('user', 'pages'));
    }

    public static function membersWikiView(): void
    {
        $user = Auth::requireMember();
        $slug = $_GET['slug'] ?? '';
        $stmt = Db::pdo()->prepare('SELECT * FROM wiki_pages WHERE slug = ?');
        $stmt->execute([$slug]);
        $page = $stmt->fetch();
        layout('members', 'members/wiki_view', compact('user', 'page'));
    }

    public static function membersWikiSave(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $slug = trim($_POST['slug'] ?? '');
        $title = trim($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');
        if ($slug && $title) {
            $db = Db::pdo();
            $exists = $db->prepare('SELECT id, version FROM wiki_pages WHERE slug = ?');
            $exists->execute([$slug]);
            $row = $exists->fetch();
            if ($row) {
                $db->prepare('UPDATE wiki_pages SET title = ?, body = ?, version = version + 1, updated_by_id = ?, updated_at = datetime("now") WHERE id = ?')
                    ->execute([$title, $body, $user['id'], $row['id']]);
            } else {
                $db->prepare('INSERT INTO wiki_pages (id, slug, title, body, updated_by_id) VALUES (?,?,?,?,?)')
                    ->execute([uuid(), $slug, $title, $body, $user['id']]);
            }
        }
        redirect('/members/wiki/view?slug=' . urlencode($slug));
    }

    public static function membersProjects(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $projects = $db->query(
            "SELECT p.*,
              (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id) AS task_count,
              (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.status = 'done') AS done_count,
              (SELECT COUNT(*) FROM tasks t WHERE t.project_id = p.id AND t.status = 'doing') AS doing_count,
              u.display_name AS lead_name
             FROM projects p
             LEFT JOIN users u ON u.id = p.lead_id
             ORDER BY CASE p.status WHEN 'active' THEN 0 WHEN 'planned' THEN 1 ELSE 2 END, p.created_at DESC"
        )->fetchAll();
        $members = $db->query('SELECT id, display_name FROM users WHERE is_active = 1 ORDER BY display_name')->fetchAll();
        layout('members', 'members/projects', compact('user', 'projects', 'members'));
    }

    public static function membersKanban(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $projects = $db->query("SELECT id, title, status FROM projects WHERE status != 'archived' ORDER BY title")->fetchAll();
        $projectId = $_GET['project'] ?? ($projects[0]['id'] ?? '');
        $project = null;
        $tasks = [];
        $members = $db->query('SELECT id, display_name FROM users WHERE is_active = 1 ORDER BY display_name')->fetchAll();
        $focusTaskId = $_GET['task'] ?? '';
        $taskDetail = null;
        if ($projectId) {
            $stmt = $db->prepare('SELECT p.*, u.display_name AS lead_name FROM projects p LEFT JOIN users u ON u.id = p.lead_id WHERE p.id = ?');
            $stmt->execute([$projectId]);
            $project = $stmt->fetch() ?: null;
            if ($project) {
                $t = $db->prepare(
                    'SELECT t.*, a.display_name AS assignee_name FROM tasks t
                     LEFT JOIN users a ON a.id = t.assignee_id
                     WHERE t.project_id = ? ORDER BY t.sort_order, t.created_at'
                );
                $t->execute([$projectId]);
                $tasks = $t->fetchAll();
                if ($focusTaskId !== '') {
                    $taskDetail = Projects::taskDetail($db, $focusTaskId, $projectId);
                }
            }
        }
        $viewMode = 'kanban';
        $returnTo = '/members/kanban?project=' . urlencode((string) $projectId);
        if ($focusTaskId !== '') {
            $returnTo .= '&task=' . urlencode($focusTaskId);
        }
        layout('members', 'members/kanban', compact(
            'user',
            'projects',
            'project',
            'projectId',
            'tasks',
            'members',
            'viewMode',
            'returnTo',
            'focusTaskId',
            'taskDetail'
        ));
    }

    public static function membersProjectCreate(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $title = trim($_POST['title'] ?? '');
        if ($title) {
            $id = uuid();
            $status = $_POST['status'] ?? 'planned';
            if (!in_array($status, ['planned', 'active', 'paused', 'done', 'archived'], true)) {
                $status = 'planned';
            }
            $priority = $_POST['priority'] ?? 'medium';
            if (!in_array($priority, ['low', 'medium', 'high', 'urgent'], true)) {
                $priority = 'medium';
            }
            $lead = $_POST['lead_id'] ?: $user['id'];
            Db::pdo()->prepare('INSERT INTO projects (id, title, description, status, priority, lead_id) VALUES (?,?,?,?,?,?)')
                ->execute([$id, $title, trim($_POST['description'] ?? ''), $status, $priority, $lead]);
            // starter tasks
            $starter = [
                ['Kickoff / Scope', 'todo'],
                ['Umsetzung', 'todo'],
                ['Review / Abschluss', 'todo'],
            ];
            foreach ($starter as $i => [$tt, $st]) {
                Db::pdo()->prepare('INSERT INTO tasks (id, project_id, title, status, sort_order) VALUES (?,?,?,?,?)')
                    ->execute([uuid(), $id, $tt, $st, $i]);
            }
            // Ersteller wird Projekt-Lead, damit die ProjectPolicy (Phase 1) greift.
            Db::pdo()->prepare('INSERT OR IGNORE INTO project_memberships (id, project_id, user_id, role) VALUES (?,?,?,?)')
                ->execute([uuid(), $id, $user['id'], 'lead']);
            redirect('/members/projekte/view?id=' . urlencode($id));
        }
        redirect('/members/projekte');
    }

    public static function membersProjectUpdate(): void
    {
        $actor = Actor::requireMember();
        require_csrf();
        $id = $_POST['project_id'] ?? '';
        $title = trim($_POST['title'] ?? '');
        if ($id && $title) {
            $db = Db::pdo();
            $project = self::findProject($db, (string) $id);
            if ($project === null) {
                http_response_code(404);
                echo 'Projekt nicht gefunden.';
                exit;
            }
            // Nur 'projects.manage'/'*' oder die Lead-Rolle DIESES Projekts.
            if (!ProjectPolicy::canManage($actor, $project, $db)) {
                http_response_code(403);
                echo 'Keine Berechtigung für dieses Projekt.';
                exit;
            }
            // Whitelist wie beim Anlegen (Phase-0-Befund: Update hatte Freitext-Status).
            $status = $_POST['status'] ?? 'planned';
            if (!in_array($status, ['planned', 'active', 'paused', 'done', 'archived'], true)) {
                $status = 'planned';
            }
            $priority = $_POST['priority'] ?? 'medium';
            if (!in_array($priority, ['low', 'medium', 'high', 'urgent'], true)) {
                $priority = 'medium';
            }
            $db->prepare('UPDATE projects SET title = ?, description = ?, status = ?, priority = ?, lead_id = ? WHERE id = ?')
                ->execute([
                    $title,
                    trim($_POST['description'] ?? ''),
                    $status,
                    $priority,
                    $_POST['lead_id'] ?: null,
                    $id,
                ]);
        }
        $back = $_POST['return_to'] ?? ('/members/projekte/view?id=' . urlencode($id));
        redirect($back);
    }

    public static function membersProjectView(): void
    {
        $user = Auth::requireMember();
        $id = $_GET['id'] ?? '';
        $viewMode = $_GET['view'] ?? 'kanban';
        if (!in_array($viewMode, ['kanban', 'list'], true)) {
            $viewMode = 'kanban';
        }
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT p.*, u.display_name AS lead_name FROM projects p LEFT JOIN users u ON u.id = p.lead_id WHERE p.id = ?');
        $stmt->execute([$id]);
        $project = $stmt->fetch();
        $tasks = [];
        $members = $db->query('SELECT id, display_name FROM users WHERE is_active = 1 ORDER BY display_name')->fetchAll();
        $focusTaskId = $_GET['task'] ?? '';
        $taskDetail = null;
        if ($project) {
            $t = $db->prepare(
                'SELECT t.*, a.display_name AS assignee_name FROM tasks t
                 LEFT JOIN users a ON a.id = t.assignee_id
                 WHERE t.project_id = ? ORDER BY t.sort_order, t.created_at'
            );
            $t->execute([$id]);
            $tasks = $t->fetchAll();
            if ($focusTaskId !== '') {
                $taskDetail = Projects::taskDetail($db, $focusTaskId, $id);
            }
        }
        $returnTo = '/members/projekte/view?id=' . urlencode($id) . '&view=' . urlencode($viewMode);
        if ($focusTaskId !== '') {
            $returnTo .= '&task=' . urlencode($focusTaskId);
        }
        layout('members', 'members/project_view', compact(
            'user',
            'project',
            'tasks',
            'members',
            'viewMode',
            'returnTo',
            'focusTaskId',
            'taskDetail'
        ));
    }

    public static function membersTaskStatus(): void
    {
        $actor = Actor::requireMember();
        require_csrf();
        $id = $_POST['task_id'] ?? '';
        $status = $_POST['status'] ?? 'todo';
        if (!in_array($status, ['todo', 'doing', 'done'], true)) {
            $status = 'todo';
        }
        $db = Db::pdo();
        $task = self::findTask($db, (string) $id);
        if ($task === null) {
            self::taskGateFail(404, 'Aufgabe nicht gefunden.');
        }
        if (!ProjectPolicy::canEditTask($actor, self::findProjectForTask($db, $task), $db)) {
            self::taskGateFail(403, 'Keine Berechtigung für diese Aufgabe.');
        }
        $db->prepare('UPDATE tasks SET status = ? WHERE id = ?')->execute([$status, $id]);
        if (!empty($_POST['ajax'])) {
            header('Content-Type: application/json');
            echo json_encode(['ok' => true, 'status' => $status]);
            exit;
        }
        $back = $_POST['return_to'] ?? '';
        if ($back) {
            redirect($back);
        }
        $proj = $db->prepare('SELECT project_id FROM tasks WHERE id = ?');
        $proj->execute([$id]);
        $pid = $proj->fetchColumn();
        redirect('/members/projekte/view?id=' . urlencode((string) $pid));
    }

    public static function membersTaskCreate(): void
    {
        $actor = Actor::requireMember();
        require_csrf();
        $projectId = $_POST['project_id'] ?? '';
        $title = trim($_POST['title'] ?? '');
        $status = $_POST['status'] ?? 'todo';
        if (!in_array($status, ['todo', 'doing', 'done'], true)) {
            $status = 'todo';
        }
        if ($projectId && $title) {
            $db = Db::pdo();
            $project = self::findProject($db, (string) $projectId);
            if ($project === null) {
                self::taskGateFail(404, 'Projekt nicht gefunden.');
            }
            // Wie membersTaskUpdate: nur Lead/Contributor dieses Projekts oder globale Verwalter.
            if (!ProjectPolicy::canEditTask($actor, $project, $db)) {
                self::taskGateFail(403, 'Keine Berechtigung für dieses Projekt.');
            }
            $priority = $_POST['priority'] ?? 'medium';
            if (!in_array($priority, ['low', 'medium', 'high', 'urgent'], true)) {
                $priority = 'medium';
            }
            $max = $db->prepare('SELECT COALESCE(MAX(sort_order), -1) FROM tasks WHERE project_id = ? AND status = ?');
            $max->execute([$projectId, $status]);
            $order = ((int) $max->fetchColumn()) + 1;
            $db->prepare(
                'INSERT INTO tasks (id, project_id, title, description, status, priority, assignee_id, due_at, sort_order) VALUES (?,?,?,?,?,?,?,?,?)'
            )->execute([
                uuid(),
                $projectId,
                $title,
                trim($_POST['description'] ?? ''),
                $status,
                $priority,
                $_POST['assignee_id'] ?: null,
                $_POST['due_at'] ?: null,
                $order,
            ]);
            if (!empty($_POST['ajax'])) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['ok' => true]);
                exit;
            }
        }
        $back = $_POST['return_to'] ?? ('/members/projekte/view?id=' . urlencode($projectId));
        redirect($back);
    }

    public static function membersTaskUpdate(): void
    {
        $actor = Actor::requireMember();
        require_csrf();
        $id = $_POST['task_id'] ?? '';
        $title = trim($_POST['title'] ?? '');
        if ($id && $title) {
            $db = Db::pdo();
            $task = self::findTask($db, (string) $id);
            if ($task === null) {
                http_response_code(404);
                echo 'Aufgabe nicht gefunden.';
                exit;
            }
            if (!ProjectPolicy::canEditTask($actor, self::findProjectForTask($db, $task), $db)) {
                http_response_code(403);
                echo 'Keine Berechtigung für diese Aufgabe.';
                exit;
            }
            $priority = $_POST['priority'] ?? 'medium';
            $status = $_POST['status'] ?? 'todo';
            $db->prepare(
                'UPDATE tasks SET title = ?, description = ?, status = ?, priority = ?, assignee_id = ?, due_at = ? WHERE id = ?'
            )->execute([
                $title,
                trim($_POST['description'] ?? ''),
                $status,
                $priority,
                $_POST['assignee_id'] ?: null,
                $_POST['due_at'] ?: null,
                $id,
            ]);
        }
        $back = $_POST['return_to'] ?? '/members/projekte';
        redirect($back);
    }

    public static function membersTaskDelete(): void
    {
        $actor = Actor::requireMember();
        require_csrf();
        $id = $_POST['task_id'] ?? '';
        $db = Db::pdo();
        $proj = $db->prepare('SELECT project_id FROM tasks WHERE id = ?');
        $proj->execute([$id]);
        $pid = (string) $proj->fetchColumn();
        if ($id) {
            $task = self::findTask($db, (string) $id);
            if ($task === null) {
                http_response_code(404);
                echo 'Aufgabe nicht gefunden.';
                exit;
            }
            if (!ProjectPolicy::canEditTask($actor, self::findProjectForTask($db, $task), $db)) {
                http_response_code(403);
                echo 'Keine Berechtigung für diese Aufgabe.';
                exit;
            }
            $db->prepare('DELETE FROM tasks WHERE id = ?')->execute([$id]);
        }
        $back = $_POST['return_to'] ?? ('/members/projekte/view?id=' . urlencode($pid));
        redirect($back);
    }

    public static function membersEvents(): void
    {
        $user = Auth::requireMember();
        $events = Db::pdo()->query('SELECT * FROM events ORDER BY starts_at DESC')->fetchAll();
        layout('members', 'members/events', compact('user', 'events'));
    }

    public static function membersCalendar(): void
    {
        $user = Auth::requireMember();
        $year = (int) ($_GET['y'] ?? date('Y'));
        $month = (int) ($_GET['m'] ?? date('n'));
        if ($month < 1 || $month > 12) {
            $month = (int) date('n');
        }
        if ($year < 2000 || $year > 2100) {
            $year = (int) date('Y');
        }

        $start = sprintf('%04d-%02d-01', $year, $month);
        $endExclusive = date('Y-m-d', strtotime($start . ' +1 month'));
        $db = Db::pdo();

        $stmt = $db->prepare(
            "SELECT * FROM events
             WHERE starts_at IS NOT NULL
               AND date(starts_at) >= date(?)
               AND date(starts_at) < date(?)
             ORDER BY starts_at ASC"
        );
        $stmt->execute([$start, $endExclusive]);
        $events = $stmt->fetchAll();

        $byDay = [];
        foreach ($events as $ev) {
            $day = substr((string) $ev['starts_at'], 0, 10);
            $byDay[$day][] = $ev;
        }

        // also show bookings in month (resource calendar overlay)
        $b = $db->prepare(
            "SELECT * FROM bookings
             WHERE date(starts_at) >= date(?) AND date(starts_at) < date(?)
             ORDER BY starts_at ASC"
        );
        $b->execute([$start, $endExclusive]);
        $bookings = $b->fetchAll();
        $bookingsByDay = [];
        foreach ($bookings as $row) {
            $day = substr((string) $row['starts_at'], 0, 10);
            $bookingsByDay[$day][] = $row;
        }

        $firstDow = (int) date('N', strtotime($start)); // 1=Mon … 7=Sun
        $daysInMonth = (int) date('t', strtotime($start));
        $prev = strtotime($start . ' -1 month');
        $next = strtotime($start . ' +1 month');
        $selected = $_GET['day'] ?? date('Y-m-d');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selected)) {
            $selected = date('Y-m-d');
        }

        $monthLabel = [
            1 => 'Januar', 2 => 'Februar', 3 => 'März', 4 => 'April', 5 => 'Mai', 6 => 'Juni',
            7 => 'Juli', 8 => 'August', 9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Dezember',
        ][$month] . ' ' . $year;

        layout('members', 'members/calendar', compact(
            'user', 'year', 'month', 'monthLabel', 'firstDow', 'daysInMonth',
            'byDay', 'bookingsByDay', 'events', 'prev', 'next', 'selected', 'start'
        ));
    }

    public static function membersEventCreate(): void
    {
        $actor = Actor::requireMember();
        require_csrf();
        // Mitglieder legen nur Entwürfe an (Phase 5d): public/status werden im
        // Service erzwungen — gepostete Werte dafür werden ignoriert.
        try {
            (new MemberEventCreate(Db::pdo()))->create($actor, $_POST);
            flash('success', 'Event als Entwurf angelegt. Veröffentlichung erfolgt nach Freigabe (Kollektiv-Team).');
        } catch (ApprovalValidation $e) {
            flash('error', $e->getMessage());
        }
        $back = $_POST['return_to'] ?? '/members/events';
        redirect($back);
    }

    public static function membersPolls(): void
    {
        $user = Auth::requireMember();
        $polls = Db::pdo()->query('SELECT * FROM polls ORDER BY created_at DESC')->fetchAll();
        layout('members', 'members/polls', compact('user', 'polls'));
    }

    public static function membersPollVote(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $pollId = $_POST['poll_id'] ?? '';
        $choice = trim($_POST['choice'] ?? '');
        if ($pollId && $choice !== '') {
            $db = Db::pdo();
            $db->prepare('INSERT INTO votes (id, poll_id, voter_id, choice) VALUES (?,?,?,?) ON CONFLICT(poll_id, voter_id) DO UPDATE SET choice = excluded.choice')
                ->execute([uuid(), $pollId, $user['id'], $choice]);
        }
        redirect('/members/abstimmungen');
    }

    public static function membersMedia(): void
    {
        $user = Auth::requireMember();
        $rows = Db::pdo()->query('SELECT * FROM media_assets ORDER BY created_at DESC')->fetchAll();
        layout('members', 'members/media', compact('user', 'rows'));
    }

    public static function membersMediaUpload(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        self::handleUpload($user['id'], 'members');
        redirect('/members/mediathek');
    }

    public static function membersEquipment(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $assets = $db->query('SELECT * FROM assets ORDER BY name')->fetchAll();
        $reservations = $db->query('SELECT r.*, a.name AS asset_name, u.display_name FROM asset_reservations r JOIN assets a ON a.id = r.asset_id JOIN users u ON u.id = r.requester_id ORDER BY r.created_at DESC LIMIT 50')->fetchAll();
        layout('members', 'members/equipment', compact('user', 'assets', 'reservations'));
    }

    public static function membersEquipmentReserve(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $assetId = $_POST['asset_id'] ?? '';
        $starts = $_POST['starts_at'] ?? '';
        $ends = $_POST['ends_at'] ?? '';
        if ($assetId && $starts && $ends) {
            Db::pdo()->prepare('INSERT INTO asset_reservations (id, asset_id, requester_id, starts_at, ends_at, note) VALUES (?,?,?,?,?,?)')
                ->execute([uuid(), $assetId, $user['id'], $starts, $ends, trim($_POST['note'] ?? '')]);
        }
        redirect('/members/equipment');
    }

    public static function membersBookings(): void
    {
        $user = Auth::requireMember();
        $rows = Db::pdo()->query('SELECT b.*, u.display_name FROM bookings b JOIN users u ON u.id = b.requester_id ORDER BY b.starts_at DESC')->fetchAll();
        layout('members', 'members/bookings', compact('user', 'rows'));
    }

    public static function membersBookingCreate(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $name = trim($_POST['resource_name'] ?? '');
        if ($name) {
            Db::pdo()->prepare('INSERT INTO bookings (id, resource_type, resource_name, requester_id, starts_at, ends_at, note) VALUES (?,?,?,?,?,?,?)')
                ->execute([uuid(), $_POST['resource_type'] ?? 'room', $name, $user['id'], $_POST['starts_at'], $_POST['ends_at'], trim($_POST['note'] ?? '')]);
        }
        redirect('/members/buchungen');
    }

    public static function membersFinance(): void
    {
        $user = Auth::requireMember();
        if (!Rbac::can($user['roles'], 'finance.submit') && !Rbac::can($user['roles'], 'finance.view') && !Rbac::can($user['roles'], '*')) {
            http_response_code(403);
            echo 'Keine Finanzrechte.';
            return;
        }
        $rows = Db::pdo()->query('SELECT e.*, u.display_name FROM expenses e JOIN users u ON u.id = e.submitter_id ORDER BY e.created_at DESC')->fetchAll();
        layout('members', 'members/finance', compact('user', 'rows'));
    }

    public static function membersExpenseCreate(): void
    {
        $user = Auth::requirePerm('finance.submit');
        require_csrf();
        $title = trim($_POST['title'] ?? '');
        $amount = (int) round(((float) ($_POST['amount'] ?? 0)) * 100);
        if ($title && $amount > 0) {
            Db::pdo()->prepare('INSERT INTO expenses (id, title, amount_cents, submitter_id, note) VALUES (?,?,?,?,?)')
                ->execute([uuid(), $title, $amount, $user['id'], trim($_POST['note'] ?? '')]);
        }
        redirect('/members/finanzen');
    }

    public static function membersProfile(): void
    {
        $user = Auth::requireMember();
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM profiles WHERE user_id = ?');
        $stmt->execute([$user['id']]);
        $profile = $stmt->fetch() ?: [];
        $certStmt = $db->prepare('SELECT * FROM certificates WHERE user_id = ? ORDER BY expires_at IS NULL, expires_at');
        $certStmt->execute([$user['id']]);
        $certificates = $certStmt->fetchAll();
        layout('members', 'members/profile', compact('user', 'profile', 'certificates'));
    }

    public static function membersProfileSave(): void
    {
        $user = Auth::requireMember();
        require_csrf();
        $db = Db::pdo();
        $db->prepare('UPDATE users SET display_name = ? WHERE id = ?')->execute([trim($_POST['display_name'] ?? $user['display_name']), $user['id']]);
        $fields = [
            trim($_POST['artist_name'] ?? ''),
            trim($_POST['bio'] ?? ''),
            json_encode_db(array_filter(array_map('trim', explode(',', $_POST['disciplines'] ?? '')))),
            json_encode_db(array_filter(array_map('trim', explode(',', $_POST['skills'] ?? '')))),
            trim($_POST['location'] ?? ''),
            trim($_POST['availability'] ?? ''),
            $_POST['visibility'] ?? 'members',
            !empty($_POST['public_visible']) ? 1 : 0,
            $user['id'],
        ];
        $exists = $db->prepare('SELECT id FROM profiles WHERE user_id = ?');
        $exists->execute([$user['id']]);
        if ($exists->fetchColumn()) {
            $db->prepare('UPDATE profiles SET artist_name=?, bio=?, disciplines=?, skills=?, location=?, availability=?, visibility=?, public_visible=? WHERE user_id=?')
                ->execute($fields);
        } else {
            $db->prepare('INSERT INTO profiles (id, user_id, artist_name, bio, disciplines, skills, location, availability, visibility, public_visible) VALUES (?,?,?,?,?,?,?,?,?,?)')
                ->execute([uuid(), $user['id'], $fields[0], $fields[1], $fields[2], $fields[3], $fields[4], $fields[5], $fields[6], $fields[7]]);
        }
        flash('success', 'Profil gespeichert.');
        redirect('/members/profil');
    }

    /* ---------- Team (between members & admin) ---------- */

    public static function teamDashboard(): void
    {
        $user = Auth::requireTeam();
        $db = Db::pdo();
        $open = $db->prepare("SELECT * FROM time_entries WHERE user_id = ? AND status = 'running' ORDER BY created_at DESC LIMIT 1");
        $open->execute([$user['id']]);
        $running = $open->fetch() ?: null;
        $weekStart = date('Y-m-d', strtotime('monday this week'));
        $sum = $db->prepare("SELECT COALESCE(SUM(minutes),0) FROM time_entries WHERE user_id = ? AND work_date >= ? AND status != 'rejected'");
        $sum->execute([$user['id'], $weekStart]);
        $weekMinutes = (int) $sum->fetchColumn();
        $recent = $db->prepare('SELECT t.*, p.title AS project_title FROM time_entries t LEFT JOIN projects p ON p.id = t.project_id WHERE t.user_id = ? ORDER BY t.work_date DESC, t.created_at DESC LIMIT 8');
        $recent->execute([$user['id']]);
        $entries = $recent->fetchAll();
        layout('team', 'team/dashboard', compact('user', 'running', 'weekMinutes', 'entries'));
    }

    public static function teamTime(): void
    {
        $user = Auth::requireTeam();
        $db = Db::pdo();
        $month = $_GET['month'] ?? date('Y-m');
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
            $month = date('Y-m');
        }
        $from = $month . '-01';
        $to = date('Y-m-d', strtotime($from . ' +1 month'));
        $stmt = $db->prepare(
            'SELECT t.*, p.title AS project_title FROM time_entries t
             LEFT JOIN projects p ON p.id = t.project_id
             WHERE t.user_id = ? AND t.work_date >= ? AND t.work_date < ?
             ORDER BY t.work_date DESC, t.start_time DESC'
        );
        $stmt->execute([$user['id'], $from, $to]);
        $entries = $stmt->fetchAll();
        $total = 0;
        foreach ($entries as $e) {
            if ($e['status'] !== 'rejected') {
                $total += (int) $e['minutes'];
            }
        }
        $projects = $db->query("SELECT id, title FROM projects WHERE status != 'archived' ORDER BY title")->fetchAll();
        $running = $db->prepare("SELECT * FROM time_entries WHERE user_id = ? AND status = 'running' LIMIT 1");
        $running->execute([$user['id']]);
        $running = $running->fetch() ?: null;
        $activities = $db->query('SELECT code, label FROM time_activity_types ORDER BY label')->fetchAll();
        layout('team', 'team/time', compact('user', 'entries', 'projects', 'month', 'total', 'running', 'activities'));
    }

    public static function teamTimeSave(): void
    {
        $user = Auth::requireTeam();
        require_csrf();
        $workDate = $_POST['work_date'] ?? date('Y-m-d');
        $start = $_POST['start_time'] ?? '';
        $end = $_POST['end_time'] ?? '';
        $note = trim($_POST['note'] ?? '');
        $projectId = ($_POST['project_id'] ?? '') ?: null;
        $startFull = $start ? ($workDate . ' ' . $start . ':00') : null;
        $endFull = $end ? ($workDate . ' ' . $end . ':00') : null;
        $rawMinutes = self::minutesFromRange($startFull, $endFull);
        if (!$rawMinutes && isset($_POST['hours'])) {
            $rawMinutes = (int) round(((float) $_POST['hours']) * 60);
        }
        $break = max(0, (int) ($_POST['break_minutes'] ?? 0));
        $minutes = Time::billableMinutes($rawMinutes, $break);
        if ($minutes <= 0) {
            flash('error', 'Dauer muss größer 0 sein.');
            redirect('/team/zeit');
        }
        $activity = preg_replace('/[^a-z_]/', '', strtolower((string) ($_POST['activity_type'] ?? 'orga'))) ?: 'orga';
        $night = !empty($_POST['night_flag']) || ($startFull && Time::isNight($startFull)) ? 1 : 0;
        $weekend = Time::isWeekend($workDate) ? 1 : 0;
        $id = $_POST['id'] ?? '';
        $db = Db::pdo();
        if ($id) {
            $own = $db->prepare("SELECT id, status FROM time_entries WHERE id = ? AND user_id = ?");
            $own->execute([$id, $user['id']]);
            $row = $own->fetch();
            if ($row && in_array($row['status'], ['draft', 'rejected'], true)) {
                $db->prepare('UPDATE time_entries SET project_id=?, work_date=?, start_time=?, end_time=?, minutes=?, note=?, status=?, activity_type=?, night_flag=?, weekend_flag=?, break_minutes=?, updated_at=datetime("now") WHERE id=?')
                    ->execute([$projectId, $workDate, $startFull, $endFull, $minutes, $note, 'draft', $activity, $night, $weekend, $break, $id]);
            }
        } else {
            $db->prepare('INSERT INTO time_entries (id, user_id, project_id, work_date, start_time, end_time, minutes, note, status, activity_type, night_flag, weekend_flag, break_minutes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)')
                ->execute([uuid(), $user['id'], $projectId, $workDate, $startFull, $endFull, $minutes, $note, 'draft', $activity, $night, $weekend, $break]);
        }
        flash('success', 'Zeiteintrag gespeichert.');
        redirect('/team/zeit?month=' . urlencode(substr($workDate, 0, 7)));
    }

    public static function teamTimeClock(): void
    {
        $user = Auth::requireTeam();
        require_csrf();
        $action = $_POST['action'] ?? '';
        $db = Db::pdo();
        if ($action === 'start') {
            $open = $db->prepare("SELECT id FROM time_entries WHERE user_id = ? AND status = 'running'");
            $open->execute([$user['id']]);
            if ($open->fetchColumn()) {
                flash('error', 'Es läuft bereits eine Stempeluhr.');
                redirect('/team/zeit');
            }
            $now = date('Y-m-d H:i:s');
            $db->prepare('INSERT INTO time_entries (id, user_id, project_id, work_date, start_time, minutes, note, status) VALUES (?,?,?,?,?,0,?,?)')
                ->execute([uuid(), $user['id'], ($_POST['project_id'] ?? '') ?: null, date('Y-m-d'), $now, trim($_POST['note'] ?? 'Stempeluhr'), 'running']);
            flash('success', 'Eingestempelt.');
        } elseif ($action === 'stop') {
            $open = $db->prepare("SELECT * FROM time_entries WHERE user_id = ? AND status = 'running' LIMIT 1");
            $open->execute([$user['id']]);
            $row = $open->fetch();
            if ($row) {
                $end = date('Y-m-d H:i:s');
                $mins = self::minutesFromRange($row['start_time'], $end);
                $db->prepare('UPDATE time_entries SET end_time = ?, minutes = ?, status = ?, updated_at = datetime("now") WHERE id = ?')
                    ->execute([$end, max(1, $mins), 'draft', $row['id']]);
                flash('success', 'Ausgestempelt (' . $mins . ' Min).');
            }
        }
        redirect('/team/zeit');
    }

    public static function teamTimeDelete(): void
    {
        $user = Auth::requireTeam();
        require_csrf();
        $id = $_POST['id'] ?? '';
        $db = Db::pdo();
        $db->prepare("DELETE FROM time_entries WHERE id = ? AND user_id = ? AND status IN ('draft','rejected','running')")
            ->execute([$id, $user['id']]);
        redirect('/team/zeit');
    }

    public static function teamTimeSubmit(): void
    {
        $user = Auth::requireTeam();
        require_csrf();
        $id = $_POST['id'] ?? '';
        $db = Db::pdo();
        $db->prepare("UPDATE time_entries SET status = 'submitted', updated_at = datetime('now') WHERE id = ? AND user_id = ? AND status IN ('draft','rejected')")
            ->execute([$id, $user['id']]);
        audit($db, $user['id'], 'time.submit', 'time_entry', $id);
        flash('success', 'Zur Freigabe eingereicht.');
        redirect('/team/zeit');
    }

    /* ---------- Admin ---------- */

    public static function adminDashboard(): void
    {
        $user = Auth::requireAdmin();
        $db = Db::pdo();
        $count = static function (string $sql) use ($db): int {
            return (int) $db->query($sql)->fetchColumn();
        };
        $stats = [
            ['label' => 'Mitglieder', 'value' => $count("SELECT COUNT(*) FROM memberships WHERE status = 'active'"), 'href' => '/admin/mitglieder', 'hint' => 'aktiv'],
            ['label' => 'Bewerbungen', 'value' => $count("SELECT COUNT(*) FROM applications WHERE status = 'pending'"), 'href' => '/admin/bewerbungen', 'hint' => 'offen'],
            ['label' => 'News', 'value' => $count("SELECT COUNT(*) FROM news_posts WHERE public = 1 AND status = 'published'"), 'href' => '/admin/news', 'hint' => 'live auf www'],
            ['label' => 'Events', 'value' => $count("SELECT COUNT(*) FROM events WHERE public = 1 AND status = 'published'"), 'href' => '/admin/events', 'hint' => 'öffentlich'],
            ['label' => 'Künstler', 'value' => $count('SELECT COUNT(*) FROM profiles WHERE public_visible = 1'), 'href' => '/admin/kuenstler', 'hint' => 'auf www'],
            ['label' => 'Jobs', 'value' => $count("SELECT COUNT(*) FROM job_posts WHERE status = 'open'"), 'href' => '/admin/jobs', 'hint' => 'offen'],
            ['label' => 'Zeit', 'value' => $count("SELECT COUNT(*) FROM time_entries WHERE status = 'submitted'"), 'href' => '/admin/zeit', 'hint' => 'wartet'],
            ['label' => 'Auslagen', 'value' => $count("SELECT COUNT(*) FROM expenses WHERE status = 'submitted'"), 'href' => '/admin', 'hint' => 'zur Freigabe'],
            ['label' => 'Tasks', 'value' => $count("SELECT COUNT(*) FROM tasks WHERE status != 'done'"), 'href' => '/members/kanban', 'hint' => 'nicht fertig'],
            ['label' => 'Projekte', 'value' => $count('SELECT COUNT(*) FROM projects'), 'href' => '/members/projekte', 'hint' => 'im Mitgliederbereich'],
        ];
        $applications = $db->query("SELECT * FROM applications WHERE status = 'pending' ORDER BY created_at DESC LIMIT 6")->fetchAll();
        $times = $db->query(
            "SELECT t.*, u.display_name, p.title AS project_title
             FROM time_entries t
             JOIN users u ON u.id = t.user_id
             LEFT JOIN projects p ON p.id = t.project_id
             WHERE t.status = 'submitted'
             ORDER BY t.work_date DESC LIMIT 6"
        )->fetchAll();
        $expenses = $db->query(
            "SELECT e.*, u.display_name FROM expenses e
             JOIN users u ON u.id = e.submitter_id
             WHERE e.status = 'submitted' ORDER BY e.created_at DESC LIMIT 6"
        )->fetchAll();
        $reservations = $db->query(
            "SELECT r.*, a.name AS asset_name, u.display_name
             FROM asset_reservations r
             JOIN assets a ON a.id = r.asset_id
             JOIN users u ON u.id = r.requester_id
             WHERE r.status = 'requested' ORDER BY r.created_at DESC LIMIT 6"
        )->fetchAll();
        $news = $db->query('SELECT * FROM news_posts ORDER BY created_at DESC LIMIT 4')->fetchAll();
        $events = $db->query(
            "SELECT e.*, p.id AS linked_project_id, p.title AS project_title FROM events e
             LEFT JOIN projects p ON p.id = e.project_id OR (e.project_id IS NULL AND p.event_id = e.id)
             ORDER BY COALESCE(e.starts_at, e.created_at) DESC LIMIT 4"
        )->fetchAll();
        $activity = $db->query(
            'SELECT a.*, u.display_name FROM audit_logs a
             LEFT JOIN users u ON u.id = a.actor_id
             ORDER BY a.created_at DESC LIMIT 8'
        )->fetchAll();
        $attention = count($applications) + count($times) + count($expenses) + count($reservations);
        layout('admin', 'admin/dashboard', compact(
            'user',
            'stats',
            'applications',
            'times',
            'expenses',
            'reservations',
            'news',
            'events',
            'activity',
            'attention'
        ));
    }

    public static function adminTime(): void
    {
        $user = Auth::requirePerm('time.view_all');
        $db = Db::pdo();
        $rows = $db->query(
            "SELECT t.*, u.display_name, p.title AS project_title
             FROM time_entries t
             JOIN users u ON u.id = t.user_id
             LEFT JOIN projects p ON p.id = t.project_id
             ORDER BY CASE t.status WHEN 'submitted' THEN 0 WHEN 'running' THEN 1 ELSE 2 END, t.work_date DESC
             LIMIT 200"
        )->fetchAll();
        layout('admin', 'admin/time', compact('user', 'rows'));
    }

    public static function adminTimeDecide(): void
    {
        $user = Auth::requirePerm('time.approve');
        require_csrf();
        $id = $_POST['id'] ?? '';
        $status = $_POST['status'] ?? '';
        if (in_array($status, ['approved', 'rejected'], true)) {
            Db::pdo()->prepare("UPDATE time_entries SET status = ?, updated_at = datetime('now') WHERE id = ? AND status = 'submitted'")
                ->execute([$status, $id]);
            audit(Db::pdo(), $user['id'], 'time.' . $status, 'time_entry', $id);
        }
        redirect(admin_return('/admin/zeit'));
    }

    public static function adminMembers(): void
    {
        $user = Auth::requirePerm('members.manage');
        $db = Db::pdo();
        $q = trim($_GET['q'] ?? '');
        $filter = $_GET['status'] ?? '';
        $sql = 'SELECT u.*, m.status AS membership_status, GROUP_CONCAT(r.role) AS roles
                FROM users u
                LEFT JOIN memberships m ON m.user_id = u.id
                LEFT JOIN role_assignments r ON r.user_id = u.id
                WHERE 1=1';
        $params = [];
        if ($q !== '') {
            $sql .= ' AND (u.email LIKE ? OR u.display_name LIKE ?)';
            $params[] = '%' . $q . '%';
            $params[] = '%' . $q . '%';
        }
        if ($filter !== '' && in_array($filter, ['active', 'invited', 'pending', 'inactive', 'suspended', 'former'], true)) {
            $sql .= ' AND m.status = ?';
            $params[] = $filter;
        }
        $sql .= ' GROUP BY u.id ORDER BY u.display_name';
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        $edit = null;
        $editRoles = [];
        if (!empty($_GET['id'])) {
            $s = $db->prepare('SELECT u.*, m.status AS membership_status FROM users u LEFT JOIN memberships m ON m.user_id = u.id WHERE u.id = ?');
            $s->execute([$_GET['id']]);
            $edit = $s->fetch() ?: null;
            if ($edit) {
                $rr = $db->prepare('SELECT role FROM role_assignments WHERE user_id = ?');
                $rr->execute([$edit['id']]);
                $editRoles = array_column($rr->fetchAll(), 'role');
            }
        }

        $roleOptions = Rbac::roleOptions();
        $statusOptions = ['invited', 'pending', 'active', 'inactive', 'suspended', 'former'];
        layout('admin', 'admin/members', compact('user', 'rows', 'edit', 'editRoles', 'roleOptions', 'statusOptions', 'q', 'filter'));
    }

    public static function adminMemberSave(): void
    {
        $actor = Auth::requirePerm('members.manage');
        require_csrf();
        $id = $_POST['id'] ?? '';
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM users WHERE id = ?');
        $stmt->execute([$id]);
        $target = $stmt->fetch();
        if (!$target) {
            flash('error', 'Nutzer nicht gefunden.');
            redirect('/admin/mitglieder');
        }

        $display = trim($_POST['display_name'] ?? $target['display_name']);
        $email = strtolower(trim($_POST['email'] ?? $target['email']));
        $active = !empty($_POST['is_active']) ? 1 : 0;
        $membership = $_POST['membership_status'] ?? 'active';
        if (!in_array($membership, ['invited', 'pending', 'active', 'inactive', 'suspended', 'former'], true)) {
            $membership = 'active';
        }
        $roles = $_POST['roles'] ?? [];
        if (!is_array($roles)) {
            $roles = [];
        }
        $allowed = Rbac::roleOptions();
        $roles = array_values(array_intersect($roles, $allowed));
        if (!$roles) {
            $roles = ['member'];
        }

        // Prevent locking yourself out of admin
        if ($id === $actor['id'] && !in_array('admin', $roles, true) && !in_array('superadmin', $roles, true)) {
            flash('error', 'Du kannst dir Admin-Rechte nicht selbst entziehen.');
            redirect('/admin/mitglieder?id=' . urlencode($id));
        }

        $db->prepare('UPDATE users SET display_name = ?, email = ?, is_active = ?, updated_at = datetime("now") WHERE id = ?')
            ->execute([$display, $email, $active, $id]);

        $mem = $db->prepare('SELECT id FROM memberships WHERE user_id = ?');
        $mem->execute([$id]);
        $memId = $mem->fetchColumn();
        if ($memId) {
            if ($membership === 'active') {
                $db->prepare('UPDATE memberships SET status = ?, joined_at = COALESCE(joined_at, datetime("now")) WHERE user_id = ?')
                    ->execute([$membership, $id]);
            } else {
                $db->prepare('UPDATE memberships SET status = ? WHERE user_id = ?')->execute([$membership, $id]);
            }
        } else {
            $db->prepare('INSERT INTO memberships (id, user_id, status, joined_at) VALUES (?,?,?,?)')
                ->execute([uuid(), $id, $membership, $membership === 'active' ? date('Y-m-d H:i:s') : null]);
        }

        $db->prepare('DELETE FROM role_assignments WHERE user_id = ?')->execute([$id]);
        foreach ($roles as $role) {
            $db->prepare('INSERT INTO role_assignments (id, user_id, role) VALUES (?,?,?)')->execute([uuid(), $id, $role]);
        }

        // Ensure profile exists
        $p = $db->prepare('SELECT id FROM profiles WHERE user_id = ?');
        $p->execute([$id]);
        if (!$p->fetchColumn()) {
            $db->prepare('INSERT INTO profiles (id, user_id, artist_name) VALUES (?,?,?)')
                ->execute([uuid(), $id, $display]);
        }

        audit($db, $actor['id'], 'member.update', 'user', $id, [
            'roles' => $roles,
            'membership' => $membership,
            'active' => $active,
        ]);
        flash('success', 'Mitglied gespeichert.');
        redirect('/admin/mitglieder?id=' . urlencode($id));
    }

    public static function adminMemberCreate(): void
    {
        $actor = Auth::requirePerm('members.manage');
        require_csrf();
        $email = strtolower(trim($_POST['email'] ?? ''));
        $display = trim($_POST['display_name'] ?? '');
        $password = $_POST['password'] ?? '';
        $roles = $_POST['roles'] ?? ['member'];
        if (!is_array($roles)) {
            $roles = array_filter(array_map('trim', explode(',', (string) $roles)));
        }
        $allowed = Rbac::roleOptions();
        $roles = array_values(array_intersect($roles, $allowed)) ?: ['member'];

        if ($email === '' || strlen($password) < 8) {
            flash('error', 'E-Mail und Passwort (min. 8) sind Pflicht.');
            redirect('/admin/mitglieder');
        }

        $db = Db::pdo();
        $exists = $db->prepare('SELECT id FROM users WHERE email = ?');
        $exists->execute([$email]);
        if ($exists->fetchColumn()) {
            flash('error', 'E-Mail existiert bereits.');
            redirect('/admin/mitglieder');
        }

        $id = uuid();
        $db->prepare('INSERT INTO users (id, email, display_name, password_hash, is_active) VALUES (?,?,?,?,1)')
            ->execute([$id, $email, $display ?: $email, password_hash($password, PASSWORD_DEFAULT)]);
        $db->prepare('INSERT INTO memberships (id, user_id, status, joined_at) VALUES (?,?,?,datetime("now"))')
            ->execute([uuid(), $id, 'active']);
        $db->prepare('INSERT INTO profiles (id, user_id, artist_name) VALUES (?,?,?)')
            ->execute([uuid(), $id, $display ?: $email]);
        foreach ($roles as $role) {
            $db->prepare('INSERT INTO role_assignments (id, user_id, role) VALUES (?,?,?)')->execute([uuid(), $id, $role]);
        }
        audit($db, $actor['id'], 'member.create', 'user', $id, ['email' => $email, 'roles' => $roles]);
        flash('success', 'Mitglied angelegt.');
        redirect('/admin/mitglieder?id=' . urlencode($id));
    }

    public static function adminMemberPassword(): void
    {
        $actor = Auth::requirePerm('members.manage');
        require_csrf();
        $id = $_POST['id'] ?? '';
        $password = $_POST['password'] ?? '';
        if (strlen($password) < 8) {
            flash('error', 'Passwort mind. 8 Zeichen.');
            redirect('/admin/mitglieder?id=' . urlencode($id));
        }
        $db = Db::pdo();
        $db->prepare('UPDATE users SET password_hash = ?, updated_at = datetime("now") WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $id]);
        audit($db, $actor['id'], 'member.password_reset', 'user', $id);
        flash('success', 'Passwort gesetzt.');
        redirect('/admin/mitglieder?id=' . urlencode($id));
    }

    public static function adminInvites(): void
    {
        $user = Auth::requireAdmin();
        $rows = Db::pdo()->query('SELECT * FROM invites ORDER BY created_at DESC')->fetchAll();
        layout('admin', 'admin/invites', compact('user', 'rows'));
    }

    public static function adminInviteCreate(): void
    {
        $user = Auth::requirePerm('members.invite');
        require_csrf();
        $email = strtolower(trim($_POST['email'] ?? ''));
        $roles = array_values(array_filter(array_map('trim', explode(',', $_POST['roles'] ?? 'member'))));
        if ($email) {
            $token = bin2hex(random_bytes(16));
            $id = uuid();
            Db::pdo()->prepare('INSERT INTO invites (id, email, token, roles, invited_by_id, expires_at) VALUES (?,?,?,?,?,datetime("now","+14 days"))')
                ->execute([$id, $email, $token, json_encode_db($roles ?: ['member']), $user['id']]);
            audit(Db::pdo(), $user['id'], 'invite.create', 'invite', $id, ['email' => $email]);
            flash('success', 'Invite erstellt. Link: /invite?token=' . $token);
        }
        redirect('/admin/invites');
    }

    public static function adminApplications(): void
    {
        $user = Auth::requireAdmin();
        $rows = Db::pdo()->query('SELECT * FROM applications ORDER BY created_at DESC')->fetchAll();
        layout('admin', 'admin/applications', compact('user', 'rows'));
    }

    public static function adminApplicationDecide(): void
    {
        $actor = Actor::requirePerm('applications.decide');
        require_csrf();
        $id = (string) ($_POST['id'] ?? '');
        $decision = (string) ($_POST['decision'] ?? '');
        $note = trim((string) ($_POST['note'] ?? ''));
        try {
            $result = (new DecideApplication(Db::pdo()))->decide($actor, $id, $decision, $note);
            if ($result['invite_token'] !== null) {
                flash('success', 'Akzeptiert. Invite: /invite?token=' . $result['invite_token']);
            } else {
                flash('success', 'Bewerbung entschieden.');
            }
        } catch (ApprovalValidation $e) {
            flash('error', $e->getMessage());
        } catch (ApprovalNotFound $e) {
            http_response_code(404);
            echo 'Bewerbung nicht gefunden.';
            exit;
        } catch (ApprovalForbidden $e) {
            http_response_code(403);
            echo e($e->getMessage());
            exit;
        } catch (ApprovalConflict $e) {
            http_response_code(409);
            echo e($e->getMessage());
            exit;
        }
        redirect(admin_return('/admin/bewerbungen'));
    }

    public static function adminContentHub(): void
    {
        $user = Auth::requireAdmin();
        $db = Db::pdo();
        $cards = [
            ['href' => '/admin/cms', 'preview' => '/', 'label' => 'Seiten', 'text' => 'Home und CMS-Blöcke', 'value' => (int) $db->query('SELECT COUNT(*) FROM pages')->fetchColumn()],
            ['href' => '/admin/news', 'preview' => '/news', 'label' => 'News', 'text' => 'Aktuelles auf der Website', 'value' => (int) $db->query('SELECT COUNT(*) FROM news_posts')->fetchColumn()],
            ['href' => '/admin/events', 'preview' => '/events', 'label' => 'Events', 'text' => 'Öffentlich und intern', 'value' => (int) $db->query('SELECT COUNT(*) FROM events')->fetchColumn()],
            ['href' => '/admin/kuenstler', 'preview' => '/artists', 'label' => 'Künstler', 'text' => 'Profile auf www', 'value' => (int) $db->query('SELECT COUNT(*) FROM profiles WHERE public_visible = 1')->fetchColumn()],
            ['href' => '/admin/jobs', 'preview' => '/members/jobs', 'label' => 'Jobbörse', 'text' => 'Offene Angebote und Gesuche', 'value' => (int) $db->query("SELECT COUNT(*) FROM job_posts WHERE status = 'open'")->fetchColumn()],
            ['href' => '/admin/medien', 'preview' => '/members/mediathek', 'label' => 'Medien', 'text' => 'Uploads und Freigabe', 'value' => (int) $db->query('SELECT COUNT(*) FROM media_assets')->fetchColumn()],
        ];
        layout('admin', 'admin/content', compact('user', 'cards'));
    }

    public static function adminCms(): void
    {
        $user = Auth::requireAdmin();
        $pages = Db::pdo()->query('SELECT * FROM pages ORDER BY slug')->fetchAll();
        $edit = null;
        if (!empty($_GET['slug'])) {
            $stmt = Db::pdo()->prepare('SELECT * FROM pages WHERE slug = ?');
            $stmt->execute([$_GET['slug']]);
            $edit = $stmt->fetch() ?: null;
        } elseif ($pages) {
            $edit = $pages[0];
        }
        $blocks = $edit ? json_decode_db($edit['blocks'] ?? '[]') : [];
        layout('admin', 'admin/cms', compact('user', 'pages', 'edit', 'blocks'));
    }

    public static function adminCmsSave(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $slug = trim($_POST['slug'] ?? '');
        $title = trim($_POST['title'] ?? '');
        $status = $_POST['status'] ?? 'draft';
        if (!in_array($status, ['draft', 'published'], true)) {
            $status = 'draft';
        }

        // Prefer structured form fields; fall back to JSON
        if (!empty($_POST['use_structured'])) {
            $blocks = [];
            $types = $_POST['block_type'] ?? [];
            $eyebrows = $_POST['block_eyebrow'] ?? [];
            $headlines = $_POST['block_headline'] ?? [];
            $bodies = $_POST['block_body'] ?? [];
            $labels = $_POST['block_label'] ?? [];
            $hrefs = $_POST['block_href'] ?? [];
            foreach ($types as $i => $type) {
                $type = (string) $type;
                if ($type === 'hero') {
                    $blocks[] = [
                        'type' => 'hero',
                        'eyebrow' => trim((string) ($eyebrows[$i] ?? '')),
                        'headline' => trim((string) ($headlines[$i] ?? '')),
                    ];
                } elseif ($type === 'richtext') {
                    $blocks[] = [
                        'type' => 'richtext',
                        'body' => trim((string) ($bodies[$i] ?? '')),
                    ];
                } elseif ($type === 'cta') {
                    $blocks[] = [
                        'type' => 'cta',
                        'label' => trim((string) ($labels[$i] ?? 'Mehr')),
                        'href' => trim((string) ($hrefs[$i] ?? '/')),
                    ];
                }
            }
        } else {
            $blocksRaw = $_POST['blocks_json'] ?? '[]';
            $blocks = json_decode($blocksRaw, true);
            if (!is_array($blocks)) {
                flash('error', 'Ungültiges Blocks-JSON');
                redirect('/admin/cms');
            }
        }

        $db = Db::pdo();
        $exists = $db->prepare('SELECT id FROM pages WHERE slug = ?');
        $exists->execute([$slug]);
        $rowId = $exists->fetchColumn();
        if ($rowId) {
            $db->prepare('UPDATE pages SET title = ?, status = ?, blocks = ?, version = version + 1, updated_at = datetime("now") WHERE id = ?')
                ->execute([$title, $status, json_encode_db($blocks), $rowId]);
            $id = (string) $rowId;
        } else {
            $id = uuid();
            $db->prepare('INSERT INTO pages (id, slug, title, status, blocks) VALUES (?,?,?,?,?)')
                ->execute([$id, $slug, $title, $status, json_encode_db($blocks)]);
        }
        audit($db, $user['id'], 'cms.save', 'page', $id, ['status' => $status]);
        flash('success', 'Seite gespeichert.');
        redirect('/admin/cms?slug=' . urlencode($slug));
    }

    public static function adminCmsDelete(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $slug = $_POST['slug'] ?? '';
        if ($slug === 'home') {
            flash('error', 'Home-Seite kann nicht gelöscht werden.');
            redirect('/admin/cms?slug=home');
        }
        $db = Db::pdo();
        $db->prepare('DELETE FROM pages WHERE slug = ?')->execute([$slug]);
        audit($db, $user['id'], 'cms.delete', 'page', $slug);
        flash('success', 'Seite gelöscht.');
        redirect('/admin/cms');
    }

    public static function adminNews(): void
    {
        $user = Auth::requireAdmin();
        $rows = Db::pdo()->query('SELECT * FROM news_posts ORDER BY created_at DESC')->fetchAll();
        $edit = null;
        if (!empty($_GET['id'])) {
            $s = Db::pdo()->prepare('SELECT * FROM news_posts WHERE id = ?');
            $s->execute([$_GET['id']]);
            $edit = $s->fetch() ?: null;
        }
        layout('admin', 'admin/news', compact('user', 'rows', 'edit'));
    }

    public static function adminNewsSave(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $id = $_POST['id'] ?? '';
        $title = trim($_POST['title'] ?? '');
        $body = trim($_POST['body'] ?? '');
        $status = $_POST['status'] ?? 'draft';
        $public = !empty($_POST['public']) ? 1 : 0;
        if ($title === '') {
            flash('error', 'Titel fehlt.');
            redirect('/admin/news');
        }
        $db = Db::pdo();
        if ($id) {
            $db->prepare('UPDATE news_posts SET title=?, body=?, status=?, public=? WHERE id=?')
                ->execute([$title, $body, $status, $public, $id]);
        } else {
            $id = uuid();
            $db->prepare('INSERT INTO news_posts (id, title, body, status, public) VALUES (?,?,?,?,?)')
                ->execute([$id, $title, $body, $status, $public]);
        }
        audit($db, $user['id'], 'news.save', 'news', $id);
        flash('success', 'News gespeichert.');
        redirect('/admin/news?id=' . urlencode($id));
    }

    public static function adminNewsDelete(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $id = $_POST['id'] ?? '';
        Db::pdo()->prepare('DELETE FROM news_posts WHERE id = ?')->execute([$id]);
        audit(Db::pdo(), $user['id'], 'news.delete', 'news', $id);
        flash('success', 'News gelöscht.');
        redirect('/admin/news');
    }

    public static function adminEvents(): void
    {
        $user = Auth::requireAdmin();
        $rows = Db::pdo()->query(
            'SELECT e.*, p.id AS linked_project_id, p.title AS project_title FROM events e LEFT JOIN projects p ON p.id = e.project_id OR (e.project_id IS NULL AND p.event_id = e.id) ORDER BY COALESCE(e.starts_at, e.created_at) DESC'
        )->fetchAll();
        $edit = null;
        if (!empty($_GET['id'])) {
            $s = Db::pdo()->prepare(
                'SELECT e.*, p.id AS linked_project_id, p.title AS project_title FROM events e LEFT JOIN projects p ON p.id = e.project_id OR (e.project_id IS NULL AND p.event_id = e.id) WHERE e.id = ?'
            );
            $s->execute([$_GET['id']]);
            $edit = $s->fetch() ?: null;
        }
        layout('admin', 'admin/events', compact('user', 'rows', 'edit'));
    }

    public static function adminEventsSave(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $id = $_POST['id'] ?? '';
        $title = trim($_POST['title'] ?? '');
        if ($title === '') {
            flash('error', 'Titel fehlt.');
            redirect('/admin/events');
        }
        $fields = [
            $title,
            trim($_POST['description'] ?? ''),
            trim($_POST['venue'] ?? ''),
            ($_POST['starts_at'] ?? '') !== '' ? str_replace('T', ' ', $_POST['starts_at']) : null,
            ($_POST['ends_at'] ?? '') !== '' ? str_replace('T', ' ', $_POST['ends_at']) : null,
            $_POST['status'] ?? 'draft',
            !empty($_POST['public']) ? 1 : 0,
        ];
        $db = Db::pdo();
        if ($id) {
            $db->prepare('UPDATE events SET title=?, description=?, venue=?, starts_at=?, ends_at=?, status=?, public=? WHERE id=?')
                ->execute([...$fields, $id]);
        } else {
            $id = uuid();
            $db->prepare('INSERT INTO events (id, title, description, venue, starts_at, ends_at, status, public) VALUES (?,?,?,?,?,?,?,?)')
                ->execute([$id, ...$fields]);
            Automations::fire('event.created', ['event_id' => $id, 'title' => $title]);
        }
        audit($db, $user['id'], 'event.save', 'event', $id);
        flash('success', 'Event gespeichert.');
        redirect('/admin/events?id=' . urlencode($id));
    }

    public static function adminEventsDelete(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $id = $_POST['id'] ?? '';
        Db::pdo()->prepare('DELETE FROM events WHERE id = ?')->execute([$id]);
        audit(Db::pdo(), $user['id'], 'event.delete', 'event', $id);
        redirect('/admin/events');
    }

    public static function adminArtists(): void
    {
        $user = Auth::requireAdmin();
        $rows = Db::pdo()->query(
            'SELECT p.*, u.display_name, u.email FROM profiles p JOIN users u ON u.id = p.user_id ORDER BY p.artist_name, u.display_name'
        )->fetchAll();
        $edit = null;
        if (!empty($_GET['id'])) {
            $s = Db::pdo()->prepare(
                'SELECT p.*, u.display_name, u.email FROM profiles p JOIN users u ON u.id = p.user_id WHERE p.id = ?'
            );
            $s->execute([$_GET['id']]);
            $edit = $s->fetch() ?: null;
        }
        layout('admin', 'admin/artists', compact('user', 'rows', 'edit'));
    }

    public static function adminArtistsSave(): void
    {
        $user = Auth::requirePerm('cms.publish');
        require_csrf();
        $id = $_POST['id'] ?? '';
        $db = Db::pdo();
        $db->prepare(
            'UPDATE profiles SET artist_name=?, bio=?, disciplines=?, location=?, visibility=?, public_visible=? WHERE id=?'
        )->execute([
            trim($_POST['artist_name'] ?? ''),
            trim($_POST['bio'] ?? ''),
            json_encode_db(array_values(array_filter(array_map('trim', explode(',', $_POST['disciplines'] ?? ''))))),
            trim($_POST['location'] ?? ''),
            $_POST['visibility'] ?? 'members',
            !empty($_POST['public_visible']) ? 1 : 0,
            $id,
        ]);
        audit($db, $user['id'], 'artist.save', 'profile', $id);
        flash('success', 'Künstlerprofil gespeichert.');
        redirect('/admin/kuenstler?id=' . urlencode($id));
    }

    public static function adminJobs(): void
    {
        $user = Auth::requireAdmin();
        $rows = Db::pdo()->query(
            'SELECT j.*, u.display_name FROM job_posts j JOIN users u ON u.id = j.author_id ORDER BY j.created_at DESC'
        )->fetchAll();
        layout('admin', 'admin/jobs', compact('user', 'rows'));
    }

    public static function adminJobsStatus(): void
    {
        $user = Auth::requireAdmin();
        require_csrf();
        $id = $_POST['id'] ?? '';
        $status = $_POST['status'] ?? 'closed';
        if (!in_array($status, ['open', 'filled', 'closed'], true)) {
            $status = 'closed';
        }
        Db::pdo()->prepare('UPDATE job_posts SET status = ?, updated_at = datetime("now") WHERE id = ?')->execute([$status, $id]);
        audit(Db::pdo(), $user['id'], 'job.status', 'job_post', $id, ['status' => $status]);
        redirect('/admin/jobs');
    }

    public static function adminJobsDelete(): void
    {
        $user = Auth::requireAdmin();
        require_csrf();
        $id = $_POST['id'] ?? '';
        Db::pdo()->prepare('DELETE FROM job_posts WHERE id = ?')->execute([$id]);
        audit(Db::pdo(), $user['id'], 'job.delete', 'job_post', $id);
        redirect('/admin/jobs');
    }

    public static function adminMedia(): void
    {
        $user = Auth::requireAdmin();
        $rows = Db::pdo()->query('SELECT * FROM media_assets ORDER BY created_at DESC')->fetchAll();
        layout('admin', 'admin/media', compact('user', 'rows'));
    }

    public static function adminMediaUpload(): void
    {
        $user = Auth::requirePerm('media.manage');
        require_csrf();
        self::handleUpload($user['id'], $_POST['acl'] ?? 'members');
        redirect('/admin/medien');
    }

    public static function adminMediaDelete(): void
    {
        $user = Auth::requirePerm('media.manage');
        require_csrf();
        $id = $_POST['id'] ?? '';
        $db = Db::pdo();
        $stmt = $db->prepare('SELECT * FROM media_assets WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if ($row) {
            $path = (string) $row['path'];
            $file = Config::get('upload_dir') . '/' . basename($path);
            if (is_file($file)) {
                @unlink($file);
            }
            $db->prepare('DELETE FROM media_assets WHERE id = ?')->execute([$id]);
            audit($db, $user['id'], 'media.delete', 'media', $id);
        }
        redirect('/admin/medien');
    }

    public static function adminAutomations(): void
    {
        $user = Auth::requireAdmin();
        $db = Db::pdo();
        $rules = $db->query('SELECT * FROM automation_rules')->fetchAll();
        $runs = $db->query('SELECT * FROM automation_runs ORDER BY created_at DESC LIMIT 50')->fetchAll();
        layout('admin', 'admin/automations', compact('user', 'rules', 'runs'));
    }

    public static function adminAudit(): void
    {
        $user = Auth::requirePerm('audit.read');
        $rows = Db::pdo()->query('SELECT a.*, u.display_name FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_id ORDER BY a.created_at DESC LIMIT 200')->fetchAll();
        layout('admin', 'admin/audit', compact('user', 'rows'));
    }

    public static function adminEquipmentApprove(): void
    {
        $actor = Actor::requirePerm('equipment.approve');
        require_csrf();
        $id = (string) ($_POST['id'] ?? '');
        $status = (string) ($_POST['status'] ?? '');
        $note = trim((string) ($_POST['note'] ?? ''));
        self::equipmentAction(
            static fn () => (new ReservationWorkflow(Db::pdo()))->decide($actor, $id, $status, $note),
            'Reservierung entschieden.'
        );
    }

    public static function adminEquipmentCheckout(): void
    {
        $actor = Actor::requirePerm('equipment.approve');
        require_csrf();
        $id = (string) ($_POST['id'] ?? '');
        self::equipmentAction(
            static fn () => (new ReservationWorkflow(Db::pdo()))->checkout($actor, $id),
            'Ausgabe quittiert.'
        );
    }

    public static function adminEquipmentReturn(): void
    {
        $actor = Actor::requirePerm('equipment.approve');
        require_csrf();
        $id = (string) ($_POST['id'] ?? '');
        self::equipmentAction(
            static fn () => (new ReservationWorkflow(Db::pdo()))->markReturned($actor, $id),
            'Rückgabe quittiert.'
        );
    }

    /** Einheitliche Fehlerabbildung der Equipment-Workflow-Ausnahmen auf HTTP. */
    private static function equipmentAction(callable $action, string $success): void
    {
        try {
            $action();
            flash('success', $success);
        } catch (ApprovalValidation $e) {
            flash('error', $e->getMessage());
        } catch (ApprovalNotFound $e) {
            http_response_code(404);
            echo 'Reservierung nicht gefunden.';
            exit;
        } catch (ApprovalForbidden $e) {
            http_response_code(403);
            echo e($e->getMessage());
            exit;
        } catch (ApprovalConflict $e) {
            http_response_code(409);
            echo e($e->getMessage());
            exit;
        }
        redirect(admin_return('/members/equipment'));
    }

    public static function adminExpenseDecide(): void
    {
        $actor = Actor::requirePerm('finance.approve');
        require_csrf();
        $id = (string) ($_POST['id'] ?? '');
        $status = (string) ($_POST['status'] ?? '');
        $note = trim((string) ($_POST['note'] ?? ''));
        try {
            (new DecideExpense(Db::pdo()))->decide($actor, $id, $status, $note);
            flash('success', 'Auslage entschieden.');
        } catch (ApprovalValidation $e) {
            // Fachlicher Formularfehler (z. B. fehlende Ablehnungsbegründung).
            flash('error', $e->getMessage());
        } catch (ApprovalNotFound $e) {
            http_response_code(404);
            echo 'Auslage nicht gefunden.';
            exit;
        } catch (ApprovalForbidden $e) {
            http_response_code(403);
            echo e($e->getMessage());
            exit;
        } catch (ApprovalConflict $e) {
            http_response_code(409);
            echo e($e->getMessage());
            exit;
        }
        redirect(admin_return('/members/finanzen'));
    }

    /* ---------- Objekt-Loader für Policy-Prüfungen (Phase 1) ---------- */

    /** @return array<string, mixed>|null */
    private static function findTask(PDO $db, string $taskId): ?array
    {
        if ($taskId === '') {
            return null;
        }
        $stmt = $db->prepare('SELECT * FROM tasks WHERE id = ?');
        $stmt->execute([$taskId]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    /** @return array<string, mixed>|null */
    private static function findProject(PDO $db, string $projectId): ?array
    {
        if ($projectId === '') {
            return null;
        }
        $stmt = $db->prepare('SELECT * FROM projects WHERE id = ?');
        $stmt->execute([$projectId]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    /**
     * Projekt einer Aufgabe laden; null bei Aufgaben ohne Projektbezug
     * (solche Aufgaben darf laut ProjectPolicy nur 'projects.manage'/'*' bearbeiten).
     *
     * @param array<string, mixed> $task
     * @return array<string, mixed>|null
     */
    private static function findProjectForTask(PDO $db, array $task): ?array
    {
        $projectId = (string) ($task['project_id'] ?? '');
        if ($projectId === '') {
            return null;
        }
        return self::findProject($db, $projectId);
    }

    /** @return array<string, mixed>|null */
    private static function findChannel(PDO $db, string $channelId): ?array
    {
        if ($channelId === '') {
            return null;
        }
        $stmt = $db->prepare('SELECT * FROM channels WHERE id = ?');
        $stmt->execute([$channelId]);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    /** Fehlerantwort für Task-Endpunkte — als JSON, wenn der Client AJAX angefragt hat. */
    private static function taskGateFail(int $code, string $message): never
    {
        http_response_code($code);
        if (!empty($_POST['ajax'])) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => $code === 404 ? 'not_found' : 'forbidden']);
            exit;
        }
        echo $message;
        exit;
    }

    private static function handleUpload(string $uploaderId, string $acl): void
    {
        if (empty($_FILES['file']['tmp_name']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
            flash('error', 'Kein Upload.');
            return;
        }
        $dir = Config::get('upload_dir');
        if (!is_dir($dir)) {
            mkdir($dir, 0775, true);
        }
        $orig = basename((string) $_FILES['file']['name']);
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'txt', 'md', 'zip'];
        if (!in_array($ext, $allowed, true)) {
            flash('error', 'Dateityp nicht erlaubt.');
            return;
        }
        $safe = bin2hex(random_bytes(8)) . '.' . $ext;
        $dest = rtrim($dir, '/') . '/' . $safe;
        if (!move_uploaded_file($_FILES['file']['tmp_name'], $dest)) {
            flash('error', 'Upload fehlgeschlagen.');
            return;
        }
        // Prevent PHP execution in uploads
        @chmod($dest, 0644);
        $mime = mime_content_type($dest) ?: 'application/octet-stream';
        $urlPath = rtrim((string) Config::get('upload_url', '/uploads'), '/') . '/' . $safe;
        Db::pdo()->prepare('INSERT INTO media_assets (id, filename, path, mime, size, uploader_id, acl) VALUES (?,?,?,?,?,?,?)')
            ->execute([uuid(), $orig, $urlPath, $mime, (int) ($_FILES['file']['size'] ?? 0), $uploaderId, $acl]);
        flash('success', 'Upload OK.');
    }
}
