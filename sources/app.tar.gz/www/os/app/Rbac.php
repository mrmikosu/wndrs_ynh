<?php
declare(strict_types=1);

final class Rbac
{
    /** @var array<string, list<string>> */
    private const MAP = [
        'superadmin' => ['*'],
        'admin' => [
            'admin.access', 'members.invite', 'members.manage', 'cms.publish',
            'media.manage', 'applications.decide', 'equipment.approve',
            'finance.approve', 'finance.view_all', 'audit.read', 'automations.manage',
            'team.access', 'time.track', 'time.view_own', 'time.view_all', 'time.approve',
            'projects.manage', 'projects.budget', 'jobs.moderate', 'impersonate',
            'settings.manage', 'notifications.admin',
        ],
        'project_lead' => [
            'team.access', 'time.track', 'time.view_own', 'time.view_project',
            'projects.read', 'projects.task', 'projects.lead', 'projects.budget',
            'events.read', 'events.plan', 'jobs.write', 'jobs.moderate',
            'members.read', 'channels.write', 'wiki.write', 'board.write',
            'equipment.request', 'bookings.request', 'polls.vote', 'finance.submit',
            'profile.edit', 'media.upload',
        ],
        'team' => [
            'team.access', 'time.track', 'time.view_own',
            'members.read', 'channels.write', 'projects.read', 'projects.task',
            'events.read', 'events.shift_respond', 'wiki.write', 'board.write',
            'jobs.write', 'jobs.apply', 'media.upload',
            'equipment.request', 'bookings.request', 'polls.vote', 'finance.submit',
            'profile.edit',
        ],
        'freelance' => [
            'time.track', 'time.view_own', 'members.read', 'projects.read', 'projects.task',
            'events.read', 'events.shift_respond', 'jobs.apply', 'jobs.write',
            'wiki.write', 'board.write', 'media.upload', 'equipment.request',
            'bookings.request', 'polls.vote', 'finance.submit', 'profile.edit',
        ],
        'volunteer' => [
            'members.read', 'projects.read', 'events.read', 'events.shift_respond',
            'jobs.apply', 'board.write', 'polls.vote', 'profile.edit', 'time.track', 'time.view_own',
        ],
        'guest' => [
            'projects.read_limited', 'events.read_assigned', 'profile.edit',
        ],
        'finance' => ['finance.view', 'finance.submit', 'finance.approve', 'finance.view_all'],
        'member' => [
            'members.read', 'channels.write', 'projects.read', 'projects.task',
            'events.read', 'events.shift_respond', 'wiki.write', 'board.write',
            'jobs.write', 'jobs.apply', 'media.upload',
            'equipment.request', 'bookings.request', 'polls.vote', 'finance.submit',
            'profile.edit', 'time.track', 'time.view_own',
        ],
    ];

    /** Project-scoped roles */
    private const PROJECT_MAP = [
        'lead' => ['projects.lead', 'projects.task', 'projects.budget', 'projects.read', 'events.plan'],
        'contributor' => ['projects.task', 'projects.read', 'events.read'],
        'viewer' => ['projects.read'],
    ];

    /** @param list<string> $roles */
    public static function permissions(array $roles): array
    {
        $perms = [];
        foreach ($roles as $role) {
            foreach (self::MAP[$role] ?? [] as $p) {
                $perms[$p] = true;
            }
        }
        return array_keys($perms);
    }

    /** @param list<string> $roles */
    public static function can(array $roles, string $permission): bool
    {
        $perms = self::permissions($roles);
        return in_array('*', $perms, true) || in_array($permission, $perms, true);
    }

    public static function projectPermissions(string $projectRole): array
    {
        return self::PROJECT_MAP[$projectRole] ?? [];
    }

    public static function canOnProject(array $globalRoles, string $projectRole, string $permission): bool
    {
        if (self::can($globalRoles, $permission) || self::can($globalRoles, '*')) {
            return true;
        }
        return in_array($permission, self::projectPermissions($projectRole), true);
    }

    public static function projectRole(string $userId, string $projectId): ?string
    {
        $stmt = Db::pdo()->prepare('SELECT role FROM project_memberships WHERE user_id = ? AND project_id = ?');
        $stmt->execute([$userId, $projectId]);
        $role = $stmt->fetchColumn();
        return $role === false ? null : (string) $role;
    }

    /** @return list<string> */
    public static function roleOptions(): array
    {
        return ['superadmin', 'admin', 'project_lead', 'team', 'member', 'freelance', 'volunteer', 'guest', 'finance'];
    }
}
