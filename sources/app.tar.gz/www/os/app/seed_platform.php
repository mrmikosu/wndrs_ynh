#!/usr/bin/env php
<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$db = Db::pdo();
$result = Ops::seedPlatform($db);

echo 'Seed platform:' . PHP_EOL;
echo '  time_activity_types inserted: ' . $result['time_activity_types'] . PHP_EOL;
echo '  feature_flags inserted: ' . $result['feature_flags'] . PHP_EOL;
