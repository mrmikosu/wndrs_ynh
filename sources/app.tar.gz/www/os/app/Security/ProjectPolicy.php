<?php
declare(strict_types=1);

/**
 * ProjectPolicy — objektbezogene Zugriffsregeln für Projekte und deren Aufgaben.
 *
 * Regeln (vom Nutzer freigegeben, Phase 1):
 * - Globales Recht 'projects.manage' oder '*' erlaubt alles.
 * - Sonst entscheidet ausschließlich die Rolle in project_memberships DIESES
 *   Projekts (lead/contributor/viewer via Rbac::PROJECT_MAP). Globale Rechte
 *   wie 'projects.read'/'projects.task' der Rolle 'member' gelten hier bewusst
 *   NICHT — sie würden jede Objektgrenze aufheben (Befund A, Phase 0).
 * - Inaktive Konten: immer verboten.
 * - Gesperrte/pausierte/archivierte Projekte: keine Schreibaktionen über
 *   Projektrollen. Globale Manager ('*'/'projects.manage') dürfen weiter
 *   schreiben, damit z. B. ein versehentliches Archivieren rückgängig gemacht
 *   werden kann.
 */
final class ProjectPolicy
{
    /** Projekt-Status, auf denen projektbezogene Schreibaktionen verboten sind. */
    private const WRITE_BLOCKED_STATUSES = ['paused', 'archived', 'locked'];

    /** Darf der Actor das Projekt sehen? */
    public static function canView(Actor $actor, ?array $project, ?PDO $db = null): bool
    {
        if (!$actor->active || $project === null) {
            return false;
        }
        if (self::managesAll($actor)) {
            return true;
        }
        return self::projectHas($actor, $project, 'projects.read', $db);
    }

    /** Darf der Actor das Projekt verwalten (Stammdaten, Status, Lead)? */
    public static function canManage(Actor $actor, ?array $project, ?PDO $db = null): bool
    {
        if (!$actor->active || $project === null) {
            return false;
        }
        if (self::managesAll($actor)) {
            return true;
        }
        if (self::isWriteBlocked($project)) {
            return false;
        }
        return self::projectHas($actor, $project, 'projects.lead', $db);
    }

    /** Darf der Actor Aufgaben dieses Projekts anlegen/ändern/löschen? */
    public static function canEditTask(Actor $actor, ?array $project, ?PDO $db = null): bool
    {
        if (!$actor->active || $project === null) {
            // Aufgaben ohne Projektbezug: nur globale Verwalter.
            return $actor->active && $project === null && self::managesAll($actor);
        }
        if (self::managesAll($actor)) {
            return true;
        }
        if (self::isWriteBlocked($project)) {
            return false;
        }
        return self::projectHas($actor, $project, 'projects.task', $db);
    }

    /** Globale Verwaltungsberechtigung ('projects.manage' oder '*'). */
    public static function managesAll(Actor $actor): bool
    {
        return $actor->can('projects.manage') || $actor->isWildcard();
    }

    private static function isWriteBlocked(array $project): bool
    {
        return in_array((string) ($project['status'] ?? ''), self::WRITE_BLOCKED_STATUSES, true);
    }

    /** Prüft ein Recht der projektbezogenen Rolle (Rbac::PROJECT_MAP) in DIESEM Projekt. */
    private static function projectHas(Actor $actor, array $project, string $permission, ?PDO $db): bool
    {
        $role = self::projectRole($actor->id, (string) $project['id'], $db);
        if ($role === null) {
            return false;
        }
        return in_array($permission, Rbac::projectPermissions($role), true);
    }

    /** Projektzugehörigkeit; mit injizierbarer PDO für Tests, sonst über Rbac/Db. */
    private static function projectRole(string $userId, string $projectId, ?PDO $db): ?string
    {
        if ($db === null) {
            return Rbac::projectRole($userId, $projectId);
        }
        $stmt = $db->prepare('SELECT role FROM project_memberships WHERE user_id = ? AND project_id = ?');
        $stmt->execute([$userId, $projectId]);
        $role = $stmt->fetchColumn();
        return $role === false ? null : (string) $role;
    }
}
