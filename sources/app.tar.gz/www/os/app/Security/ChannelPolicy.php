<?php
declare(strict_types=1);

/**
 * ChannelPolicy — Zugriffsregeln für Nachrichtenkanäle.
 *
 * Regeln (vom Nutzer freigegeben, Phase 1):
 * - Öffentliche Kanäle (visibility = 'public'): für alle aktiven Mitglieder
 *   lesbar; Schreiben erfordert zusätzlich das Recht 'channels.write'.
 * - Private Kanäle: nur mit Eintrag in channel_members les-/schreibbar
 *   (Schreiben ebenfalls nur mit 'channels.write'). Kein Admin-Bypass —
 *   Moderationszugang für private Kanäle ist bewusst out of scope.
 * - Inaktive Konten: immer verboten.
 */
final class ChannelPolicy
{
    /** Darf der Actor den Kanal lesen? */
    public static function canRead(Actor $actor, array $channel, ?PDO $db = null): bool
    {
        if (!$actor->active) {
            return false;
        }
        if (self::isPublic($channel)) {
            return true;
        }
        return self::isMember($actor->id, (string) $channel['id'], $db);
    }

    /** Darf der Actor in den Kanal schreiben? */
    public static function canWrite(Actor $actor, array $channel, ?PDO $db = null): bool
    {
        if (!self::canRead($actor, $channel, $db)) {
            return false;
        }
        return $actor->can('channels.write');
    }

    /**
     * Alle für den Actor sichtbaren Kanäle (öffentliche + private mit Mitgliedschaft),
     * für die Kanalliste in der Oberfläche.
     *
     * @return list<array<string, mixed>>
     */
    public static function visibleChannels(Actor $actor, ?PDO $db = null): array
    {
        $db = $db ?? Db::pdo();
        if (!$actor->active) {
            return [];
        }
        $stmt = $db->prepare(
            "SELECT c.* FROM channels c
             WHERE c.archived = 0 AND (
                   c.visibility = 'public'
                   OR EXISTS (SELECT 1 FROM channel_members m
                              WHERE m.channel_id = c.id AND m.user_id = ?)
             )
             ORDER BY c.name"
        );
        $stmt->execute([$actor->id]);
        return $stmt->fetchAll();
    }

    /** Kanalmitgliedschaft vorhanden? */
    public static function isMember(string $userId, string $channelId, ?PDO $db = null): bool
    {
        $db = $db ?? Db::pdo();
        $stmt = $db->prepare('SELECT 1 FROM channel_members WHERE channel_id = ? AND user_id = ?');
        $stmt->execute([$channelId, $userId]);
        return (bool) $stmt->fetchColumn();
    }

    private static function isPublic(array $channel): bool
    {
        // Kanäle ohne Visibility-Spalte (Altbestand) gelten als öffentlich.
        return ($channel['visibility'] ?? 'public') === 'public';
    }
}
