<?php
declare(strict_types=1);

/**
 * Actor — schlankes Sicherheitsobjekt des aktuell angemeldeten Nutzers.
 *
 * Adapter über Auth (Session) und Rbac (Rechte): Rollen kommen weiterhin aus
 * role_assignments und werden über Rbac aufgelöst. Actor ersetzt Rbac NICHT,
 * er bündelt nur Identität + Aktiv-Status + Rollen für Policy-Prüfungen.
 */
final class Actor
{
    /** @param list<string> $roles */
    public function __construct(
        public readonly string $id,
        public readonly bool $active,
        public readonly array $roles = [],
        public readonly ?string $membershipStatus = null,
    ) {
    }

    /**
     * Aus dem Auth::user()-Array erzeugen. null, wenn niemand angemeldet ist.
     *
     * @param array<string, mixed>|null $user
     */
    public static function fromUser(?array $user): ?self
    {
        if (!$user) {
            return null;
        }
        return new self(
            (string) $user['id'],
            !empty($user['is_active']),
            array_values($user['roles'] ?? []),
            isset($user['membership_status']) ? (string) $user['membership_status'] : null,
        );
    }

    /** Wie Auth::requireLogin(), liefert aber einen Actor. Inaktive Konten: 403. */
    public static function requireLogin(): self
    {
        $actor = self::fromUser(Auth::requireLogin());
        if ($actor === null || !$actor->active) {
            // Auth::user() filtert inaktive Konten bereits; dies ist Tiefenverteidigung.
            http_response_code(403);
            echo 'Konto nicht aktiv.';
            exit;
        }
        return $actor;
    }

    /** Wie Auth::requireMember(), liefert aber einen Actor. */
    public static function requireMember(): self
    {
        Auth::requireMember();
        return self::requireLogin();
    }

    /** Wie Auth::requireTeam(), liefert aber einen Actor. */
    public static function requireTeam(): self
    {
        Auth::requireTeam();
        return self::requireLogin();
    }

    /** Wie Auth::requireAdmin(), liefert aber einen Actor. */
    public static function requireAdmin(): self
    {
        Auth::requireAdmin();
        return self::requireLogin();
    }

    /** Wie Auth::requirePerm(), liefert aber einen Actor. */
    public static function requirePerm(string $permission): self
    {
        Auth::requirePerm($permission);
        return self::requireLogin();
    }

    /** Rechteprüfung über die globale Rollenmatrix (delegiert an Rbac). */
    public function can(string $permission): bool
    {
        return Rbac::can($this->roles, $permission);
    }

    public function isWildcard(): bool
    {
        return Rbac::can($this->roles, '*');
    }
}
