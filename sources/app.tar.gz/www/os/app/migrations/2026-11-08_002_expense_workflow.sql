-- Auslagenfreigabe-Workflow + Outbox (Phase 2, additiv)
-- Entscheidungsdaten an Auslagen: wer, wann, welche Begründung.
ALTER TABLE expenses ADD COLUMN decided_by TEXT;
ALTER TABLE expenses ADD COLUMN decided_at TEXT;
ALTER TABLE expenses ADD COLUMN decision_note TEXT NOT NULL DEFAULT '';

-- Outbox für nachgelagerte Effekte (z. B. Benachrichtigungen),
-- wird in derselben Transaktion wie die Fachänderung geschrieben.
CREATE TABLE IF NOT EXISTS outbox (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  payload_json TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  processed_at TEXT
);
