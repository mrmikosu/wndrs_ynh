-- Equipment-Reservierungs-Workflow (Phase 5a, additiv)
-- Entscheidungsdaten + Ausgabe-/Rückgabezustand.
ALTER TABLE asset_reservations ADD COLUMN decided_by TEXT;
ALTER TABLE asset_reservations ADD COLUMN decided_at TEXT;
ALTER TABLE asset_reservations ADD COLUMN decision_note TEXT NOT NULL DEFAULT '';
ALTER TABLE asset_reservations ADD COLUMN checked_out_at TEXT;
ALTER TABLE asset_reservations ADD COLUMN checked_out_by TEXT;
ALTER TABLE asset_reservations ADD COLUMN returned_at TEXT;
ALTER TABLE asset_reservations ADD COLUMN returned_by TEXT;
