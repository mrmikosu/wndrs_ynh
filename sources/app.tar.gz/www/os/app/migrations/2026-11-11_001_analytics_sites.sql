CREATE TABLE IF NOT EXISTS analytics_sites (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  domain TEXT NOT NULL,
  endpoint TEXT NOT NULL DEFAULT '/a/x.php',
  sid TEXT NOT NULL UNIQUE,
  config_path TEXT NOT NULL DEFAULT 'data/analytics/config.php',
  tz TEXT NOT NULL DEFAULT 'Europe/Berlin',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

INSERT OR IGNORE INTO analytics_sites (id, name, domain, sid, config_path)
VALUES (1, 'WNDRS', 'wndrs.de', 'wndrs', 'data/analytics/config.php');
