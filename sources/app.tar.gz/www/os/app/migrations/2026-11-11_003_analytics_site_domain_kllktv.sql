-- Public landing host for campaign links / site label.
UPDATE analytics_sites
SET domain = 'kllktv.wndrs.de'
WHERE domain IN ('wndrs.de', 'www.wndrs.de')
   OR (id = 1 AND domain NOT LIKE '%.%.%');
