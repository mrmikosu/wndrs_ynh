-- Bewerbungs-Entscheidungsdaten (Phase 5b, additiv)
ALTER TABLE applications ADD COLUMN decided_by TEXT;
ALTER TABLE applications ADD COLUMN decided_at TEXT;
ALTER TABLE applications ADD COLUMN decision_note TEXT NOT NULL DEFAULT '';
