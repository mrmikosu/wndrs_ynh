-- Kanalmitgliedschaft (Phase 1, additiv — bestehende Migrationen bleiben unverändert)
-- Öffentliche Kanäle bleiben für alle aktiven Mitglieder les-/schreibbar;
-- private Kanäle nur mit Eintrag in channel_members.
CREATE TABLE IF NOT EXISTS channel_members (
  id TEXT PRIMARY KEY,
  channel_id TEXT NOT NULL REFERENCES channels(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  role TEXT NOT NULL DEFAULT 'member',
  joined_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(channel_id, user_id)
);

-- Sichtbarkeit des Kanals: 'public' (Default, bisheriges Verhalten) oder 'private'.
ALTER TABLE channels ADD COLUMN visibility TEXT NOT NULL DEFAULT 'public';
