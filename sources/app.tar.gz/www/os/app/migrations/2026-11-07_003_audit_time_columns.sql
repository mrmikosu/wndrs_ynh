-- Best-effort column adds; Migrator wraps whole file in a transaction.
-- SQLite cannot IF NOT EXISTS for columns; ensureColumn helper also used from PHP.
ALTER TABLE audit_logs ADD COLUMN ip TEXT NOT NULL DEFAULT '';
ALTER TABLE audit_logs ADD COLUMN user_agent TEXT NOT NULL DEFAULT '';
ALTER TABLE projects ADD COLUMN phase TEXT NOT NULL DEFAULT 'idea';
ALTER TABLE projects ADD COLUMN concept TEXT NOT NULL DEFAULT '';
ALTER TABLE time_entries ADD COLUMN activity_type TEXT NOT NULL DEFAULT 'orga';
ALTER TABLE time_entries ADD COLUMN event_id TEXT;
ALTER TABLE time_entries ADD COLUMN cost_center TEXT NOT NULL DEFAULT '';
ALTER TABLE time_entries ADD COLUMN night_flag INTEGER NOT NULL DEFAULT 0;
ALTER TABLE time_entries ADD COLUMN weekend_flag INTEGER NOT NULL DEFAULT 0;
ALTER TABLE time_entries ADD COLUMN break_minutes INTEGER NOT NULL DEFAULT 0;
ALTER TABLE time_entries ADD COLUMN review_note TEXT NOT NULL DEFAULT '';
ALTER TABLE job_posts ADD COLUMN slots INTEGER NOT NULL DEFAULT 1;
ALTER TABLE job_posts ADD COLUMN qualifications TEXT NOT NULL DEFAULT '[]';
ALTER TABLE job_posts ADD COLUMN deadline TEXT;
ALTER TABLE job_posts ADD COLUMN event_id TEXT;
ALTER TABLE profiles ADD COLUMN trades TEXT NOT NULL DEFAULT '[]';
