CREATE TABLE IF NOT EXISTS analytics_campaigns (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  landing_path TEXT NOT NULL DEFAULT '/',
  utm_source TEXT NOT NULL,
  utm_medium TEXT NOT NULL,
  utm_campaign TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  archived_at TEXT NULL,
  UNIQUE (utm_source, utm_medium, utm_campaign)
);

CREATE INDEX IF NOT EXISTS idx_analytics_campaigns_archived
  ON analytics_campaigns (archived_at);
