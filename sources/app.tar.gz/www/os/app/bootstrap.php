<?php
declare(strict_types=1);

require_once __DIR__ . '/Config.php';
require_once __DIR__ . '/Db.php';
require_once __DIR__ . '/Rbac.php';
require_once __DIR__ . '/Auth.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/Automations.php';
require_once __DIR__ . '/Core/Env.php';
require_once __DIR__ . '/Core/Security.php';
require_once __DIR__ . '/Core/RateLimit.php';
require_once __DIR__ . '/Core/Mailer.php';
require_once __DIR__ . '/Core/Health.php';
require_once __DIR__ . '/Core/Migrator.php';
require_once __DIR__ . '/Core/Time.php';
require_once __DIR__ . '/Security/Actor.php';
require_once __DIR__ . '/Security/ProjectPolicy.php';
require_once __DIR__ . '/Security/ChannelPolicy.php';
require_once __DIR__ . '/Modules/Approvals/ApprovalErrors.php';
require_once __DIR__ . '/Modules/Approvals/Outbox.php';
require_once __DIR__ . '/Modules/Approvals/Queries/ApprovalInboxQuery.php';
require_once __DIR__ . '/Modules/Dashboard/Queries/DashboardQuery.php';
require_once __DIR__ . '/Modules/Expenses/ExpenseRepository.php';
require_once __DIR__ . '/Modules/Expenses/DecideExpense.php';
require_once __DIR__ . '/Modules/Equipment/ReservationRepository.php';
require_once __DIR__ . '/Modules/Equipment/ReservationWorkflow.php';
require_once __DIR__ . '/Modules/Applications/ApplicationRepository.php';
require_once __DIR__ . '/Modules/Applications/DecideApplication.php';
require_once __DIR__ . '/Modules/Events/MemberEventCreate.php';
require_once __DIR__ . '/Analytics/Store.php';
require_once __DIR__ . '/Analytics/TotpSetup.php';
require_once __DIR__ . '/Analytics/Report.php';
require_once __DIR__ . '/Analytics/Charts.php';
require_once __DIR__ . '/Modules/Analytics.php';
require_once __DIR__ . '/Modules/Ops.php';
require_once __DIR__ . '/Modules/Projects.php';
require_once __DIR__ . '/Modules/Projects/BackfillProjectLeads.php';
require_once __DIR__ . '/Modules/ProjectExtras.php';
require_once __DIR__ . '/Router.php';

Env::loadDotEnv(dirname(__DIR__) . '/.env');
date_default_timezone_set((string) Config::get('timezone', 'Europe/Berlin'));
Security::sendHeaders();
Auth::startSession();

try {
    Db::migrate();
    Migrator::run();
} catch (Throwable $e) {
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, 'Migration error: ' . $e->getMessage() . PHP_EOL);
    }
}
