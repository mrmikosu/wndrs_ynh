<?php
declare(strict_types=1);

// Production (flattened www/os/): app/ sits next to index.php.
// Local (`php -S -t public`): app/ is one level up from public/.
$appRoot = is_dir(__DIR__ . '/app')
    ? __DIR__ . '/app'
    : dirname(__DIR__) . '/app';
require_once $appRoot . '/bootstrap.php';
Router::dispatch();
