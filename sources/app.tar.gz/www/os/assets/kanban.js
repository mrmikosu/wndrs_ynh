function wndrsKanbanDrag(e) {
  const card = e.target.closest(".task-card");
  if (!card) return;
  e.dataTransfer.setData("text/task-id", card.dataset.taskId);
  e.dataTransfer.effectAllowed = "move";
  card.classList.add("dragging");
}

function wndrsKanbanDrop(e, status) {
  e.preventDefault();
  const taskId = e.dataTransfer.getData("text/task-id");
  document.querySelectorAll(".task-card.dragging").forEach((el) => el.classList.remove("dragging"));
  if (!taskId) return;
  const form = document.getElementById("kanban-move-form");
  if (!form) return;
  document.getElementById("kanban-task-id").value = taskId;
  document.getElementById("kanban-status").value = status;
  form.submit();
}

document.addEventListener("dragend", () => {
  document.querySelectorAll(".task-card.dragging").forEach((el) => el.classList.remove("dragging"));
});
