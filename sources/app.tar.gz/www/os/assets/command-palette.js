(() => {
  const root = document.createElement('div');
  root.id = 'cmdk';
  root.hidden = true;
  root.innerHTML = `
    <div class="cmdk-backdrop" data-close></div>
    <div class="cmdk-panel" role="dialog" aria-label="Befehlspalette">
      <input type="search" id="cmdk-input" placeholder="Springe zu …" autocomplete="off">
      <ul id="cmdk-list"></ul>
    </div>`;
  document.body.appendChild(root);

  const style = document.createElement('style');
  style.textContent = `
    #cmdk{position:fixed;inset:0;z-index:100}
    .cmdk-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.55)}
    .cmdk-panel{position:relative;margin:12vh auto 0;width:min(560px,calc(100% - 1.5rem));background:#161311;border:1px solid rgba(197,168,128,.28);border-radius:14px;overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.45)}
    #cmdk-input{width:100%;border:0;border-bottom:1px solid rgba(197,168,128,.28);background:transparent;color:#f3eee6;padding:1rem 1.1rem;font:inherit}
    #cmdk-list{list-style:none;margin:0;padding:.4rem;max-height:50vh;overflow:auto}
    #cmdk-list li a{display:block;padding:.55rem .7rem;border-radius:8px;color:#f3eee6;text-decoration:none}
    #cmdk-list li a:hover,#cmdk-list li a[aria-selected="true"]{background:rgba(235,84,36,.16)}
  `;
  document.head.appendChild(style);

  const u = (typeof window.__wndrsUrl === 'function') ? window.__wndrsUrl : (p) => p;
  const items = [
    { label: 'Dashboard', href: u('/members') },
    { label: 'Kalender', href: u('/members/kalender') },
    { label: 'Jobbörse', href: u('/members/jobs') },
    { label: 'Projekte', href: u('/members/projekte') },
    { label: 'Kanban', href: u('/members/kanban') },
    { label: 'Schichten', href: u('/members/schichten') },
    { label: 'Verfügbarkeit', href: u('/members/verfuegbarkeit') },
    { label: 'Mitteilungen', href: u('/members/benachrichtigungen') },
    { label: 'Arbeitszeit', href: u('/team/zeit') },
    { label: 'Profil', href: u('/members/profil') },
    { label: 'Admin', href: u('/admin') },
    { label: 'Freigaben-Inbox', href: u('/admin/inbox') },
    { label: 'Neues Projekt (Vorlagen)', href: u('/members/projekte') },
  ];

  const list = root.querySelector('#cmdk-list');
  const input = root.querySelector('#cmdk-input');
  let filtered = items;
  let idx = 0;

  function render() {
    list.innerHTML = filtered.map((it, i) =>
      `<li><a href="${it.href}" aria-selected="${i === idx}">${it.label}</a></li>`
    ).join('');
  }

  function open() {
    root.hidden = false;
    input.value = '';
    filtered = items;
    idx = 0;
    render();
    input.focus();
  }

  function close() {
    root.hidden = true;
  }

  document.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      root.hidden ? open() : close();
    }
    if (root.hidden) return;
    if (e.key === 'Escape') close();
    if (e.key === 'ArrowDown') { idx = Math.min(idx + 1, filtered.length - 1); render(); e.preventDefault(); }
    if (e.key === 'ArrowUp') { idx = Math.max(idx - 1, 0); render(); e.preventDefault(); }
    if (e.key === 'Enter' && filtered[idx]) { window.location.href = filtered[idx].href; }
  });

  input.addEventListener('input', () => {
    const q = input.value.trim().toLowerCase();
    filtered = items.filter((it) => it.label.toLowerCase().includes(q));
    idx = 0;
    render();
  });

  root.addEventListener('click', (e) => {
    if (e.target.matches('[data-close]')) close();
  });
})();
