(() => {
  const toast = document.getElementById('pwa-update-toast');
  const installBtn = document.getElementById('pwa-install');
  const iosHint = document.getElementById('pwa-ios-hint');
  let deferredPrompt = null;

  const isStandalone =
    window.matchMedia('(display-mode: standalone)').matches ||
    window.navigator.standalone === true;

  const isIos = /iphone|ipad|ipod/i.test(navigator.userAgent);

  if (installBtn) {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      installBtn.hidden = false;
    });
    installBtn.addEventListener('click', async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
      installBtn.hidden = true;
    });
  }

  if (iosHint && isIos && !isStandalone) {
    iosHint.hidden = false;
  }

  if ('serviceWorker' in navigator) {
    const swUrl = (window.__wndrsBase || '') + '/sw.js';
    navigator.serviceWorker.register(swUrl).then((reg) => {
      reg.addEventListener('updatefound', () => {
        const worker = reg.installing;
        if (!worker) return;
        worker.addEventListener('statechange', () => {
          if (worker.state === 'installed' && navigator.serviceWorker.controller && toast) {
            toast.hidden = false;
          }
        });
      });
    }).catch(() => {});

    if (toast) {
      const reload = toast.querySelector('[data-reload]');
      if (reload) {
        reload.addEventListener('click', () => {
          if (navigator.serviceWorker.controller) {
            navigator.serviceWorker.controller.postMessage({ type: 'SKIP_WAITING' });
          }
          window.location.reload();
        });
      }
    }
  }
})();
