(function () {
  const body = document.body;
  const vapidPublic = body?.dataset?.vapidPublic || '';
  const csrf = body?.dataset?.csrf || '';
  if (!vapidPublic || !('serviceWorker' in navigator) || !('PushManager' in window)) {
    return;
  }

  function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const raw = atob(base64);
    const out = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; ++i) {
      out[i] = raw.charCodeAt(i);
    }
    return out;
  }

  async function subscribePush() {
    const reg = await navigator.serviceWorker.ready;
    let sub = await reg.pushManager.getSubscription();
    if (!sub) {
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(vapidPublic),
      });
    }
    const json = sub.toJSON();
    const endpoint =
      typeof window.__wndrsUrl === 'function'
        ? window.__wndrsUrl('/api/v1/push/subscribe')
        : '/api/v1/push/subscribe';
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': csrf,
      },
      credentials: 'same-origin',
      body: JSON.stringify({
        endpoint: json.endpoint,
        p256dh: json.keys?.p256dh,
        auth: json.keys?.auth,
        device_name: navigator.userAgent.slice(0, 80),
        _csrf: csrf,
      }),
    });
    return res.json();
  }

  window.wndrsPushSubscribe = subscribePush;

  document.addEventListener('DOMContentLoaded', function () {
    const btn = document.getElementById('push-enable');
    if (btn) {
      btn.addEventListener('click', function () {
        subscribePush()
          .then(function (data) {
            if (data.ok) {
              btn.hidden = true;
            }
          })
          .catch(console.error);
      });
    }
  });
})();
