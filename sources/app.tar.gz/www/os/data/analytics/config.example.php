<?php
return [
    'site_id'  => 'wndrs',
    'site_key' => 'CHANGE_ME_SITE_KEY',
    'secret'   => 'CHANGE_ME_SECRET_AT_LEAST_32_CHARS____',
    'origins'  => ['https://wndrs.de', 'https://www.wndrs.de', 'http://127.0.0.1:8080'],
    'tz'       => 'Europe/Berlin',
    'device_stats' => true,
    'visitor_mode' => 'hash', // hash|off
    'geo_enabled' => false,
    'geo_db' => 'geo/GeoLite2-Country.mmdb', // relative to this directory
    'retention_days' => 30,
];
