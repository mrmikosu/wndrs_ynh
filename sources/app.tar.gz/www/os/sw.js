/* WNDRS PWA service worker — scope-aware for /site/os/ installs */
const CACHE = 'wndrs-shell-v2';
const scopeUrl = new URL('./', self.registration.scope);
const BASE = scopeUrl.pathname.replace(/\/$/, '');

function scoped(path) {
  if (!path.startsWith('/')) path = '/' + path;
  return BASE + path;
}

const PRECACHE = [
  scoped('/assets/app.css'),
  scoped('/assets/admin.css'),
  scoped('/assets/tokens.css'),
  scoped('/assets/pwa.js'),
  scoped('/assets/icons/icon-192.png'),
  scoped('/?r=/manifest.webmanifest'),
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((c) => c.addAll(PRECACHE.map((p) => new Request(p, { cache: 'reload' }))))
      .then(() => self.skipWaiting())
      .catch(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() =>
          caches.match(req).then((r) => r || caches.match(scoped('/?r=/members')))
        )
    );
    return;
  }

  const underAssets = url.pathname.startsWith(BASE + '/assets/') || url.pathname.startsWith('/assets/');
  const isManifest =
    url.pathname.endsWith('/manifest.webmanifest') || url.searchParams.get('r') === '/manifest.webmanifest';
  if (underAssets || isManifest) {
    event.respondWith(
      caches.match(req).then(
        (cached) =>
          cached ||
          fetch(req).then((res) => {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
            return res;
          })
      )
    );
  }
});

self.addEventListener('push', (event) => {
  let data = { title: 'WNDRS', body: 'Neue Benachrichtigung', url: scoped('/?r=/members') };
  try {
    if (event.data) data = { ...data, ...event.data.json() };
  } catch (_) {}
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: scoped('/assets/icons/icon-192.png'),
      badge: scoped('/assets/icons/icon-192.png'),
      data: { url: data.url || scoped('/?r=/members') },
    })
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || scoped('/?r=/members');
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) {
        if ('focus' in c) {
          c.navigate(url);
          return c.focus();
        }
      }
      return clients.openWindow(url);
    })
  );
});
