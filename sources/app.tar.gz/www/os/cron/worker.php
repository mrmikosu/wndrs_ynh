<?php
declare(strict_types=1);

/**
 * Cron worker — call every minute:
 *   php site/cron/worker.php
 * or HTTPS: /cron?token=YOUR_CRON_TOKEN
 */
require_once dirname(__DIR__) . '/app/bootstrap.php';

$token = Config::get('cron_token', '');
$provided = $_GET['token'] ?? ($argv[1] ?? '');
if (PHP_SAPI !== 'cli') {
    if ($token === '' || !is_string($provided) || !hash_equals((string) $token, $provided)) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

$mail = Mailer::processQueue(25);
$push = 0;
try {
    $pdo = Db::pdo();
    $stmt = $pdo->query("SELECT COUNT(*) FROM push_queue WHERE status = 'pending'");
    $push = (int) $stmt->fetchColumn();
} catch (Throwable) {
}

$analyticsPruned = 0;
try {
    $site = \Analytics\Store::activeSite(Db::pdo());
    $cfg = \Analytics\Store::loadCollectorConfig($site) ?? [];
    $conn = \Analytics\Store::collectorPdo($site);
    if ($conn) {
        $days = (int) ($cfg['retention_days'] ?? 30);
        $st = $conn->prepare('DELETE FROM c WHERE h < ?');
        $st->execute([time() - $days * 86400]);
        $analyticsPruned = $st->rowCount();
        $conn->exec("DELETE FROM seen WHERE day < date('now', '-2 day')");
    }
} catch (Throwable) {
}

$result = [
    'ok' => true,
    'mail_processed' => $mail,
    'push_pending' => $push,
    'analytics_pruned' => $analyticsPruned,
    'at' => gmdate('c'),
];
if (PHP_SAPI === 'cli') {
    echo json_encode($result, JSON_PRETTY_PRINT) . PHP_EOL;
} else {
    header('Content-Type: application/json');
    echo json_encode($result);
}
