<?php
// Gemeinsame Basis für c.php und x.php: Konfiguration laden, Datenbank öffnen.
declare(strict_types=1);

if (!isset($_SERVER['SCRIPT_FILENAME']) || realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    exit; // lib.php direkt aufgerufen: nichts ausgeben
}

function boot(): array
{
    $root = dirname(__DIR__, 2); // site/ when script is site/public/a/lib.php
    $candidates = [
        dirname(__DIR__) . '/data/analytics',
        $root . '/data/analytics',
        dirname(__DIR__) . '/a-data',
        dirname(__DIR__, 2) . '/a-data',
        __DIR__ . '/data',
    ];
    $dir = null;
    foreach ($candidates as $cand) {
        if (is_file($cand . '/config.php')) {
            $dir = $cand;
            break;
        }
    }
    if ($dir === null) {
        $dir = $candidates[0];
    }
    $cfg = require $dir . '/config.php';
    if (is_file($dir . '/overrides.php')) {
        $overrides = require $dir . '/overrides.php';
        if (is_array($overrides)) {
            $cfg = array_merge($cfg, array_intersect_key($overrides, [
                'visitor_mode' => true,
                'geo_enabled' => true,
                'origins' => true,
                'device_stats' => true,
                'geo_db' => true,
            ]));
        }
    }
    $cfg += ['tz' => 'Europe/Berlin', 'visitor_mode' => 'hash', 'max_rows_per_hour' => 3000,
             'retention_days' => 30, 'wal' => false, 'device_stats' => true,
             'geo_enabled' => false, 'geo_db' => 'geo/GeoLite2-Country.mmdb'];
    $cfg['_dir'] ??= $dir;
    date_default_timezone_set($cfg['tz']);

    $db = new PDO('sqlite:' . $dir . '/s.sqlite', null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_NUM,
    ]);
    $db->exec('PRAGMA busy_timeout=3000; PRAGMA secure_delete=ON;');
    if ($cfg['wal']) {
        $db->exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;');
    }
    $db->exec('CREATE TABLE IF NOT EXISTS c (site TEXT, h INTEGER, m TEXT, a TEXT, b TEXT, n INTEGER,
                 PRIMARY KEY (site, h, m, a, b)) WITHOUT ROWID;
               CREATE TABLE IF NOT EXISTS seen (site TEXT, day TEXT, vid TEXT,
                 PRIMARY KEY (site, day, vid)) WITHOUT ROWID;
               CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT) WITHOUT ROWID;');
    return [$cfg, $db];
}
