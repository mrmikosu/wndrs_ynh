<?php
// Export: liefert Zählerzeilen (nur Aggregate) an das Dashboard. Signiert per HMAC, kein IP-Bezug.
declare(strict_types=1);
require __DIR__ . '/lib.php';

header('Content-Type: application/json');
header('Cache-Control: no-store');
$deny = static function (): never { http_response_code(403); echo '{"e":1}'; exit; };

try {
    [$cfg, $db] = boot();
    $site = (string)($_GET['site'] ?? '');
    $since = (int)($_GET['since'] ?? 0);
    $ts = (int)($_GET['ts'] ?? 0);
    $sig = (string)($_GET['sig'] ?? '');
    if ($site !== (string)$cfg['site_id'] || abs(time() - $ts) > 60) $deny();
    if (!hash_equals(hash_hmac('sha256', "$site|$since|$ts", (string)$cfg['secret']), $sig)) $deny();

    $st = $db->prepare('SELECT h,m,a,b,n FROM c WHERE site=? AND h>=? ORDER BY h LIMIT 300000');
    $st->execute([$site, $since]);
    $rows = [];
    while ($r = $st->fetch()) { $r[0] = (int)$r[0]; $r[4] = (int)$r[4]; $rows[] = $r; }
    echo json_encode(['site' => $site, 'now' => time(), 'rows' => $rows], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo '{"e":2}';
}
