<?php
declare(strict_types=1);

function geo_country(array $cfg): ?string
{
    if (empty($cfg['geo_enabled'])) {
        return null;
    }
    $base = (string)($cfg['_dir'] ?? (is_dir(dirname(__DIR__) . '/data/analytics')
        ? dirname(__DIR__) . '/data/analytics'
        : dirname(__DIR__, 2) . '/data/analytics'));
    $path = (string)($cfg['geo_db'] ?? 'geo/GeoLite2-Country.mmdb');
    if ($path === '') {
        return null;
    }
    if ($path[0] !== '/') {
        $path = rtrim($base, '/') . '/' . $path;
    }
    $geoIpCandidates = [
        dirname(__DIR__) . '/app/Analytics/GeoIp.php',
        dirname(__DIR__, 2) . '/app/Analytics/GeoIp.php',
    ];
    foreach ($geoIpCandidates as $geoIpFile) {
        if (is_file($geoIpFile)) {
            require_once $geoIpFile;
            break;
        }
    }
    return \Analytics\GeoIp::countryCode($_SERVER['REMOTE_ADDR'] ?? '', $path);
}
