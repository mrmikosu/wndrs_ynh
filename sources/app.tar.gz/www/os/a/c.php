<?php
// Collector: nimmt Ereignisse an und erhöht Stundenzähler. Speichert keine Rohdaten.
declare(strict_types=1);
require __DIR__ . '/lib.php';
require __DIR__ . '/geo.php';

http_response_code(204);
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') exit;

$raw = file_get_contents('php://input', false, null, 0, 1025);
if ($raw === false || strlen($raw) > 1024) exit;
$j = json_decode($raw, true);
if (!is_array($j)) exit;

try {
    [$cfg, $db] = boot();
    $site = (string)$cfg['site_id'];
    if (!hash_equals((string)$cfg['site_key'], (string)($j['k'] ?? ''))) exit;
    if (!in_array($_SERVER['HTTP_ORIGIN'] ?? '', $cfg['origins'], true)) exit;

    $PATH = '#^/[A-Za-z0-9._~%!$&()*+,;=:@/-]{0,199}$#'; // nur URL-sichere Zeichen (Browser kodieren den Rest)
    $p = $j['p'] ?? '';
    if (!is_string($p) || !preg_match($PATH, $p)) exit;
    $dom = static function ($v): string {
        $v = strtolower(is_string($v) ? $v : '');
        $v = preg_replace('~^www\.~', '', $v);
        return preg_match('~^[a-z0-9.-]{1,100}$~', $v) ? $v : '';
    };
    $tag = static fn($v): string => (is_string($v) && preg_match('#^[A-Za-z0-9 ._~%!$&()*+,;=:@/-]{1,40}$#', $v)) ? $v : '';

    $now = time();
    $h = intdiv($now, 3600) * 3600;
    $full = (int)$db->query("SELECT COUNT(*) FROM c WHERE site=" . $db->quote($site) . " AND h=$h")->fetchColumn()
            >= $cfg['max_rows_per_hour'];
    $st = $db->prepare('INSERT INTO c (site,h,m,a,b,n) VALUES (?,?,?,?,?,?)
                        ON CONFLICT(site,h,m,a,b) DO UPDATE SET n = n + excluded.n');
    $inc = static function (string $m, string $a, string $b, int $n = 1) use ($st, $site, $h, $db, $full): void {
        if ($full) {
            $chk = $db->prepare('SELECT 1 FROM c WHERE site=? AND h=? AND m=? AND a=? AND b=?');
            $chk->execute([$site, $h, $m, $a, $b]);
            if (!$chk->fetchColumn()) { $a = '(andere)'; $b = $b === '' ? '' : '(andere)'; }
        }
        $st->execute([$site, $h, $m, $a, $b, $n]);
    };

    $t = $j['t'] ?? '';
    $ua = ua_info($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua === null) { // Bots werden getrennt gezählt und lösen sonst nichts aus
        if ($t === 'pv') $inc('bot', 'total', '');
        exit;
    }
    switch ($t) {
        case 'pv':
            $inc('pv', $p, '');
            $newVisitor = true; // ohne Tages-Hash: Gerätewerte pro Aufruf statt pro Tagesbesucher
            if ($cfg['visitor_mode'] === 'hash') {
                $day = date('Y-m-d', $now);
                $salt = day_salt($db, $day);
                // IP und User-Agent nur im Arbeitsspeicher für diesen einen Hash, nie gespeichert oder geloggt.
                $vid = substr(hash_hmac('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '') . '|' . $site, $salt), 0, 12);
                $ins = $db->prepare('INSERT OR IGNORE INTO seen (site,day,vid) VALUES (?,?,?)');
                $ins->execute([$site, $day, $vid]);
                $newVisitor = $ins->rowCount() === 1;
                if ($newVisitor) $inc('vis', 'total', '');
            }
            if ($newVisitor && $cfg['device_stats']) { // grobe Klassen, der User-Agent selbst wird nie gespeichert
                $inc('dev', $ua['dev'], '');
                $inc('br', $ua['br'], '');
                $inc('os', $ua['os'], '');
                $inc('lang', $ua['lang'], '');
            }
            if ($newVisitor) {
                $cc = geo_country($cfg);
                if ($cc !== null) $inc('cc', $cc, '');
            }
            if (empty($j['rl'])) {
                $prev = (string)($j['q'] ?? '');
                if ($prev !== '' && preg_match($PATH, $prev)) {
                    $inc('tr', $prev, $p);
                } else {
                    $ref = $dom($j['r'] ?? '');
                    $inc('ent', $p, $ref !== '' ? $ref : '(direkt)');
                    $u = $j['u'] ?? null;
                    if (is_array($u) && $tag($u[0] ?? null) !== '') {
                        $inc('utm', $tag($u[0]), $tag($u[1] ?? null) . '/' . $tag($u[2] ?? null));
                    }
                }
            }
            break;
        case 'd':
            $s = max(0, min(1800, (int)($j['s'] ?? 0)));
            if ($s > 0) $inc('dws', $p, '', $s);
            if (!empty($j['f'])) $inc('dwn', $p, '');
            break;
        case 'c':
            $g = $j['g'] ?? '';
            if (is_string($g) && preg_match('#^(out|dl|ev):[A-Za-z0-9 ._~%!$&()*+,;=:@/-]{1,80}$#', $g)) $inc('clk', $p, $g);
            break;
    }

    if (random_int(1, 200) === 1) { // gelegentlich aufräumen
        $db->prepare('DELETE FROM c WHERE h < ?')->execute([$now - $cfg['retention_days'] * 86400]);
    }
} catch (Throwable $e) {
    // bewusst still: keine Fehlerdetails nach außen, nichts mit Besucherbezug ins Log
}

function day_salt(PDO $db, string $day): string
{
    $read = static function () use ($db, $day): ?string {
        $v = $db->query("SELECT v FROM kv WHERE k='salt'")->fetchColumn();
        if (is_string($v) && str_starts_with($v, $day . '|')) return substr($v, strlen($day) + 1);
        return null;
    };
    if (($s = $read()) !== null) return $s;
    $db->exec('BEGIN IMMEDIATE');
    if (($s = $read()) === null) {
        $s = bin2hex(random_bytes(32));
        $db->prepare("INSERT OR REPLACE INTO kv (k,v) VALUES ('salt', ?)")->execute([$day . '|' . $s]);
        $db->prepare('DELETE FROM seen WHERE day <> ?')->execute([$day]);
    }
    $db->exec('COMMIT');
    return $s;
}

/** Grobe Klassifizierung. Gibt null für Bots zurück. Nichts davon wird gespeichert außer der Klassenname. */
function ua_info(string $ua): ?array
{
    $l = strtolower($ua);
    if ($l === '' || preg_match('/bot|crawl|spider|slurp|headless|lighthouse|pagespeed|curl|wget|python|java\/|httpclient|preview|monitor|facebookexternalhit/', $l)) {
        return null;
    }
    $os = preg_match('/iphone|ipad|ipod/', $l) ? 'iOS' : (str_contains($l, 'android') ? 'Android' : (str_contains($l, 'windows') ? 'Windows'
        : (str_contains($l, 'cros') ? 'ChromeOS' : (preg_match('/macintosh|mac os/', $l) ? 'macOS' : (str_contains($l, 'linux') ? 'Linux' : 'Andere')))));
    $br = preg_match('/edg(e|a|ios)?\//', $l) ? 'Edge' : (preg_match('/opr\/|opera/', $l) ? 'Opera' : (str_contains($l, 'samsungbrowser') ? 'Samsung Internet'
        : (preg_match('/firefox|fxios/', $l) ? 'Firefox' : (preg_match('/chrome|crios/', $l) ? 'Chrome' : (str_contains($l, 'safari') ? 'Safari' : 'Andere')))));
    $dev = preg_match('/ipad|tablet/', $l) || (str_contains($l, 'android') && !str_contains($l, 'mobile')) ? 'Tablet'
        : (preg_match('/mobile|iphone|android/', $l) ? 'Mobil' : 'Desktop');
    $lang = preg_match('/^([a-z]{2})/i', $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '', $m) ? strtolower($m[1]) : '??';
    return ['os' => $os, 'br' => $br, 'dev' => $dev, 'lang' => $lang];
}
