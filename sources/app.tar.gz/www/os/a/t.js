/* Tracker: keine Cookies, keine IDs, nichts im Browser gespeichert. Einbindung:
   <script defer src="/a/t.js" data-k="SITE_KEY"></script> */
(function () {
  var s = document.currentScript, d = document, w = window, n = navigator, l = location;
  if (!s) return;
  try { if (n.doNotTrack == '1' || n.globalPrivacyControl || w.localStorage.getItem('no-stats')) return; } catch (e) {}
  var ep = s.src.replace(/t\.js(\?.*)?$/, 'c.php'), k = s.getAttribute('data-k'), p = l.pathname;

  function send(o) {
    o.k = k; o.p = p;
    var b = JSON.stringify(o);
    try { if (!(n.sendBeacon && n.sendBeacon(ep, b))) throw 0; }
    catch (e) { try { fetch(ep, { method: 'POST', body: b, keepalive: true, mode: 'no-cors' }); } catch (e2) {} }
  }

  // Seitenaufruf: externer Referrer (nur Domain) oder interne Vorgängerseite (nur Pfad)
  var ref = '', prev = '', r = d.referrer, rl = 0;
  try {
    var nav = performance.getEntriesByType('navigation')[0];
    rl = nav && nav.type === 'reload' ? 1 : 0;
    if (r) { var u = new URL(r); if (u.host === l.host) prev = u.pathname; else ref = u.hostname; }
  } catch (e) {}
  var q = new URLSearchParams(l.search), utm = q.get('utm_source') ? [q.get('utm_source'), q.get('utm_medium') || '', q.get('utm_campaign') || ''].map(function (x) { return x.slice(0, 40); }) : 0;
  send({ t: 'pv', r: ref, q: prev, rl: rl, u: utm });

  // Verweildauer: nur sichtbare Zeit, im Arbeitsspeicher gezählt, beim Verlassen gesendet
  var acc = 0, st = d.visibilityState === 'visible' ? Date.now() : 0, first = 1;
  function stop() { if (st) { acc += Date.now() - st; st = 0; } }
  function flush() {
    stop();
    var sec = Math.round(acc / 1000);
    if (sec < 1 && !first) return;
    send({ t: 'd', s: sec, f: first }); first = 0; acc = 0;
  }
  d.addEventListener('visibilitychange', function () { if (d.visibilityState === 'hidden') flush(); else st = Date.now(); });
  w.addEventListener('pagehide', flush);

  // Klicks: externe Links, Downloads, Elemente mit data-track="name"
  d.addEventListener('click', function (e) {
    var t = e.target && e.target.closest ? e.target.closest('[data-track],a[href]') : null;
    if (!t) return;
    var g = '';
    if (t.hasAttribute('data-track')) g = 'ev:' + t.getAttribute('data-track');
    else if (t.hostname && t.hostname !== l.hostname) g = 'out:' + t.hostname;
    else if (/\.(pdf|zip|docx?|xlsx?|pptx?|mp3|mp4|csv|exe|dmg)$/i.test(t.pathname)) g = 'dl:' + t.pathname;
    if (g) send({ t: 'c', g: g.slice(0, 84) });
  }, true);
})();
