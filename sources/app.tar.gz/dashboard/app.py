"""Besucher-Analyse Dashboard (Starlette). Start: uvicorn app:app --host 127.0.0.1 --port 8000"""
import asyncio
import csv
import hmac
import io
import os
import re
import secrets
import time
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo, available_timezones

from markupsafe import Markup
from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import FileResponse, PlainTextResponse, RedirectResponse, Response
from starlette.routing import Route
from starlette.templating import Jinja2Templates

import charts
import db
import importer
import reports
import security as sec

BASE = os.path.dirname(os.path.abspath(__file__))
SECURE = os.environ.get("DASH_INSECURE_COOKIES") != "1"
IMPORT_MIN = int(os.environ.get("DASH_IMPORT_MIN", "15"))  # 0 = Hintergrund-Import aus
SESSION_SECONDS = 12 * 3600
templates = Jinja2Templates(directory=os.path.join(BASE, "templates"))


def _n(v):
    return "–" if v is None else f"{int(round(v)):,}".replace(",", ".")


def _dur(s):
    if s is None:
        return "–"
    s = int(round(s))
    return f"{s // 60}:{s % 60:02d} min" if s >= 60 else f"{s} s"


def _pct(v):
    return "–" if v is None else f"{v * 100:.0f} %"


def _ago(ts):
    if not ts:
        return "noch nie"
    d = int(time.time()) - ts
    return "gerade eben" if d < 90 else f"vor {d // 60} Min." if d < 5400 else f"vor {d // 3600} Std." if d < 172800 else f"vor {d // 86400} Tagen"


templates.env.filters.update(n=_n, dur=_dur, pct=_pct, ago=_ago, svg=Markup)


# ---------------------------------------------------------------- Sicherheit / Sitzung
# Comma-separated public hostnames (Yunohost dashboard_domain). Needed when nginx
# forwards Host as 127.0.0.1 or browsers send Origin: null on form POSTs.
PUBLIC_HOSTS = {
    h.lower().split(":")[0]
    for h in os.environ.get("DASH_PUBLIC_HOST", "").replace(" ", "").split(",")
    if h
}


def _request_hosts(request: Request) -> set[str]:
    hosts = set(PUBLIC_HOSTS)
    for raw in (
        request.headers.get("host") or "",
        (request.headers.get("x-forwarded-host") or "").split(",", 1)[0].strip(),
    ):
        h = raw.lower().split(":")[0].strip()
        if h:
            hosts.add(h)
    return hosts


def _post_origin_ok(request: Request) -> bool:
    """CSRF helper for login (no session cookie yet) and other POSTs."""
    origin = (request.headers.get("origin") or "").strip()
    site = (request.headers.get("sec-fetch-site") or "").lower()
    # Browser asserts same-origin navigational POST (survives Host=127.0.0.1).
    if site == "same-origin":
        return True
    if not origin:
        return True
    if origin == "null":
        # Opaque origin (some embedded / privacy browsers). Allow same-site only.
        return site in ("same-site", "none")
    origin_host = origin.split("://", 1)[-1].split("/", 1)[0].lower().split(":")[0]
    if origin_host in _request_hosts(request):
        return True
    # Referer fallback when Origin is odd but still same host
    referer = (request.headers.get("referer") or "").strip()
    if referer:
        ref_host = referer.split("://", 1)[-1].split("/", 1)[0].lower().split(":")[0]
        if ref_host and ref_host in _request_hosts(request):
            return True
    return False


class Guard(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.method == "POST" and not _post_origin_ok(request):
            return PlainTextResponse("Forbidden", status_code=403)
        request.state.db = db.connect()
        try:
            resp = await call_next(request)
        finally:
            request.state.db.close()
        h = resp.headers
        h["Content-Security-Policy"] = ("default-src 'none'; style-src 'self'; img-src 'self'; "
                                        "form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
        h["X-Content-Type-Options"] = "nosniff"
        h["Referrer-Policy"] = "no-referrer"
        h["X-Frame-Options"] = "DENY"
        if SECURE:
            h["Strict-Transport-Security"] = "max-age=31536000"
        if not request.url.path.startswith("/static"):
            h["Cache-Control"] = "no-store"
        return resp


def current(request: Request):
    """Gibt (user, session) zurück oder (None, None)."""
    t = request.cookies.get("sid")
    if not t:
        return None, None
    c = request.state.db
    row = c.execute("SELECT s.token, s.csrf, s.expires, u.* FROM sessions s JOIN users u ON u.id=s.user_id "
                    "WHERE s.token=?", (sec.token_hash(t),)).fetchone()
    if not row or row["expires"] < time.time():
        return None, None
    return row, row


def login_required(request: Request, admin=False):
    user, _ = current(request)
    if not user:
        return None, RedirectResponse("/login", status_code=303)
    if admin and not user["admin"]:
        return None, page(request, "error.html", user, msg="Dafür fehlt die Berechtigung.", status=403)
    return user, None


def csrf_ok(user, form) -> bool:
    return hmac.compare_digest(str(form.get("csrf", "")), user["csrf"])


def page(request, name, user, status=200, **ctx):
    ctx.update(user=user, csrf=user["csrf"] if user else "", active=ctx.get("active", ""))
    return templates.TemplateResponse(request, name, ctx, status_code=status)


def visible_sites(c, user):
    if user["admin"]:
        return c.execute("SELECT * FROM sites ORDER BY name").fetchall()
    return c.execute("SELECT s.* FROM sites s JOIN access a ON a.site_id=s.id WHERE a.user_id=? ORDER BY s.name",
                     (user["id"],)).fetchall()


def get_site(c, user, site_id):
    return next((s for s in visible_sites(c, user) if s["id"] == site_id), None)


# ---------------------------------------------------------------- Anmeldung
async def login(request: Request):
    user, _ = current(request)
    if user:
        return RedirectResponse("/", status_code=303)
    if request.method == "GET":
        return templates.TemplateResponse(request, "login.html", {"user": None, "error": None})
    f = await request.form()
    c = request.state.db
    name, pw, code = str(f.get("name", ""))[:60], str(f.get("password", ""))[:200], str(f.get("code", ""))
    u = c.execute("SELECT * FROM users WHERE name=?", (name,)).fetchone()
    ok = False
    if u and u["locked_until"] > time.time():
        sec.verify_pw(pw, sec.DUMMY_HASH)
    elif u:
        pw_ok = sec.verify_pw(pw, u["pw"])
        step = sec.totp_verify(u["totp"], code, u["last_step"])
        ok = pw_ok and step is not None
        with c:
            if ok:
                c.execute("UPDATE users SET fails=0, last_step=? WHERE id=?", (step, u["id"]))
            else:
                fails = u["fails"] + 1
                c.execute("UPDATE users SET fails=?, locked_until=? WHERE id=?",
                          (0 if fails >= 5 else fails, int(time.time()) + 900 if fails >= 5 else 0, u["id"]))
    else:
        sec.verify_pw(pw, sec.DUMMY_HASH)
    if not ok:
        db.audit(c, name[:40], "login_failed")
        return templates.TemplateResponse(request, "login.html",
                                          {"user": None, "error": "Anmeldung fehlgeschlagen (oder vorübergehend gesperrt)."},
                                          status_code=401)
    tok = sec.token()
    with c:
        c.execute("DELETE FROM sessions WHERE expires<?", (time.time(),))
        c.execute("INSERT INTO sessions(token,user_id,csrf,expires) VALUES(?,?,?,?)",
                  (sec.token_hash(tok), u["id"], secrets.token_urlsafe(24), int(time.time()) + SESSION_SECONDS))
    db.audit(c, name, "login")
    r = RedirectResponse("/", status_code=303)
    r.set_cookie("sid", tok, max_age=SESSION_SECONDS, httponly=True, secure=SECURE, samesite="strict", path="/")
    return r


async def logout(request: Request):
    user, r = login_required(request)
    if r:
        return r
    f = await request.form()
    if csrf_ok(user, f):
        with request.state.db:
            request.state.db.execute("DELETE FROM sessions WHERE token=?", (user["token"],))
    resp = RedirectResponse("/login", status_code=303)
    resp.delete_cookie("sid", path="/")
    return resp


async def account(request: Request):
    user, r = login_required(request)
    if r:
        return r
    msg = None
    if request.method == "POST":
        f = await request.form()
        new = str(f.get("new", ""))
        if not csrf_ok(user, f):
            msg = "Ungültige Anfrage."
        elif not sec.verify_pw(str(f.get("old", "")), user["pw"]):
            msg = "Aktuelles Passwort falsch."
        elif len(new) < 12 or new != str(f.get("new2", "")):
            msg = "Neues Passwort: mindestens 12 Zeichen und beide Eingaben gleich."
        else:
            with request.state.db as c:
                c.execute("UPDATE users SET pw=? WHERE id=?", (sec.hash_pw(new), user["id"]))
                c.execute("DELETE FROM sessions WHERE user_id=? AND token<>?", (user["id"], user["token"]))
            db.audit(request.state.db, user["name"], "password_changed")
            msg = "Passwort geändert. Andere Sitzungen wurden beendet."
    return page(request, "account.html", user, msg=msg, active="account")


# ---------------------------------------------------------------- Auswertung
async def overview(request: Request):
    user, r = login_required(request)
    if r:
        return r
    c = request.state.db
    cards = []
    for s in visible_sites(c, user):
        tz = ZoneInfo(s["tz"])
        today = datetime.now(tz).date()
        rep = reports.build(c, s["id"], tz, today - timedelta(days=13), today, detail=False)
        vis = [rep["per"][d]["vis"] for d in rep["days"]]
        week = sum(rep["per"][d]["pv"] for d in rep["days"][-7:])
        cards.append(dict(site=s, spark=charts.spark(vis), today=vis[-1], yesterday=vis[-2], week_pv=week))
    return page(request, "overview.html", user, cards=cards, active="home")


def _range(request: Request, tz):
    q = request.query_params
    today = datetime.now(tz).date()
    try:
        if q.get("from") and q.get("to"):
            d0, d1 = date.fromisoformat(q["from"]), date.fromisoformat(q["to"])
            label = "custom"
        else:
            r = int(q.get("r", "30"))
            r = r if r in (7, 30, 90, 365) else 30
            d0, d1, label = today - timedelta(days=r - 1), today, str(r)
    except ValueError:
        d0, d1, label = today - timedelta(days=29), today, "30"
    d1 = min(d1, today)
    if d0 > d1 or (d1 - d0).days > 400:
        d0, d1, label = today - timedelta(days=29), today, "30"
    return d0, d1, label


async def site_report(request: Request):
    user, r = login_required(request)
    if r:
        return r
    c = request.state.db
    s = get_site(c, user, int(request.path_params["id"]))
    if not s:
        return page(request, "error.html", user, msg="Seite nicht gefunden.", status=404)
    tz = ZoneInfo(s["tz"])
    d0, d1, label = _range(request, tz)
    rep = reports.build(c, s["id"], tz, d0, d1)
    span = (d1 - d0).days + 1
    prev = reports.build(c, s["id"], tz, d0 - timedelta(days=span), d0 - timedelta(days=1), detail=False)
    kpis = []
    for title, key, fmt in (("Tagesbesucher (Summe)", "vis", _n), ("Seitenaufrufe", "pv", _n),
                            ("Einstiege (≈ Besuche)", "ent", _n), ("Ø Verweildauer pro Seite", "avg", _dur)):
        cur, old = rep["tot"][key], prev["tot"][key]
        kpis.append(dict(title=title, value=fmt(cur), delta=reports.delta(cur, old)))
    vis = [rep["per"][d]["vis"] for d in rep["days"]]
    pv = [rep["per"][d]["pv"] for d in rep["days"]]
    rows = [dict(day=d, **rep["per"][d]) for d in rep["days"]]
    return page(request, "site.html", user, site=s, rep=rep, kpis=kpis, label=label, d0=d0, d1=d1,
                chart=charts.daily(rep["days"], vis, pv),
                hourchart=charts.bars([f"{h:02d}" for h in range(24)], rep["hours"]),
                flow=charts.flow(rep["flow"]),
                bars={k: charts.share_bars(rep[k]) for k in ("devices", "browsers", "systems", "langs")},
                rows=rows[::-1], empty=(rep["tot"]["pv"] == 0), active="home")


def _csv_cell(v):
    v = str(v)
    return "'" + v if v[:1] in "=+-@\t\r" else v  # Schutz vor Formel-Injektion in Tabellenkalkulationen


async def site_csv(request: Request):
    user, r = login_required(request)
    if r:
        return r
    c = request.state.db
    s = get_site(c, user, int(request.path_params["id"]))
    if not s:
        return PlainTextResponse("Nicht gefunden", status_code=404)
    d0, d1, _ = _range(request, ZoneInfo(s["tz"]))
    rep = reports.build(c, s["id"], ZoneInfo(s["tz"]), d0, d1)
    kind = request.query_params.get("t", "days")
    out = io.StringIO()
    w = csv.writer(out, delimiter=";")
    if kind == "pages":
        w.writerow(["Pfad", "Aufrufe", "Einstiege", "Ausstiege", "Ausstiegsrate", "Verweildauer_s"])
        for p in rep["pages"]:
            w.writerow([_csv_cell(p["path"]), p["pv"], p["ent"], p["exits"],
                        "" if p["exit_rate"] is None else round(p["exit_rate"], 3),
                        "" if p["avg"] is None else round(p["avg"], 1)])
    elif kind == "sources":
        w.writerow(["Quelle", "Kanal", "Einstiege"])
        for x in rep["sources"]:
            w.writerow([_csv_cell(x["ref"]), x["channel"], x["n"]])
    else:
        kind = "days"
        w.writerow(["Datum", "Tagesbesucher", "Aufrufe", "Einstiege", "Verweildauer_s_Summe", "Messungen"])
        for d in rep["days"]:
            p = rep["per"][d]
            w.writerow([d.isoformat(), p["vis"], p["pv"], p["ent"], p["dws"], p["dwn"]])
    fn = re.sub(r"[^\w-]", "_", s["name"])[:40] + "-" + kind + ".csv"
    return Response("﻿" + out.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{fn}"'})


# ---------------------------------------------------------------- Verwaltung: Seiten
DOMAIN_RE = re.compile(r"^[a-z0-9]([a-z0-9.-]{0,98}[a-z0-9])?$")


def snippets(s):
    host = s["domain"]
    bare = host[4:] if host.startswith("www.") else host
    origins = sorted({f"https://{host}", f"https://{bare}", f"https://www.{bare}"})
    script = f'<script defer src="https://{host}/a/t.js" data-k="{s["site_key"]}"></script>'
    cfg = ("<?php\nreturn [\n"
           f"    'site_id'  => '{s['sid']}',\n    'site_key' => '{s['site_key']}',\n    'secret'   => '{s['secret']}',\n"
           "    'origins'  => [" + ", ".join(f"'{o}'" for o in origins) + "],\n"
           f"    'tz'       => '{s['tz']}',\n    'visitor_mode' => 'hash',\n    'device_stats' => true,\n];\n")
    return script, cfg


async def admin_sites(request: Request):
    user, r = login_required(request, admin=True)
    if r:
        return r
    c = request.state.db
    err = None
    if request.method == "POST":
        f = await request.form()
        name, domain = str(f.get("name", "")).strip()[:60], str(f.get("domain", "")).strip().lower()
        tz = str(f.get("tz", "Europe/Berlin")).strip()
        endpoint = str(f.get("endpoint", "")).strip() or f"https://{domain}/a/x.php"
        if not csrf_ok(user, f):
            err = "Ungültige Anfrage."
        elif not name or not DOMAIN_RE.match(domain) or tz not in available_timezones() or not endpoint.startswith(("https://", "http://")):
            err = "Bitte Name, Domain (z. B. www.beispiel.de), Zeitzone und Endpoint prüfen."
        else:
            with c:
                cur = c.execute("INSERT INTO sites(name,domain,endpoint,sid,site_key,secret,tz,created) VALUES(?,?,?,?,?,?,?,?)",
                                (name, domain, endpoint, secrets.token_hex(4), secrets.token_hex(12), secrets.token_hex(32), tz, int(time.time())))
            db.audit(c, user["name"], "site_created", name)
            return RedirectResponse(f"/admin/sites/{cur.lastrowid}", status_code=303)
    sites = c.execute("SELECT * FROM sites ORDER BY name").fetchall()
    return page(request, "admin_sites.html", user, sites=sites, err=err, active="admin")


async def admin_site(request: Request):
    user, r = login_required(request, admin=True)
    if r:
        return r
    c = request.state.db
    s = c.execute("SELECT * FROM sites WHERE id=?", (int(request.path_params["id"]),)).fetchone()
    if not s:
        return page(request, "error.html", user, msg="Seite nicht gefunden.", status=404)
    script, cfg = snippets(s)
    return page(request, "admin_site.html", user, site=s, script=script, cfg=cfg, flash=request.query_params.get("m"),
                active="admin")


async def admin_site_op(request: Request):
    user, r = login_required(request, admin=True)
    if r:
        return r
    f = await request.form()
    c = request.state.db
    sid, op = int(request.path_params["id"]), request.path_params["op"]
    s = c.execute("SELECT * FROM sites WHERE id=?", (sid,)).fetchone()
    if not s or not csrf_ok(user, f):
        return page(request, "error.html", user, msg="Ungültige Anfrage.", status=400)
    msg = ""
    if op in ("pause", "resume"):
        with c:
            c.execute("UPDATE sites SET active=? WHERE id=?", (1 if op == "resume" else 0, sid))
        msg = "Import pausiert." if op == "pause" else "Import aktiv."
    elif op == "rotate":
        with c:
            c.execute("UPDATE sites SET secret=? WHERE id=?", (secrets.token_hex(32), sid))
        msg = "Neues Secret erzeugt. Jetzt die neue config.php auf den Webspace hochladen, sonst schlägt der Import fehl."
    elif op == "import":
        msg = await asyncio.to_thread(lambda: importer.pull_site(db.connect(), s))
    elif op == "wipe" and f.get("confirm") == s["name"]:
        with c:
            c.execute("DELETE FROM counters WHERE site=?", (sid,))
            c.execute("UPDATE sites SET last_h=0 WHERE id=?", (sid,))
        msg = "Alle Daten dieser Seite gelöscht."
    elif op == "delete" and f.get("confirm") == s["name"]:
        with c:
            c.execute("DELETE FROM sites WHERE id=?", (sid,))
        db.audit(c, user["name"], "site_deleted", s["name"])
        return RedirectResponse("/admin/sites", status_code=303)
    elif op in ("wipe", "delete"):
        msg = "Zum Bestätigen den Namen der Seite exakt eintippen."
    db.audit(c, user["name"], f"site_{op}", s["name"])
    from urllib.parse import quote
    return RedirectResponse(f"/admin/sites/{sid}?m={quote(msg)}", status_code=303)


# ---------------------------------------------------------------- Verwaltung: Benutzer
async def admin_users(request: Request):
    user, r = login_required(request, admin=True)
    if r:
        return r
    c = request.state.db
    err = None
    if request.method == "POST":
        f = await request.form()
        name, pw = str(f.get("name", "")).strip(), str(f.get("password", ""))
        if not csrf_ok(user, f):
            err = "Ungültige Anfrage."
        elif not re.match(r"^[\w.@-]{3,40}$", name) or len(pw) < 12:
            err = "Name: 3–40 Zeichen (Buchstaben, Zahlen, . _ - @). Passwort: mindestens 12 Zeichen."
        elif c.execute("SELECT 1 FROM users WHERE name=?", (name,)).fetchone():
            err = "Benutzername existiert bereits."
        else:
            totp = sec.new_totp_secret()
            with c:
                cur = c.execute("INSERT INTO users(name,pw,totp,admin) VALUES(?,?,?,?)",
                                (name, sec.hash_pw(pw), totp, 1 if f.get("admin") else 0))
                for sid in f.getlist("sites"):
                    if str(sid).isdigit():
                        c.execute("INSERT OR IGNORE INTO access(user_id,site_id) SELECT ?, id FROM sites WHERE id=?", (cur.lastrowid, int(sid)))
            db.audit(c, user["name"], "user_created", name)
            return page(request, "secret.html", user, uname=name, totp=totp, uri=sec.otpauth_uri(name, totp), active="admin")
    users = c.execute("SELECT * FROM users ORDER BY name").fetchall()
    access = {u["id"]: {x["site_id"] for x in c.execute("SELECT site_id FROM access WHERE user_id=?", (u["id"],))} for u in users}
    sites = c.execute("SELECT id,name FROM sites ORDER BY name").fetchall()
    return page(request, "admin_users.html", user, users=users, access=access, sites=sites, err=err, active="admin")


async def admin_user_op(request: Request):
    user, r = login_required(request, admin=True)
    if r:
        return r
    f = await request.form()
    c = request.state.db
    uid, op = int(request.path_params["id"]), request.path_params["op"]
    u = c.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not u or not csrf_ok(user, f):
        return page(request, "error.html", user, msg="Ungültige Anfrage.", status=400)
    if op == "access":
        with c:
            c.execute("DELETE FROM access WHERE user_id=?", (uid,))
            for sid in f.getlist("sites"):
                if str(sid).isdigit():
                    c.execute("INSERT OR IGNORE INTO access(user_id,site_id) SELECT ?, id FROM sites WHERE id=?", (uid, int(sid)))
    elif op == "reset":
        totp = sec.new_totp_secret()
        with c:
            c.execute("UPDATE users SET totp=?, last_step=0, fails=0, locked_until=0 WHERE id=?", (totp, uid))
            c.execute("DELETE FROM sessions WHERE user_id=?", (uid,))
        db.audit(c, user["name"], "totp_reset", u["name"])
        return page(request, "secret.html", user, uname=u["name"], totp=totp, uri=sec.otpauth_uri(u["name"], totp), active="admin")
    elif op == "delete" and uid != user["id"]:
        with c:
            c.execute("DELETE FROM users WHERE id=?", (uid,))
        db.audit(c, user["name"], "user_deleted", u["name"])
    return RedirectResponse("/admin/users", status_code=303)


async def static_css(request: Request):
    return FileResponse(os.path.join(BASE, "static", "app.css"), media_type="text/css",
                        headers={"Cache-Control": "public, max-age=3600"})


# ---------------------------------------------------------------- Hintergrund-Import
@asynccontextmanager
async def lifespan(app):
    task = None
    if IMPORT_MIN > 0:
        async def loop():
            await asyncio.sleep(5)
            while True:
                try:
                    await asyncio.to_thread(lambda: importer.pull_all(db.connect()))
                except Exception:
                    pass
                await asyncio.sleep(IMPORT_MIN * 60)
        task = asyncio.create_task(loop())
    yield
    if task:
        task.cancel()


app = Starlette(
    routes=[
        Route("/", overview), Route("/login", login, methods=["GET", "POST"]), Route("/logout", logout, methods=["POST"]),
        Route("/account", account, methods=["GET", "POST"]),
        Route("/s/{id:int}", site_report), Route("/s/{id:int}/export.csv", site_csv),
        Route("/admin/sites", admin_sites, methods=["GET", "POST"]), Route("/admin/sites/{id:int}", admin_site),
        Route("/admin/sites/{id:int}/{op}", admin_site_op, methods=["POST"]),
        Route("/admin/users", admin_users, methods=["GET", "POST"]),
        Route("/admin/users/{id:int}/{op}", admin_user_op, methods=["POST"]),
        Route("/static/app.css", static_css),
    ],
    middleware=[Middleware(Guard)],
    lifespan=lifespan,
)
