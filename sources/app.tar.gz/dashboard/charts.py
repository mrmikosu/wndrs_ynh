"""Diagramme als Inline-SVG (kein JavaScript nötig). Farben kommen aus der CSS-Datei (Klassen)."""
import math
from html import escape


def _num(n: int) -> str:
    return f"{n:,}".replace(",", ".")


def _compact(n: float) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:g}M"
    if n >= 1000:
        return f"{n / 1000:g}K"
    return f"{n:g}"


def _ticks(vmax):
    if vmax <= 0:
        return 1, [0, 1]
    base = 1
    while True:
        for k in (1, 2, 5):
            s = k * base
            if vmax / s <= 5:
                top = math.ceil(vmax / s) * s
                return top, [i * s for i in range(int(top / s) + 1)]
        base *= 10


def _bar(x, y, w, y0, r=4):
    """Balken mit 4px gerundetem Ende oben und gerader Basis."""
    h = y0 - y
    if h <= 0:
        return ""
    r = min(r, w / 2, h) if w >= 8 else 0
    if r <= 0:
        return f"M{x:.1f},{y0:.1f}V{y:.1f}H{x + w:.1f}V{y0:.1f}Z"
    return (f"M{x:.1f},{y0:.1f}V{y + r:.1f}Q{x:.1f},{y:.1f} {x + r:.1f},{y:.1f}H{x + w - r:.1f}"
            f"Q{x + w:.1f},{y:.1f} {x + w:.1f},{y + r:.1f}V{y0:.1f}Z")


def daily(days, vis, pv, w=760, h=250):
    """Balken: Tagesbesucher, Linie: Seitenaufrufe, eine gemeinsame Achse."""
    ml, mr, mt, mb = 44, 14, 14, 28
    pw, ph = w - ml - mr, h - mt - mb
    top, ticks = _ticks(max(list(vis) + list(pv) + [0]))
    y = lambda v: mt + ph - v / top * ph
    band = pw / max(1, len(days))
    bw = max(1.0, min(24.0, band - 2))
    o = [f'<svg class="chart" viewBox="0 0 {w} {h}" role="img" aria-label="Tagesbesucher und Seitenaufrufe pro Tag">']
    for t in ticks:
        o.append(f'<line class="grid" x1="{ml}" x2="{w - mr}" y1="{y(t):.1f}" y2="{y(t):.1f}"/>'
                 f'<text class="tick" x="{ml - 6}" y="{y(t) + 4:.1f}" text-anchor="end">{_compact(t)}</text>')
    pts = []
    for i, d in enumerate(days):
        cx = ml + band * i + band / 2
        o.append(f'<path class="s1" d="{_bar(cx - bw / 2, y(vis[i]), bw, y(0))}"/>')
        pts.append((cx, y(pv[i])))
    step = max(1, math.ceil(len(days) / 8))
    for i in range(0, len(days), step):
        cx = ml + band * i + band / 2
        o.append(f'<text class="tick" x="{cx:.1f}" y="{h - 8}" text-anchor="middle">{days[i].strftime("%d.%m.")}</text>')
    if len(pts) > 1:
        o.append('<polyline class="l2" points="%s"/>' % " ".join(f"{x:.1f},{yy:.1f}" for x, yy in pts))
    if pts:
        o.append(f'<circle class="dot2" cx="{pts[-1][0]:.1f}" cy="{pts[-1][1]:.1f}" r="4"/>')
    for i, d in enumerate(days):  # große, unsichtbare Trefferflächen mit Tooltip
        o.append(f'<rect class="hit" x="{ml + band * i:.1f}" y="{mt}" width="{band:.1f}" height="{ph}">'
                 f'<title>{d.strftime("%d.%m.%Y")}: {_num(vis[i])} Besucher, {_num(pv[i])} Aufrufe</title></rect>')
    o.append("</svg>")
    return "".join(o)


def bars(labels, values, w=760, h=170, unit="Aufrufe"):
    ml, mr, mt, mb = 44, 14, 10, 24
    pw, ph = w - ml - mr, h - mt - mb
    top, ticks = _ticks(max(list(values) + [0]))
    y = lambda v: mt + ph - v / top * ph
    band = pw / len(values)
    bw = min(24.0, band - 2)
    o = [f'<svg class="chart" viewBox="0 0 {w} {h}" role="img" aria-label="{unit} nach Tageszeit">']
    for t in ticks:
        o.append(f'<line class="grid" x1="{ml}" x2="{w - mr}" y1="{y(t):.1f}" y2="{y(t):.1f}"/>'
                 f'<text class="tick" x="{ml - 6}" y="{y(t) + 4:.1f}" text-anchor="end">{_compact(t)}</text>')
    for i, v in enumerate(values):
        cx = ml + band * i + band / 2
        o.append(f'<path class="s1" d="{_bar(cx - bw / 2, y(v), bw, y(0))}"/>')
        if i % 3 == 0:
            o.append(f'<text class="tick" x="{cx:.1f}" y="{h - 6}" text-anchor="middle">{labels[i]}</text>')
        o.append(f'<rect class="hit" x="{ml + band * i:.1f}" y="{mt}" width="{band:.1f}" height="{ph}">'
                 f'<title>{labels[i]}: {_num(v)} {unit}</title></rect>')
    o.append("</svg>")
    return "".join(o)


def spark(values, w=150, h=38):
    """Kleine Verlaufslinie für die Übersicht (ein Wert pro Tag)."""
    if not values:
        return ""
    top = max(max(values), 1)
    n = len(values)
    px = lambda i: 4 + (w - 8) * (i / max(1, n - 1))
    py = lambda v: h - 6 - (h - 12) * v / top
    pts = " ".join(f"{px(i):.1f},{py(v):.1f}" for i, v in enumerate(values))
    area = f"{px(0):.1f},{h - 6} {pts} {px(n - 1):.1f},{h - 6}"
    return (f'<svg class="spark" viewBox="0 0 {w} {h}" role="img" aria-label="Besucher der letzten {n} Tage">'
            f'<polygon class="wash1" points="{area}"/><polyline class="l1" points="{pts}"/>'
            f'<circle class="dot1" cx="{px(n - 1):.1f}" cy="{py(values[-1]):.1f}" r="4"/></svg>')


def _short(t: str, n: int) -> str:
    return t if len(t) <= n else t[: n - 1] + "…"


def share_bars(items, w=380):
    """Waagerechte Balken mit Wert und Anteil am Ende. items = [(Name, Anzahl), ...]"""
    total = sum(v for _, v in items)
    if not total:
        return '<p class="sub">Keine Daten.</p>'
    row, lw, rw = 28, 120, 92
    top = max(v for _, v in items)
    pw = w - lw - rw
    h = row * len(items) + 4
    o = [f'<svg class="chart" viewBox="0 0 {w} {h}" role="img" aria-label="Anteile">']
    for i, (name, v) in enumerate(items):
        y = 2 + row * i
        bw = max(2.0, v / top * pw)
        by, bh, r = y + 5, 16, 4
        x0 = lw
        o.append(f'<text class="lbl" x="{lw - 8}" y="{y + 18}" text-anchor="end">{escape(_short(str(name), 16))}</text>')
        o.append(f'<path class="s1" d="M{x0},{by}H{x0 + bw - r:.1f}Q{x0 + bw:.1f},{by} {x0 + bw:.1f},{by + r}'
                 f'V{by + bh - r}Q{x0 + bw:.1f},{by + bh} {x0 + bw - r:.1f},{by + bh}H{x0}Z"/>')
        o.append(f'<text class="val" x="{x0 + bw + 8:.1f}" y="{y + 18}">{_num(v)} · {v / total * 100:.0f} %</text>')
        o.append(f'<rect class="hit" x="0" y="{y}" width="{w}" height="{row}"><title>{escape(str(name))}: {_num(v)} ({v / total * 100:.1f} %)</title></rect>')
    o.append("</svg>")
    return "".join(o)


def flow(links, w=760):
    """Fluss von Seite zu Seite: links = [(von, nach, n)]. Zwei Spalten, Bandbreite = Anzahl."""
    if not links:
        return '<p class="sub">Keine Übergänge erfasst.</p>'
    lw, nw, gap, minh = 190, 10, 8, 16
    left, right = {}, {}
    for a, b, n in links:
        left[a] = left.get(a, 0) + n
        right[b] = right.get(b, 0) + n
    lnodes = sorted(left, key=lambda k: -left[k])
    rnodes = sorted(right, key=lambda k: -right[k])
    total = sum(n for _, _, n in links)
    avail = max(220, 34 * max(len(lnodes), len(rnodes)))
    scale = avail / total

    def layout(nodes, tot):
        pos, y = {}, 10.0
        for k in nodes:
            hh = max(minh, tot[k] * scale)
            pos[k] = [y, hh, y]  # oben, Höhe, Füllstand für die Bänder
            y += hh + gap
        return pos, y
    lp, ly = layout(lnodes, left)
    rp, ry = layout(rnodes, right)
    h = int(max(ly, ry) + 6)
    xl, xr = lw, w - lw - nw
    o = [f'<svg class="chart" viewBox="0 0 {w} {h}" role="img" aria-label="Wege von Seite zu Seite">']
    lorder = {k: i for i, k in enumerate(lnodes)}
    rorder = {k: i for i, k in enumerate(rnodes)}
    # Bänder in Reihenfolge von Ziel/Quelle, damit sich möglichst wenig kreuzt
    for a, b, n in sorted(links, key=lambda l: (lorder[l[0]], rorder[l[1]])):
        t = n * scale
        y1 = lp[a][2]; lp[a][2] += t
        y2 = rp[b][2]; rp[b][2] += t
        xm = (xl + nw + xr) / 2
        d = (f"M{xl + nw},{y1:.1f}C{xm:.1f},{y1:.1f} {xm:.1f},{y2:.1f} {xr},{y2:.1f}"
             f"V{y2 + t:.1f}C{xm:.1f},{y2 + t:.1f} {xm:.1f},{y1 + t:.1f} {xl + nw},{y1 + t:.1f}Z")
        o.append(f'<path class="flowlink" d="{d}"><title>{escape(a)} → {escape(b)}: {_num(n)}</title></path>')
    for k, (y, hh, _) in lp.items():
        o.append(f'<rect class="s1" x="{xl}" y="{y:.1f}" width="{nw}" height="{hh:.1f}"/>'
                 f'<text class="lbl" x="{xl - 8}" y="{y + hh / 2 + 4:.1f}" text-anchor="end">{escape(_short(k, 28))}</text>')
    for k, (y, hh, _) in rp.items():
        o.append(f'<rect class="s1" x="{xr}" y="{y:.1f}" width="{nw}" height="{hh:.1f}"/>'
                 f'<text class="lbl" x="{xr + nw + 8}" y="{y + hh / 2 + 4:.1f}">{escape(_short(k, 28))}</text>')
    o.append("</svg>")
    return "".join(o)
