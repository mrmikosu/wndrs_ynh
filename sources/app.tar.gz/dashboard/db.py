"""Datenbank des Dashboards (SQLite, nur Standardbibliothek)."""
import os
import sqlite3

DB_PATH = os.environ.get("DASH_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "dashboard.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS sites(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, domain TEXT NOT NULL, endpoint TEXT NOT NULL,
  sid TEXT NOT NULL UNIQUE, site_key TEXT NOT NULL, secret TEXT NOT NULL,
  tz TEXT NOT NULL DEFAULT 'Europe/Berlin', active INTEGER NOT NULL DEFAULT 1,
  created INTEGER NOT NULL, last_h INTEGER NOT NULL DEFAULT 0, last_ok INTEGER, last_err TEXT);
CREATE TABLE IF NOT EXISTS counters(
  site INTEGER NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  h INTEGER NOT NULL, m TEXT NOT NULL, a TEXT NOT NULL, b TEXT NOT NULL, n INTEGER NOT NULL,
  PRIMARY KEY(site, h, m, a, b)) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, pw TEXT NOT NULL, totp TEXT NOT NULL,
  admin INTEGER NOT NULL DEFAULT 0, fails INTEGER NOT NULL DEFAULT 0,
  locked_until INTEGER NOT NULL DEFAULT 0, last_step INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS access(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  site_id INTEGER NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  PRIMARY KEY(user_id, site_id));
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf TEXT NOT NULL, expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS audit(ts INTEGER NOT NULL, user TEXT, action TEXT, detail TEXT);
"""


def connect() -> sqlite3.Connection:
    d = os.path.dirname(DB_PATH)
    os.makedirs(d, mode=0o700, exist_ok=True)
    new = not os.path.exists(DB_PATH)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript(SCHEMA)
    if new:
        os.chmod(DB_PATH, 0o600)  # enthält Site-Secrets und Passwort-Hashes
    return conn


def audit(conn, user, action, detail=""):
    import time
    with conn:
        conn.execute("INSERT INTO audit(ts,user,action,detail) VALUES(?,?,?,?)",
                     (int(time.time()), user, action, detail[:300]))
