"""Verwaltung auf der Kommandozeile.
   python manage.py create-admin NAME     ersten Administrator anlegen (Passwort wird abgefragt)
   python manage.py reset-totp NAME       neuen 2FA-Schlüssel erzeugen
   python manage.py ensure-site NAME DOMAIN ENDPOINT SID SITE_KEY SECRET [TZ]
                                          Seite anlegen/aktualisieren (Yunohost install)
   python manage.py import                alle Seiten sofort abrufen
"""
import getpass
import os
import sys
import time

import db
import importer
import security as sec


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    c = db.connect()
    cmd = sys.argv[1]
    if cmd == "create-admin" and len(sys.argv) == 3:
        name = sys.argv[2]
        # Non-interactive (Yunohost install): DASHBOARD_ADMIN_PASSWORD env, min 12 chars
        env_pw = (os.environ.get("DASHBOARD_ADMIN_PASSWORD") or "").strip()
        if env_pw:
            pw = env_pw
            if len(pw) < 12:
                print("Passwort zu kurz (mind. 12 Zeichen).")
                return 1
        else:
            pw = getpass.getpass("Passwort (mind. 12 Zeichen): ")
            if len(pw) < 12 or pw != getpass.getpass("Wiederholen: "):
                print("Passwort zu kurz oder nicht identisch.")
                return 1
        totp = sec.new_totp_secret()
        with c:
            c.execute("INSERT INTO users(name,pw,totp,admin) VALUES(?,?,?,1)", (name, sec.hash_pw(pw), totp))
        uri = sec.otpauth_uri(name, totp)
        print("Benutzer angelegt. 2FA-Schlüssel für die Authenticator-App (manuell eingeben):\n  %s\nURI: %s" % (totp, uri))
        # Machine-readable lines for PHP admin panel / Yunohost install capture
        print("TOTP_USER=%s" % name)
        print("TOTP_SECRET=%s" % totp)
        print("TOTP_URI=%s" % uri)
    elif cmd == "reset-totp" and len(sys.argv) == 3:
        totp = sec.new_totp_secret()
        with c:
            n = c.execute("UPDATE users SET totp=?, last_step=0, fails=0, locked_until=0 WHERE name=?", (totp, sys.argv[2])).rowcount
        if not n:
            print("Benutzer nicht gefunden.")
        else:
            uri = sec.otpauth_uri(sys.argv[2], totp)
            print("Neuer 2FA-Schlüssel: %s" % totp)
            print("TOTP_USER=%s" % sys.argv[2])
            print("TOTP_SECRET=%s" % totp)
            print("TOTP_URI=%s" % uri)
    elif cmd == "ensure-site" and len(sys.argv) >= 8:
        name, domain, endpoint, sid, site_key, secret = sys.argv[2:8]
        tz = sys.argv[8] if len(sys.argv) > 8 else "Europe/Berlin"
        name, domain = name.strip()[:60], domain.strip().lower()
        endpoint, sid = endpoint.strip(), sid.strip()
        site_key, secret, tz = site_key.strip(), secret.strip(), tz.strip() or "Europe/Berlin"
        if not all((name, domain, endpoint, sid, site_key, secret)):
            print("ensure-site: missing argument")
            return 1
        if not endpoint.startswith(("https://", "http://")):
            print("ensure-site: endpoint must be http(s) URL")
            return 1
        row = c.execute("SELECT id FROM sites WHERE sid=? OR domain=?", (sid, domain)).fetchone()
        with c:
            if row:
                c.execute(
                    "UPDATE sites SET name=?, domain=?, endpoint=?, sid=?, site_key=?, secret=?, tz=?, active=1 WHERE id=?",
                    (name, domain, endpoint, sid, site_key, secret, tz, row["id"]),
                )
                print("SITE_UPDATED id=%s sid=%s" % (row["id"], sid))
            else:
                cur = c.execute(
                    "INSERT INTO sites(name,domain,endpoint,sid,site_key,secret,tz,created) VALUES(?,?,?,?,?,?,?,?)",
                    (name, domain, endpoint, sid, site_key, secret, tz, int(time.time())),
                )
                print("SITE_CREATED id=%s sid=%s" % (cur.lastrowid, sid))
    elif cmd == "import":
        print("\n".join(importer.pull_all(c)) or "Keine aktive Seite.")
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
