"""Verwaltung auf der Kommandozeile.
   python manage.py create-admin NAME     ersten Administrator anlegen (Passwort wird abgefragt)
   python manage.py reset-totp NAME       neuen 2FA-Schlüssel erzeugen
   python manage.py import                alle Seiten sofort abrufen
"""
import getpass
import os
import sys

import db
import importer
import security as sec


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    c = db.connect()
    cmd = sys.argv[1]
    if cmd == "create-admin" and len(sys.argv) == 3:
        name = sys.argv[2]
        # Non-interactive (Yunohost install): DASHBOARD_ADMIN_PASSWORD env, min 12 chars
        env_pw = (os.environ.get("DASHBOARD_ADMIN_PASSWORD") or "").strip()
        if env_pw:
            pw = env_pw
            if len(pw) < 12:
                print("Passwort zu kurz (mind. 12 Zeichen).")
                return 1
        else:
            pw = getpass.getpass("Passwort (mind. 12 Zeichen): ")
            if len(pw) < 12 or pw != getpass.getpass("Wiederholen: "):
                print("Passwort zu kurz oder nicht identisch.")
                return 1
        totp = sec.new_totp_secret()
        with c:
            c.execute("INSERT INTO users(name,pw,totp,admin) VALUES(?,?,?,1)", (name, sec.hash_pw(pw), totp))
        print("Benutzer angelegt. 2FA-Schlüssel für die Authenticator-App (manuell eingeben):\n  %s\nURI: %s" % (totp, sec.otpauth_uri(name, totp)))
    elif cmd == "reset-totp" and len(sys.argv) == 3:
        totp = sec.new_totp_secret()
        with c:
            n = c.execute("UPDATE users SET totp=?, last_step=0, fails=0, locked_until=0 WHERE name=?", (totp, sys.argv[2])).rowcount
        print("Neuer 2FA-Schlüssel: %s" % totp if n else "Benutzer nicht gefunden.")
    elif cmd == "import":
        print("\n".join(importer.pull_all(c)) or "Keine aktive Seite.")
    else:
        print(__doc__)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
