"""Holt die Zähler von den Webspaces (Pull, HMAC-signiert). Aufruf: python importer.py"""
import hashlib
import hmac
import json
import os
import re
import time
import urllib.error
import urllib.request
from urllib.parse import urlencode, urlsplit

import db

MAX_BYTES = 40 * 1024 * 1024
METRICS = {"pv", "vis", "ent", "tr", "dws", "dwn", "clk", "utm", "dev", "br", "os", "lang", "bot"}
ALLOW_HTTP = os.environ.get("DASH_ALLOW_HTTP") == "1"  # nur für lokale Tests


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def sign(secret: str, sid: str, since: int, ts: int) -> str:
    return hmac.new(secret.encode(), ("%s|%d|%d" % (sid, since, ts)).encode(), hashlib.sha256).hexdigest()


def _clean(rows):
    out = []
    for r in rows:
        if not (isinstance(r, list) and len(r) == 5):
            continue
        h, m, a, b, n = r
        if (isinstance(h, int) and h % 3600 == 0 and h > 0 and m in METRICS and isinstance(a, str)
                and isinstance(b, str) and isinstance(n, int) and 0 <= n < 10 ** 9
                and len(a) <= 200 and len(b) <= 200):
            out.append((h, m, a, b, n))
    return out


def pull_site(conn, site) -> str:
    """Importiert eine Seite. Gibt eine Statuszeile zurück; Fehler werden in der Seite vermerkt."""
    try:
        sp = urlsplit(site["endpoint"])
        if sp.scheme != "https" and not (ALLOW_HTTP and sp.scheme == "http"):
            raise ValueError("Endpoint muss https:// verwenden")
        since = max(0, site["last_h"] - 2 * 3600)
        ts = int(time.time())
        q = urlencode({"site": site["sid"], "since": since, "ts": ts, "sig": sign(site["secret"], site["sid"], since, ts)})
        url = site["endpoint"] + ("&" if "?" in site["endpoint"] else "?") + q
        req = urllib.request.Request(url, headers={"User-Agent": "besucher-analyse-importer/1"})
        with urllib.request.build_opener(_NoRedirect).open(req, timeout=25) as r:
            data = r.read(MAX_BYTES + 1)
        if len(data) > MAX_BYTES:
            raise ValueError("Antwort zu groß")
        j = json.loads(data)
        if not isinstance(j, dict) or j.get("site") != site["sid"] or not isinstance(j.get("rows"), list):
            raise ValueError("Unerwartete Antwort")
        rows = _clean(j["rows"])
        last_h = max([site["last_h"]] + [r[0] for r in rows])
        with conn:
            conn.executemany("INSERT OR REPLACE INTO counters(site,h,m,a,b,n) VALUES(?,?,?,?,?,?)",
                             [(site["id"], *r) for r in rows])
            conn.execute("UPDATE sites SET last_h=?, last_ok=?, last_err=NULL WHERE id=?", (last_h, int(time.time()), site["id"]))
        return "%s: %d Zeilen" % (site["name"], len(rows))
    except Exception as e:  # Fehlerdetails ins Dashboard, nicht abstürzen
        msg = re.sub(r"[^\w .:/()-]", "", "%s: %s" % (type(e).__name__, e))[:200]
        with conn:
            conn.execute("UPDATE sites SET last_err=? WHERE id=?", (msg, site["id"]))
        return "%s: FEHLER %s" % (site["name"], msg)


def pull_all(conn):
    return [pull_site(conn, s) for s in conn.execute("SELECT * FROM sites WHERE active=1").fetchall()]


if __name__ == "__main__":
    c = db.connect()
    for line in pull_all(c):
        print(line)
