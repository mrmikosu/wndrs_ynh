"""Auswertung der Stundenzähler zu Berichten für den gewählten Zeitraum."""
from collections import defaultdict
from datetime import datetime, time, timedelta

SEARCH = {"google", "bing", "duckduckgo", "ecosia", "startpage", "qwant", "yahoo", "yandex", "baidu", "brave"}
SOCIAL = {"facebook", "instagram", "linkedin", "lnkd", "youtube", "youtu", "reddit", "pinterest", "tiktok",
          "whatsapp", "telegram", "threads", "mastodon", "bsky", "t.co", "x.com", "twitter"}


def channel(ref: str) -> str:
    if ref in ("(direkt)", ""):
        return "Direkt"
    labels = set(ref.split("."))
    if labels & SEARCH:
        return "Suche"
    if labels & SOCIAL or ref in ("t.co", "x.com"):
        return "Social"
    return "Verweis"


def _bounds(d0, d1, tz):
    start = int(datetime.combine(d0, time.min, tzinfo=tz).timestamp())
    end = int(datetime.combine(d1 + timedelta(days=1), time.min, tzinfo=tz).timestamp())
    return start, end


def build(conn, site_id, tz, d0, d1, detail=True):
    days = [d0 + timedelta(i) for i in range((d1 - d0).days + 1)]
    per = {d: dict(vis=0, pv=0, ent=0, dws=0, dwn=0) for d in days}
    pages = defaultdict(lambda: dict(pv=0, ent=0, out=0, dws=0, dwn=0))
    trans, src, utm, clk = defaultdict(int), defaultdict(int), defaultdict(int), defaultdict(int)
    dev = {k: defaultdict(int) for k in ("dev", "br", "os", "lang")}
    bots = 0
    hours = [0] * 24
    start, end = _bounds(d0, d1, tz)
    cache = {}
    for h, m, a, b, n in conn.execute("SELECT h,m,a,b,n FROM counters WHERE site=? AND h>=? AND h<?", (site_id, start, end)):
        if h not in cache:
            lt = datetime.fromtimestamp(h, tz)
            cache[h] = (lt.date(), lt.hour)
        d, hr = cache[h]
        if d not in per:
            continue
        p = per[d]
        if m == "vis": p["vis"] += n
        elif m == "pv":
            p["pv"] += n; pages[a]["pv"] += n; hours[hr] += n
        elif m == "ent":
            p["ent"] += n; pages[a]["ent"] += n; src[b] += n
        elif m == "tr": pages[a]["out"] += n; trans[(a, b)] += n
        elif m == "dws": p["dws"] += n; pages[a]["dws"] += n
        elif m == "dwn": p["dwn"] += n; pages[a]["dwn"] += n
        elif m == "utm": utm[(a, b)] += n
        elif m == "clk": clk[(a, b)] += n
        elif m in dev: dev[m][a] += n
        elif m == "bot": bots += n

    tot = {k: sum(p[k] for p in per.values()) for k in ("vis", "pv", "ent", "dws", "dwn")}
    tot["avg"] = tot["dws"] / tot["dwn"] if tot["dwn"] else None
    r = dict(days=days, per=per, tot=tot)
    if not detail:
        return r

    plist = []
    for path, v in pages.items():
        exits = max(0, v["pv"] - v["out"])
        plist.append(dict(path=path, pv=v["pv"], ent=v["ent"], exits=exits,
                          exit_rate=(exits / v["pv"] if v["pv"] else None),
                          avg=(v["dws"] / v["dwn"] if v["dwn"] else None)))
    plist.sort(key=lambda x: -x["pv"])
    chan = defaultdict(int)
    for ref, n in src.items():
        chan[channel(ref)] += n
    clicks = defaultdict(int)
    for (_, tgt), n in clk.items():
        clicks[tgt] += n
    kind = {"out": "Externer Link", "dl": "Download", "ev": "Ereignis"}
    def share(d, top=8):
        items = sorted(d.items(), key=lambda x: -x[1])
        if len(items) > top:
            items = items[:top - 1] + [("Andere", sum(v for _, v in items[top - 1:]))]
        return items

    LANG = {"de": "Deutsch", "en": "Englisch", "fr": "Französisch", "es": "Spanisch", "it": "Italienisch", "tr": "Türkisch",
            "pl": "Polnisch", "ru": "Russisch", "uk": "Ukrainisch", "nl": "Niederländisch", "ar": "Arabisch", "zh": "Chinesisch",
            "pt": "Portugiesisch", "ja": "Japanisch", "??": "Unbekannt"}
    langs = {LANG.get(k, k.upper()): v for k, v in dev["lang"].items()}
    flow = sorted(trans.items(), key=lambda x: -x[1])[:12]
    r.update(
        pages=plist[:30],
        devices=share(dev["dev"]), browsers=share(dev["br"]), systems=share(dev["os"]), langs=share(langs),
        dev_total=sum(dev["dev"].values()), bots=bots,
        bot_share=(bots / (bots + tot["pv"]) if bots + tot["pv"] else None),
        flow=[(a, b, n) for (a, b), n in flow],
        sources=[dict(ref=k, n=v, channel=channel(k)) for k, v in sorted(src.items(), key=lambda x: -x[1])[:25]],
        channels=sorted(chan.items(), key=lambda x: -x[1]),
        utm=[dict(source=a, medium=b, n=n) for (a, b), n in sorted(utm.items(), key=lambda x: -x[1])[:20]],
        clicks=[dict(kind=kind.get(t.split(":", 1)[0], "?"), target=t.split(":", 1)[-1], n=n)
                for t, n in sorted(clicks.items(), key=lambda x: -x[1])[:25]],
        trans=[dict(a=a, b=b, n=n) for (a, b), n in sorted(trans.items(), key=lambda x: -x[1])[:15]],
        hours=hours,
    )
    return r


def delta(cur, prev):
    """Prozentuale Veränderung, None wenn kein Vergleich möglich."""
    if cur is None or prev is None or prev < 10:  # zu kleine Vergleichsbasis: keine Prozentangabe
        return None
    return (cur - prev) / prev * 100.0
