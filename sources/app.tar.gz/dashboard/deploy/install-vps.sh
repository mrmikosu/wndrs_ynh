#!/usr/bin/env bash
# Installiert das Besucher-Analyse-Dashboard auf einem VPS (Yunohost/Debian).
# Als root oder mit sudo ausführen, aus dem ausgepackten dashboard/-Ordner:
#   sudo bash deploy/install-vps.sh
set -euo pipefail

APP_USER="${APP_USER:-besucher}"
APP_DIR="${APP_DIR:-/opt/besucher-dashboard}"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Bitte als root/sudo ausführen." >&2
  exit 1
fi

if ! command -v python3 >/dev/null; then
  apt-get update
  apt-get install -y python3 python3-venv python3-pip
fi

if ! id "$APP_USER" &>/dev/null; then
  useradd --system --home-dir "$APP_DIR" --create-home --shell /usr/sbin/nologin "$APP_USER"
fi

mkdir -p "$APP_DIR"
rsync -a --delete \
  --exclude '.venv' \
  --exclude 'data/dashboard.db' \
  --exclude '__pycache__' \
  --exclude '.DS_Store' \
  "$SRC_DIR"/ "$APP_DIR"/

python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install --upgrade pip
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt"

install -m 0644 "$APP_DIR/deploy/besucher-dashboard.service" /etc/systemd/system/besucher-dashboard.service
systemctl daemon-reload
systemctl enable besucher-dashboard.service
systemctl restart besucher-dashboard.service

chown -R "$APP_USER:$APP_USER" "$APP_DIR"
chmod 700 "$APP_DIR/data" 2>/dev/null || mkdir -p "$APP_DIR/data" && chown "$APP_USER:$APP_USER" "$APP_DIR/data" && chmod 700 "$APP_DIR/data"

echo
echo "Dienst: systemctl status besucher-dashboard"
echo "Lokal:  curl -sS -o /dev/null -w '%{http_code}\\n' http://127.0.0.1:8000/"
echo
echo "Als Nächstes:"
echo "  1) Admin anlegen (einmalig, interaktiv):"
echo "       sudo -u $APP_USER $APP_DIR/.venv/bin/python $APP_DIR/manage.py create-admin DEINNAME"
echo "  2) HTTPS-Proxy (Yunohost/nginx/Caddy) auf 127.0.0.1:8000, z.B. https://stats.kllktv.wndrs.de"
echo "  3) Im PHP-Admin → Besucher → Python-URL setzen"
echo "  4) Im Dashboard Seite anlegen: Endpoint https://kllktv.wndrs.de/site/os/a/x.php"
echo "     (site_id/site_key/secret wie in www/os/data/analytics/config.php)"
