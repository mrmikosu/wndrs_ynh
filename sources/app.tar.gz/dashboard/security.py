"""Passwort-Hash (scrypt), TOTP (RFC 6238), Tokens. Nur Standardbibliothek."""
import base64
import hashlib
import hmac
import os
import secrets
import struct
import time
from urllib.parse import quote

_SCRYPT = dict(n=2**15, r=8, p=1, maxmem=64 * 1024 * 1024, dklen=32)


def hash_pw(pw: str) -> str:
    salt = os.urandom(16)
    return "scrypt$%s$%s" % (salt.hex(), hashlib.scrypt(pw.encode(), salt=salt, **_SCRYPT).hex())


def verify_pw(pw: str, stored: str) -> bool:
    try:
        _, salt, h = stored.split("$")
        calc = hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), **_SCRYPT)
        return hmac.compare_digest(calc, bytes.fromhex(h))
    except Exception:
        return False


DUMMY_HASH = hash_pw(secrets.token_hex(8))  # gleicht die Antwortzeit bei unbekannten Benutzern an


def new_totp_secret() -> str:
    return base64.b32encode(os.urandom(20)).decode()


def totp_at(secret_b32: str, step: int, digits: int = 6) -> str:
    key = base64.b32decode(secret_b32)
    h = hmac.new(key, struct.pack(">Q", step), "sha1").digest()
    o = h[-1] & 15
    code = (struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
    return str(code).zfill(digits)


def totp_verify(secret_b32: str, code: str, last_step: int):
    """Gibt den verwendeten Zeitschritt zurück oder None. Ein Schritt ist nur einmal nutzbar."""
    code = (code or "").strip().replace(" ", "")
    if not (code.isdigit() and len(code) == 6):
        return None
    now = int(time.time() // 30)
    for step in (now - 1, now, now + 1):
        if step > last_step and hmac.compare_digest(totp_at(secret_b32, step), code):
            return step
    return None


def otpauth_uri(user: str, secret: str, issuer: str = "Besucher-Analyse") -> str:
    return "otpauth://totp/%s:%s?secret=%s&issuer=%s" % (quote(issuer), quote(user), secret, quote(issuer))


def token() -> str:
    return secrets.token_urlsafe(32)


def token_hash(t: str) -> str:
    return hashlib.sha256(t.encode()).hexdigest()
